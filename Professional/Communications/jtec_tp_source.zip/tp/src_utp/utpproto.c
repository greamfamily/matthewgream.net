
/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol
 *  Matthew Gream, April 1997
 *  $Id: utpproto.c,v 1.4 1997/06/25 02:26:52 matthewg Exp $
 *  $Log: utpproto.c,v $
 *  Revision 1.4  1997/06/25 02:26:52  matthewg
 *  Added some prints
 *
 *  Revision 1.3  1997/06/11 00:06:12  matthewg
 *  Enhanced debugging and reporting.
 *
 *  Revision 1.2  1997/05/08 06:12:17  matthewg
 *  Integrated/build/test of reliable part of software.
 *
 *  Revision 1.1.1.1  1997/04/28 10:55:48  matthewg
 *  Transport Protocol software. This transport protocol is used to
 *  carry reliable or unreliable data across frame relay through
 *  either an unreliable or reliable (sliding window) transport
 *  protocol.
 *
 *  Initial checkin: Unrelable protocol PC emulation testing complete.
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */

#   include     "utpproto.h"
#   include     "tputlty.h"

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_utp_create (void)
  {
    tp_print (tp_print_info, "Unreliable Transport Protocol Enabled");
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_utp_destroy (void)
  {
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_utp_ctor (tp_pr_utp_ctx* ctx)
  {
    tp_print (tp_print_warn, "UTP (%d): Installed", g_tp_copy);
    ctx->lower_handler = NULL;
    ctx->upper_handler = NULL;
    ctx->excpt_handler = NULL;
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_utp_dtor (tp_pr_utp_ctx* ctx)
  {
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_utp_config (tp_pr_utp_ctx* ctx, MSGPTR msg)
  {
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_utp_status (tp_pr_utp_ctx* ctx)
  {
    tp_print (tp_print_none, "Proto-UTP (%08X):", ctx);
    tp_print (tp_print_none, "  Upper Layer: Hnd %08X, Ctx %08X", ctx->upper_handler, ctx->upper_ctx);
    tp_print (tp_print_none, "  Lower Layer: Hnd %08X, Ctx %08X", ctx->lower_handler, ctx->lower_ctx);

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_utp_connect (tp_pr_utp_ctx* ctx)
  {
    tp_print (tp_print_warn, "UTP (%d): Connect", g_tp_copy);
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_utp_disconnect (tp_pr_utp_ctx* ctx)
  {
    tp_print (tp_print_warn, "UTP (%d): Disconnect", g_tp_copy);
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_utp_lower_set (tp_pr_utp_ctx* ctx, tp_pk_hnd_t hnd, void* ref)
  {
    ctx->lower_handler = hnd;
    ctx->lower_ctx = ref;
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_utp_upper_set (tp_pr_utp_ctx* ctx, tp_pk_hnd_t hnd, void* ref)
  {
    ctx->upper_handler = hnd;
    ctx->upper_ctx = ref;
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_utp_excpt_set (tp_pr_utp_ctx* ctx, tp_msg_hnd_t hnd, void* ref)
  {
    ctx->excpt_handler = hnd;
    ctx->excpt_ctx = ref;
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_utp_upper_input (void* ref, tp_pk_t* pkt)
  {
    tp_pr_utp_ctx* ctx = ref;
    if (tp_pr_utp_lower_output (ctx, pkt) == false)
        return false;
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_utp_lower_input (void* ref, tp_pk_t* pkt)
  {
    tp_pr_utp_ctx* ctx = ref;
    if (tp_pr_utp_upper_output (ctx, pkt) == false)
        return false;
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_utp_timer_input (void* ref, word tck)
  {
    tp_pr_utp_ctx* ctx = ref;
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_utp_upper_output (void * ref, tp_pk_t* pkt)
  {
    tp_pr_utp_ctx* ctx = ref;
    if (ctx->upper_handler == NULL)
        return false;
    if (ctx->upper_handler (ctx->upper_ctx, pkt) == false)
        return false;
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_utp_lower_output (void* ref, tp_pk_t* pkt)
  {
    tp_pr_utp_ctx* ctx = ref;
    if (ctx->lower_handler == NULL)
        return false;
    if (ctx->lower_handler (ctx->lower_ctx, pkt) == false)
        return false;
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_utp_excpt_output (void* ref, char* msg)
  {
    tp_pr_utp_ctx* ctx = ref;
    if (ctx->excpt_handler == NULL)
        return false;
    if (ctx->excpt_handler (ctx->excpt_ctx, msg) == false)
        return false;
    return true;
  }

/*  ---------------------------------------------------------------- */

