
#   ifndef      _UTP_PROTO_H_
#   define      _UTP_PROTO_H_

/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol
 *  Matthew Gream, April 1997
 *  $Id: utpproto.h,v 1.3 1997/06/11 00:06:13 matthewg Exp $
 *  $Log: utpproto.h,v $
 *  Revision 1.3  1997/06/11 00:06:13  matthewg
 *  Enhanced debugging and reporting.
 *
 *  Revision 1.2  1997/05/08 06:12:18  matthewg
 *  Integrated/build/test of reliable part of software.
 *
 *  Revision 1.1.1.1  1997/04/28 10:55:48  matthewg
 *  Transport Protocol software. This transport protocol is used to
 *  carry reliable or unreliable data across frame relay through
 *  either an unreliable or reliable (sliding window) transport
 *  protocol.
 *
 *  Initial checkin: Unrelable protocol PC emulation testing complete.
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */

#   include     "tp.h"
#   include     "tppackt.h"

/*  ---------------------------------------------------------------- */

typedef struct _tp_pr_utp_ctx_                      /* ctx: defn     */
  {
    boolean_t       active;                         /* ctx: active   */
    tp_pk_hnd_t     lower_handler;                  /* low: handler  */
    void*           lower_ctx;                      /* low: context  */
    tp_pk_hnd_t     upper_handler;                  /* upr: handler  */
    void*           upper_ctx;                      /* upr: context  */
    tp_msg_hnd_t    excpt_handler;                  /* exp: handler  */
    void*           excpt_ctx;                      /* exp: context  */
  }
tp_pr_utp_ctx;                                      /* ctx: defn     */

/*  ---------------------------------------------------------------- */

boolean_t   tp_pr_utp_create        (void);
boolean_t   tp_pr_utp_destroy       (void);

boolean_t   tp_pr_utp_ctor          (tp_pr_utp_ctx* ctx);
boolean_t   tp_pr_utp_dtor          (tp_pr_utp_ctx* ctx);

boolean_t   tp_pr_utp_config        (tp_pr_utp_ctx* ctx, MSGPTR msg);
boolean_t   tp_pr_utp_connect       (tp_pr_utp_ctx* ctx);
boolean_t   tp_pr_utp_disconnect    (tp_pr_utp_ctx* ctx);
boolean_t   tp_pr_utp_status        (tp_pr_utp_ctx* ctx);

boolean_t   tp_pr_utp_lower_set     (tp_pr_utp_ctx* ctx, tp_pk_hnd_t hnd, void* ref);
boolean_t   tp_pr_utp_upper_set     (tp_pr_utp_ctx* ctx, tp_pk_hnd_t hnd, void* ref);
boolean_t   tp_pr_utp_excpt_set     (tp_pr_utp_ctx* ctx, tp_msg_hnd_t hnd, void* ref);

boolean_t   tp_pr_utp_upper_input   (void* ref, tp_pk_t* pkt);
boolean_t   tp_pr_utp_lower_input   (void* ref, tp_pk_t* pkt);
boolean_t   tp_pr_utp_timer_input   (void* ref, word tck);

boolean_t   tp_pr_utp_upper_output  (void* ref, tp_pk_t* pkt);
boolean_t   tp_pr_utp_lower_output  (void* ref, tp_pk_t* pkt);
boolean_t   tp_pr_utp_excpt_output  (void* ref, char* msg);

/*  ---------------------------------------------------------------- */

#   endif       /*_UTP_PROTO_H_*/

