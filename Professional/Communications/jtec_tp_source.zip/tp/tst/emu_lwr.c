
/*  ---------------------------------------------------------------- */

#   include     <jexec.h>
#   include     <jtecstd.h>
#   include     <j5000.h>
#   include     <dl_std.h>
#   include     <dl_msgs.h>
#   include     <rm_res.h>
#   include     <rm_res_n.h>
#   include     <rm_res_l.h>
#   include     <monpub.h>
#   include     <rmtaskid.h>
#   include     <bufintf.h>
#   include     <pdatadef.h>
#   include     <jexeclib.h>

/*  ---------------------------------------------------------------- */
/*
 *  This is a lower layer emulator for the transport protocol.
 *  It looks like a packet switch, and accepts frames before
 *  routing them back out. It randomly drops frames too. This
 *  routing is fixed for simplicity.
 */
/*  ---------------------------------------------------------------- */

#   define      _TASK_ID                    (0x00E0)
#   define      _TASK_COPY                  (32)
#   define      _TASK_NAME                  ("Lower Layer")
#   define      _TASK_VERS                  (0x0100)
#   define      _TASK_STCK                  (4096)
#   define      _TASK_PRIO                  (3)
#   define      _TASK_RESV                  (32)
#   define      _TASK_OPTS                  (DOS_NOT_USED)

/*  ---------------------------------------------------------------- */

boolean Install_EmulatorLower (void);
boolean Remove_EmulatorLower (void);
void Execute_EmulatorLower (void);

static boolean_t tsk_execute (void);
static boolean_t tsk_get_vc (MSGPTR msg, VirtualCircuitID** vc);
static boolean_t tsk_drop (MSGPTR msg);
static boolean_t tsk_data (MSGPTR msg);

static tResourceInfo tsk_peer [_TASK_COPY + 1];
static u_byte_t tsk_loop [_TASK_COPY + 1];

/*  ---------------------------------------------------------------- */

u_long_t Stack_EmulatorLower [_TASK_STCK];

boolean Install_EmulatorLower (void)
  {
    return InstallTask (_TASK_ID,
            _TASK_OPTS,
            (void *) Execute_EmulatorLower,
            (int *) &Stack_EmulatorLower [_TASK_STCK],
            NULL,
            _TASK_RESV,
            0,
            sizeof (Stack_EmulatorLower),
            _TASK_PRIO);
  }
boolean Remove_EmulatorLower (void)
  {
    return RemoveTask (_TASK_ID);
  }
void Execute_EmulatorLower (void)
  {
    if (tsk_execute () == false)
        jprintf ("lo: execute (): failed");
  }

/*  ---------------------------------------------------------------- */

static u_long_t tsk_rand (u_long_t lower, u_long_t upper)
  {
    return lower + (random () % (upper - lower));
  }

static boolean_t tsk_execute (void)
  {
    while (1)
      {
        boolean_t result = false;

        MSGPTR msg = NULL;
        while ((msg = GetMessage (_TASK_ID)) == NULL)
            Relinquish ();

        switch (msg->type)
          {
            /* RM Connect */
            case M_CONNECT_REQ:
/*                jprintf ("lo: msg (m_connect_req)");*/
                if (rm_DecodeUpperLayer (msg, &tsk_peer [msg->parameter [0]]) == false ||
                    IsolatePID (msg, 0x01, &tsk_loop [msg->parameter [0]], 1) == 0)
                    tsk_loop [msg->parameter [0]] = 0;
#   if  0
                else
                    jprintf ("lo: loop> [%d] <-> [%d]", msg->parameter [0], tsk_loop [msg->parameter [0]]);
#   endif
                result = false;
                break;

            /* RM Control */
            case M_CONTROL_REQ:
/*                jprintf ("lo: msg (m_control_req)");*/
                result = false;
                break;

            /* RM Disconnect */
            case M_DISCONNECT_REQ:
/*                jprintf ("lo: msg (m_disconnect_req)");*/
                result = false;
                break;

            /* Protocol Data */
            case DL_DATA_REQ:
/*                jprintf ("lo: msg (dl_data_req)");*/
                result = tsk_data (msg);
                break;

            default:
                result = false;
                break;
          }

        if (result == false)
          {
            BufferDescriptor* descr;
            if (IsolateBufferStructPID (msg, &descr) == TRUE)
              {
                ReturnBufferDescriptor (descr);
              }
            ReturnMessage (_TASK_ID, msg);
          }
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

static boolean_t tsk_get_vc (MSGPTR msg, VirtualCircuitID** vc)
  {
    byte* ptr;
    ptr = FindPID (msg, PID_VIRTUAL_CIRCUIT_ID);
    if (ptr == NULL)
          return false;
    (*vc) = &ptr [2];
    return true;
  }

static boolean_t tsk_drop (MSGPTR msg)
  {
    if (tsk_rand (0, 1000) > 950) /* ~95% reliable */
        return true;
    return false;
  }

static boolean_t tsk_data (MSGPTR msg)
  {
    VirtualCircuitID* Vc;
    BufferDescriptor* descr;
    int index;
    tResourceCopy loop;

#   if  1
    /* randomly drop the packet
     */
    if (tsk_drop (msg) == true)
  	  {
		jprintf ("  lower -- drop frame");
        fprintf (stderr, "Lower(%d): Discard\n", msg->parameter [0]);
        return false;
	  }
#   endif

#   if  0
    /* get the virtual circuit id
     */
    if (tsk_get_vc (msg, &Vc) == false)
        return false;

    /* data will always arrive from the same id, so
     * only change the address to loop back.
     */
    switch (Vc->address)
      {
        case 1:
            Vc->address = 2;
            break;
        case 2:
            Vc->address = 1;
            break;
      }
#   endif

    /* send the packet back up to the transport
     * protocol after changing the type.
     */
    loop = tsk_loop [msg->parameter [1]];

    msg->type = DL_DATA_IND;
    msg->parameter [0] = tsk_peer [loop].Copy;
    msg->parameter [1] = loop;
    if (SendMessage (tsk_peer [loop].Id, msg) == FALSE)
      {
        jprintf ("lo: SendMessage failed");
        return false;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

