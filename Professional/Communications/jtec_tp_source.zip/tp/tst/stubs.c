
#   include     <jexec.h>
#   include     <jtecstd.h>
#   include     <dl_std.h>
#   include     <bufintf.h>
#   include     <string.h>
#   include     <cm2.h>
#   include     <rtc.h>
#   include     <pdatadef.h>
#   include     <j5000.h>
#   include     <j5pids.h>

void DumpCopy(MSGPTR msgptr)
  {
    JexecDumpCopy (msgptr, "Msg> ");
    return;
  }

void GetTime (TIME *time)
{
    memset (time, 0, sizeof (TIME));
}

void ReportingOverride(boolean ZZ)
  {
  }

BufferDescriptor bufferDescriptorList [512];
int bufferDescriptorSize = 0;
int bufferDescriptorAllo = 0;

BufferDescriptor *GetBufferDescriptor(dword bufSize)
  {
    int index;
    if (bufferDescriptorSize == 0)
      {
        for (index = 0; index < 512; index++)
          {
            BufferDescriptor* desc = &bufferDescriptorList [index];
            desc->sMallocPtr = (u_byte_t*) malloc (256);
            desc->sBuffPtr = desc->sMallocPtr;
            desc->sMaxBufferLength = 256;
            desc->sOwnerStream = 0;
          }
        bufferDescriptorSize = index;
      }
    for (index = 0; index < 512; index++)
      {
        BufferDescriptor* desc = &bufferDescriptorList [index];
        if (desc->sOwnerStream == 0 && desc->sMaxBufferLength >= bufSize)
          {
            desc->sOwnerStream = 1;
            desc->sLength = 0;
            desc->sOffset = 0;
            desc->sLink = NULL;
            desc->sL2BufferHandle = 0;
            bufferDescriptorAllo++;
            return desc;
          }
      }
    return NULL;
  }
boolean ReturnBufferDescriptor(BufferDescriptor *bufDesc)
  {
	if (bufDesc->sOwnerStream == 0)
	  {
		printf ("BufferDescriptor(%08X): Duplicate Return!", bufDesc);
		exit (1);
	  }
    bufDesc->sOwnerStream = 0;
    bufferDescriptorAllo--;
	if (bufferDescriptorAllo > 32)
    	jprintf ("(Buffer Descriptors: %d outstanding)", bufferDescriptorAllo);
    return FALSE;
  }

boolean build_jtec_frame_relay_header ( BufferDescriptor **buff_desc_ptr,
                                        dword dlci,
                                        FRFrameDataType fr_data_type)
{
        return FALSE;
}    

boolean remove_jtec_frame_relay_header ( BufferDescriptor **fr_buff_desc_ptr,
                                        dword *dlci,
                                        FRFrameDataType *fr_data_type)
{
        return FALSE;
}    



boolean AddVirtualCircuitIdPID(MSGPTR msg, VirtualCircuitID *aVirtualCircuit)
{
    AddArrayPID (msg, PID_VIRTUAL_CIRCUIT_ID, sizeof(VirtualCircuitID), (byte *)aVirtualCircuit);
    return TRUE;    
}    
    
boolean IsolateVirtualCircuitIdPID(MSGPTR msg,VirtualCircuitID *aVirtualCircuit)
{
    return (IsolatePID(msg, PID_VIRTUAL_CIRCUIT_ID, (byte *)aVirtualCircuit, sizeof(VirtualCircuitID)) == sizeof(VirtualCircuitID));
}

boolean AddVirtualCircuitConfigPID(MSGPTR msg, VirtualCircuitConfig *config)
{
    AddArrayPID (msg, PID_VIRTUAL_CIRCUIT_CONFIG, sizeof(VirtualCircuitConfig), (byte *)config);
}    

boolean IsolateVirtualCircuitConfigPID(MSGPTR msg, VirtualCircuitConfig *config)
{
    return (IsolatePID(msg, PID_VIRTUAL_CIRCUIT_CONFIG, (byte *)config, sizeof(VirtualCircuitConfig)) == sizeof(VirtualCircuitConfig));
}    

