
/*  ---------------------------------------------------------------- */

#   include     <jexec.h>
#   include     <jtecstd.h>

#   include     <j5000.h>
#   include     <j5pids.h>
#   include     <j5subtyp.h>
#   include     <j5msgs.h>

#   include     <jexeclib.h>

#   include     <rmtaskid.h>
#   include     <rm_res.h>
#   include     <rm_res_l.h>

#   include     <stdio.h>

#   include     "tp.h"

/*  ---------------------------------------------------------------- */

#   define      _TASK_ID                (JEXEC_TASKID_RESOURCE_MANAGER)
#   define      _TASK_COPY              (128)
#   define      _TASK_NAME              ("RM")
#   define      _TASK_VERS              (0x0100)
#   define      _TASK_STSZ              (4096)
#   define      _TASK_PRIO              (3)
#   define      _TASK_OPTS              (0)
#   define      _TASK_RESV              (64)

/*  ---------------------------------------------------------------- */

boolean Install_EmulatorManager (void);
boolean Remove_EmulatorManager (void);
void Execute_EmulatorManager (void);

static boolean_t mgt_execute (void);

/*  ---------------------------------------------------------------- */

static u_long_t Stack_EmulatorManager [_TASK_STSZ];

/*  ---------------------------------------------------------------- */

boolean Install_EmulatorManager (void)
  {
    if (InstallTask (
            _TASK_ID,
            _TASK_OPTS,
            (void *) Execute_EmulatorManager,
            (int *) &Stack_EmulatorManager [_TASK_STSZ],
            NULL,
            _TASK_RESV,
            0,
            sizeof (Stack_EmulatorManager),
            _TASK_PRIO) == FALSE)
      {
        jprintf ("mgt: install: failed");
        return FALSE;
      }
    return TRUE;
  }

/*  ---------------------------------------------------------------- */

boolean Remove_EmulatorManager (void)
  {
    if (RemoveTask (
            _TASK_ID) == FALSE)
      {
        jprintf ("mgt: remove: failed");
        return FALSE;
      }
    return TRUE;
  }

/*  ---------------------------------------------------------------- */

void Execute_EmulatorManager (void)
  {
    if (mgt_execute () == false)
        jprintf ("mgt: execute: failed");
    return;
  }

/*  ---------------------------------------------------------------- */

typedef struct _mgt_tsk_ctx_
  {
    char*               name;

    tResourceId         id;                             /* task id   */
    tResourceCopy       copy;                           /* task copy */
    tModuleId           module;                         /* task modu */

    u_byte_t            upr_data [128];                 /* up: data  */
    int                 upr_data_sz;                    /* up: size  */
    u_byte_t            lwr_data [128];                 /* lw: data  */
    int                 lwr_data_sz;                    /* lw: size  */
    u_byte_t            tsk_data [128];                 /* tk: data  */
    int                 tsk_data_sz;                    /* tk: size  */

  } mgt_tsk_ctx;

/*  ---------------------------------------------------------------- */

static boolean_t mgt_tsk_ini (mgt_tsk_ctx* tsk, mgt_tsk_ctx* upr, mgt_tsk_ctx* lwr);
static boolean_t mgt_tsk_trm (mgt_tsk_ctx* tsk);

/*  ---------------------------------------------------------------- */

/*  configuration
    - set up configuration for two protocol stacks, connected to the
      packet switch, then set up route for the protocol stacks, make
      sure the correct dlci's are present:
        - upper layer has a dlci specified
        - upper layer has an interface specified
        - route has dlci specified for the other interface
 */

static mgt_tsk_ctx tx_tst_cfg_drv =
  {
    "driver tx (upper layer)",
    0xE1, 1, 0,
    { 0x00 }, 0x00,
    { 0x00 }, 0x00,
    { 0x01, 0x01, 0x01,
	  0x02, 0x01, 0x02 }, 0x06,
  };
static mgt_tsk_ctx rx_tst_cfg_drv =
  {
    "driver rx (upper layer)",
    0xE1, 2, 0,
    { 0x00 }, 0x00,
    { 0x00 }, 0x00,
    { 0x01, 0x01, 0x00,
	  0x02, 0x01, 0x01 }, 0x06,
  };
static mgt_tsk_ctx tx_tst_cfg_tsk =
  {
    "task tx (transport protocol)",
    JEXEC_TASKID_TRANSPORT_PROTOCOL, 2, 0,
    { 0x00 }, 0x00,
    { 0x00 }, 0x00,
    { 0xA0, 0x01, 0x02,
      0x85, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00 }, 0x0D,
  };
static mgt_tsk_ctx rx_tst_cfg_tsk =
  {
    "task rx (transport protocol)",
    JEXEC_TASKID_TRANSPORT_PROTOCOL, 3, 0,
    { 0x00 }, 0x00,
    { 0x00 }, 0x00,
    { 0xA0, 0x01, 0x02,
      0x85, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00 }, 0x0D,
  };
static mgt_tsk_ctx tx_tst_cfg_emu =
  {
    "emulator tx (lower layer)",
    0xE0, 2, 0,
    { 0x00 }, 0x00,
    { 0x00 }, 0x00,
    { 0x01, 0x01, 0x03 }, 0x03,
  };
static mgt_tsk_ctx rx_tst_cfg_emu =
  {
    "emulator rx (lower layer)",
    0xE0, 3, 0,
    { 0x00 }, 0x00,
    { 0x00 }, 0x00,
    { 0x01, 0x01, 0x02 }, 0x03,
  };

/*  ---------------------------------------------------------------- */

static boolean_t mgt_execute (void)
  {
    int idx;
    for (idx = 0; idx < 100; idx++)
        Relinquish ();

    jprintf ("mgt: init");

    /* configure rx protocol stack */
    if (mgt_tsk_ini (&rx_tst_cfg_drv, NULL, &rx_tst_cfg_tsk) == false)
        jprintf ("mgt: init failed for: %s", rx_tst_cfg_drv.name);
    if (mgt_tsk_ini (&rx_tst_cfg_tsk, &rx_tst_cfg_drv, &rx_tst_cfg_emu) == false)
        jprintf ("mgt: init failed for: %s", rx_tst_cfg_tsk.name);
    if (mgt_tsk_ini (&rx_tst_cfg_emu, &rx_tst_cfg_tsk, NULL) == false)
        jprintf ("mgt: init failed for: %s", rx_tst_cfg_emu.name);
    /* configure tx protocol stack */
    if (mgt_tsk_ini (&tx_tst_cfg_drv, NULL, &tx_tst_cfg_tsk) == false)
        jprintf ("mgt: init failed for: %s", tx_tst_cfg_drv.name);
    if (mgt_tsk_ini (&tx_tst_cfg_tsk, &tx_tst_cfg_drv, &tx_tst_cfg_emu) == false)
        jprintf ("mgt: init failed for: %s", tx_tst_cfg_tsk.name);
    if (mgt_tsk_ini (&tx_tst_cfg_emu, &tx_tst_cfg_tsk, NULL) == false)
        jprintf ("mgt: init failed for: %s", tx_tst_cfg_emu.name);

    jprintf ("mgt: wait");

    while (1)
      {
        MSGPTR msg;
        while ((msg = GetMessage (_TASK_ID)) == NULL)
            Relinquish ();
        jprintf ("mgt: get_message (%04X)", msg->type);
        ReturnMessage (_TASK_ID, msg);
      }

    return false;
  }

/*  ---------------------------------------------------------------- */

static boolean_t mgt_tsk_ini (mgt_tsk_ctx* tsk, mgt_tsk_ctx* upr, mgt_tsk_ctx* lwr)
  {
    MSGPTR msg;

#   if  1
    if ((msg = NewMessage (_TASK_ID)) == NULL)
        return false;
    msg->type = JEXEC_START_UP;
    msg->parameter [0] = 4;
    if (SendMessage (tsk->id, msg) == FALSE)
      {
        ReturnMessage (_TASK_ID, msg);
        return false;
      }
#   endif

    if ((msg = NewMessage (_TASK_ID)) == NULL)
        return false;

    msg->type           = M_CONNECT_REQ;
    msg->parameter [0]  = tsk->copy;
    msg->parameter [1]  = 0;
    msg->length         = 0;

    AddPID (msg,
            PID_SUBTYPE,
            1,
            SUBTYPE_RM_RESOURCE_CONTROL);

    /* UPPER RESOURCE */
    if (upr != NULL)
      {
        tResourceInfo info;
        info.Id = upr->id;
        info.Copy = upr->copy;
        info.Module = upr->module;
        rm_EncodeUpperLayer (msg, &info);
        jprintf ("mgt: upper: %04X, %02X, %02X", info.Id, info.Copy, info.Module);
      }

    /* LOWER RESOURCE */
    if (lwr != NULL)
      {
        tResourceInfo info;
        info.Id = lwr->id;
        info.Copy = lwr->copy;
        info.Module = lwr->module;
        rm_EncodeLowerLayer (msg, &info);
        jprintf ("mgt: lower: %04X, %02X, %02X", info.Id, info.Copy, info.Module);
      }

    /* CONFIG */
    if (tsk->tsk_data_sz > 0)
      {
        memcpy (&msg->data [msg->length],
                tsk->tsk_data,
                tsk->tsk_data_sz);
        msg->length += tsk->tsk_data_sz;
      }

    /* UPPER RESOURCE CONFIG */
    if (upr != NULL &&
        upr->lwr_data_sz > 0)
      {
        memcpy (&msg->data [msg->length],
                upr->lwr_data,
                upr->lwr_data_sz);
        msg->length += upr->lwr_data_sz;
      }

    /* LOWER RESOURCE CONFIG */
    if (lwr != NULL &&
        lwr->upr_data_sz > 0)
      {
        memcpy (&msg->data [msg->length],
                lwr->upr_data,
                lwr->upr_data_sz);
        msg->length += lwr->upr_data_sz;
      }

    if (SendMessage (tsk->id, msg) == FALSE)
      {
        ReturnMessage (_TASK_ID, msg);
        return false;
      }

    return true;
  }

static boolean_t mgt_tsk_trm (mgt_tsk_ctx* tsk)
  {
    MSGPTR msg;

    if ((msg = NewMessage (_TASK_ID)) == NULL)
        return false;

    msg->type           = M_DISCONNECT_REQ;
    msg->parameter [0]  = tsk->copy;
    msg->parameter [1]  = 0;
    msg->length         = 0;

    AddPID (msg,
            PID_SUBTYPE,
            1,
            SUBTYPE_RM_RESOURCE_CONTROL);

    if (SendMessage (tsk->id, msg) == FALSE)
      {
        ReturnMessage (_TASK_ID, msg);
        return false;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

