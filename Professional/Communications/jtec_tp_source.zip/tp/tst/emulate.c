
/*  ---------------------------------------------------------------- */

#   include     <jexec.h>
#   include     <jtecstd.h>

/*  ---------------------------------------------------------------- */

extern boolean Install_TransportProtocol (void);
extern boolean Install_EmulatorLower (void);
extern boolean Install_EmulatorUpper (void);
extern boolean Install_EmulatorManager (void);

/*  ---------------------------------------------------------------- */

int main (int argc, char ** argv)
  {
    if (Gexec (argc, argv) == false)
        return -1;
    return 0;
  }

/*  ---------------------------------------------------------------- */

int Gexec_InstallTask (void)
  {
    if (Install_TransportProtocol () == FALSE)
        return FALSE;
    if (Install_EmulatorLower () == FALSE)
        return FALSE;
    if (Install_EmulatorUpper () == FALSE)
        return FALSE;
    if (Install_EmulatorManager () == FALSE)
        return FALSE;
    return TRUE;
  }

/*  ---------------------------------------------------------------- */

