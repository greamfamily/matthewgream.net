
/*  ---------------------------------------------------------------- */

#   include     <jexec.h>
#   include     <jtecstd.h>
#   include     <j5000.h>
#   include     <dl_std.h>
#   include     <dl_msgs.h>
#   include     <rm_res.h>
#   include     <rm_res_n.h>
#   include     <rm_res_l.h>
#   include     <monpub.h>
#   include     <bufintf.h>

/*  ---------------------------------------------------------------- */

/*  Upper Layer Emulator -- in this emulator, we wait until we are
 *      configured by the resource manager. When an instance is
 *      configured, it will start sending data on a random basis.
 *      Each data packet is unique. Any data received from the
 *      lower layer is displayed; all other events are displayed.
 */

/*  ---------------------------------------------------------------- */

#   define      _TASK_ID                    (0x00E1)
#   define      _TASK_COPY                  (32)
#   define      _TASK_NAME                  ("Upper Layer")
#   define      _TASK_VERS                  (0x0100)
#   define      _TASK_STCK                  (4096)
#   define      _TASK_PRIO                  (3)
#   define      _TASK_RESV                  (32)
#   define      _TASK_OPTS                  (DOS_NOT_USED)

/*  ---------------------------------------------------------------- */

typedef struct _tsk_ctx_
  {
    boolean_t           active;
    tResourceId         id;
    tResourceCopy       copy;
    tResourceId         lwr_id;
    tResourceCopy       lwr_copy;
    u_long_t            pro_count;
    u_long_t            pro_recv;
    u_long_t            pro_send;
    u_byte_t            mode;
	tResourceCopy		peer;
  } tsk_ctx;

/*  ---------------------------------------------------------------- */
	
int Gexec_SwitchCount = 0;

/*  ---------------------------------------------------------------- */

boolean Install_EmulatorUpper (void);
boolean Remove_EmulatorUpper (void);
void Execute_EmulatorUpper (void);

static boolean_t tsk_execute (void);
static boolean_t tsk_time_init (void);
static boolean_t tsk_time_expr (MSGPTR msg);
static boolean_t tsk_prot_init (void);
static boolean_t tsk_prot_send (tsk_ctx* ctx);
static boolean_t tsk_prot_conn_rcv (tsk_ctx* ctx, MSGPTR msg);
static boolean_t tsk_prot_disc_rcv (tsk_ctx* ctx, MSGPTR msg);
static boolean_t tsk_prot_data_rcv (tsk_ctx* ctx, MSGPTR msg);
static boolean_t tsk_prot_conn_snd (tsk_ctx* ctx);
static boolean_t tsk_prot_disc_snd (tsk_ctx* ctx);
static boolean_t tsk_prot_data_snd (tsk_ctx* ctx, int size, char* data);
static boolean_t tsk_prot_frame_snd (tResourceId dst_id, tResourceCopy dst_copy, tResourceId src_id, tResourceCopy src_copy, word type, int size, u_byte_t* data);
static boolean_t tsk_init (void);
static boolean_t tsk_destroy (void);
static boolean_t tsk_config (tsk_ctx* ctx, MSGPTR msg);
static boolean_t tsk_connect (tsk_ctx* ctx);
static boolean_t tsk_disconnect (tsk_ctx* ctx);
static tsk_ctx* tsk_allocate (tResourceCopy copy);
static boolean_t tsk_free (tsk_ctx* ctx);
static tsk_ctx* tsk_locate (tResourceCopy copy);
static tsk_ctx* tsk_next (int* index);
static boolean_t tsk_mgmt_init (void);
static boolean_t tsk_mgmt_conn (MSGPTR msg);
static boolean_t tsk_mgmt_disc (MSGPTR msg);
static tsk_ctx* tsk_mgmt_find (MSGPTR msg);

/*  ---------------------------------------------------------------- */

u_long_t Stack_EmulatorUpper [_TASK_STCK];

boolean Install_EmulatorUpper (void)
  {
    return InstallTask (_TASK_ID,
            _TASK_OPTS,
            (void *) Execute_EmulatorUpper,
            (int *) &Stack_EmulatorUpper [_TASK_STCK],
            NULL,
            _TASK_RESV,
            0,
            sizeof (Stack_EmulatorUpper),
            _TASK_PRIO);
  }
boolean Remove_EmulatorUpper (void)
  {
    return RemoveTask (_TASK_ID);
  }
void Execute_EmulatorUpper (void)
  {
    if (tsk_execute () == false)
        jprintf ("up: execute (): failed");
  }

/*  ---------------------------------------------------------------- */

static void tsk_dump_msg (MSGPTR msg)
  {
    jprintf ("up: dump- msg type %04x", msg->type);
    return;
  }
static void tsk_dump_buf (BufferDescriptor* descr)
  {
    jprintf ("  Buffer (%08X): %s", Gexec_SwitchCount,
                GetDataPtrFromBufDesc (descr));
    return;
  }
static u_long_t tsk_rand (u_long_t lower, u_long_t upper)
  {
    return lower + (random () % (upper - lower));
  }

static boolean_t tsk_execute (void)
  {
    if (tsk_init () == false)
        return false;
    if (tsk_time_init () == false)
        return false;
    if (tsk_prot_init () == false)
        return false;
    if (tsk_mgmt_init () == false)
        return false;

    while (1)
      {
        tsk_ctx* ctx = NULL;
        boolean_t result = false;

        MSGPTR msg = NULL;
        while ((msg = GetMessage (_TASK_ID)) == NULL)
            Relinquish ();

        switch (msg->type)
          {
            /* RM Connect */
            case M_CONNECT_REQ:
                result = tsk_mgmt_conn (msg);
                break;

            /* RM Disconnect */
            case M_DISCONNECT_REQ:
                result = tsk_mgmt_disc (msg);
                break;

            /* Protocol Connect */
            case DL_ESTABLISH_IND:
                if ((ctx = tsk_mgmt_find (msg)) != NULL)
                    result = tsk_prot_conn_rcv (ctx, msg);
                break;

            /* Protocol Disconnect */
            case DL_RELEASE_IND:
                if ((ctx = tsk_mgmt_find (msg)) != NULL)
                    result = tsk_prot_disc_rcv (ctx, msg);
                break;

            /* Protocol Data */
            case DL_DATA_IND:
                if ((ctx = tsk_mgmt_find (msg)) != NULL)
                    result = tsk_prot_data_rcv (ctx, msg);
                break;

            /* Timer Expiry */
            case JEXEC_TIMER_EXPIRY:
                result = tsk_time_expr (msg);
                break;

            default:
                result = false;
                break;
          }

        if (result == false)
          {
            jprintf ("up: msg unprocessed");
            DumpCopy (msg);
          }

        ReturnMessage (_TASK_ID, msg);
      }

    return true;
  }

/*  ---------------------------------------------------------------- */
/*  TIMERS */

static u_byte_t tsk_time_handle = 0;
static boolean_t tsk_time_init (void)
  {
    tsk_time_handle = GetTimer (_TASK_ID);
    if (tsk_time_handle == 0)
        return false;
    if (StartTimer (_TASK_ID,
                         tsk_time_handle,
                         0xDEAD,
                         0xBEEF,
                         1 SECONDS,
                         TIMER_ONE_SHOT) == FALSE)
        return false;
    return true;
  }
static boolean_t tsk_time_expr (MSGPTR msg)
  {
    int index = 0;
    tsk_ctx* ctx;
    while ((ctx = tsk_next (&index)) != NULL)
      {
#	if	0
        if (ctx->mode == 0x00)
            continue;
        if (tsk_rand (0, 1000) > 250)
            tsk_prot_send (ctx);
#   endif
        if (tsk_rand (0, 1000) > 500)
            tsk_prot_send (ctx);
      }
    if (StartTimer (_TASK_ID,
                         tsk_time_handle,
                         0xDEAD,
                         0xBEEF,
                         tsk_rand (200 MILLISECONDS, 300 MILLISECONDS),
                         TIMER_ONE_SHOT) == FALSE)
        return false;
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  PROTOCOL */

/* Initialise the Protocol */
static boolean_t tsk_prot_init (void)
  {
    return true;
  }

/* Send Data for the Protocol */
static boolean_t tsk_prot_send (tsk_ctx* ctx)
  {
    char string [80];
    sprintf (string, "Test Data: Copy(%03d), Count(%03d) -- %08X", ctx->copy, ctx->pro_count++, Gexec_SwitchCount);
    if (tsk_prot_data_snd (ctx, strlen (string) + 1, string) == false)
        return false;
    return true;
  }

/* Receive Connect for the Protocol */
static boolean_t tsk_prot_conn_rcv (tsk_ctx* ctx, MSGPTR msg)
  {
    jprintf ("up: Protocol Connected (Copy=%d)", ctx->copy);
    fprintf (stderr, "Upper(%d): Connected\n", ctx->copy);
    return true;
  }
static boolean_t tsk_prot_disc_rcv (tsk_ctx* ctx, MSGPTR msg)
  {
    jprintf ("up: Protocol Disconnected (Copy=%d)", ctx->copy);
    fprintf (stderr, "Upper(%d): Disconnected\n", ctx->copy);
    return true;
  }
static boolean_t tsk_prot_data_rcv (tsk_ctx* ctx, MSGPTR msg)
  {
	tsk_ctx* ctx_peer = tsk_locate (ctx->peer);
	u_long_t snd; u_long_t rcv;
    BufferDescriptor* descr;
    /*jprintf ("up: Protocol Receive (Copy=%d)", ctx->copy);*/
    if (IsolateBufferStructPID (msg, &descr) == FALSE)
      {
        jprintf ("up: no buffer descriptor");
        return false;
      }
    tsk_dump_buf (descr);
    ReturnBufferDescriptor (descr);
    ctx->pro_recv++;
	rcv = ctx->pro_recv;
	snd = (ctx_peer == NULL) ? 0 : ctx_peer->pro_send;
    jprintf ("up: (%d):rcv: Recv(%03d), Send(%03d) : %03d pc reliable",
        ctx->copy, rcv, snd, (rcv * 100) / (snd == 0 ? 1 : snd));
    fprintf (stderr, "Upper(%d -> %d): Send %d, Recv %d [RECV]\n",
                ctx->copy, ctx->peer,
                snd, rcv);
    return true;
  }
static boolean_t tsk_prot_conn_snd (tsk_ctx* ctx)
  {
    jprintf ("up: Protocol Connect (Copy=%d)", ctx->copy);
    if (tsk_prot_frame_snd (ctx->lwr_id,
                            ctx->lwr_copy,
                            ctx->id,
                            ctx->copy,
                            DL_ESTABLISH_REQ,
                            0,
                            NULL) == false)
        return false;
    return true;
  }
static boolean_t tsk_prot_disc_snd (tsk_ctx* ctx)
  {
    jprintf ("up: Protocol Disconnect (Copy=%d)", ctx->copy);
    if (tsk_prot_frame_snd (ctx->lwr_id,
                            ctx->lwr_copy,
                            ctx->id,
                            ctx->copy,
                            DL_RELEASE_REQ,
                            0,
                            NULL) == false)
        return false;
    return true;
  }
static boolean_t tsk_prot_data_snd (tsk_ctx* ctx, int size, char* data)
  {
	tsk_ctx* ctx_peer = tsk_locate (ctx->peer);
	u_long_t snd; u_long_t rcv;
    /*jprintf ("up: Protocol Transmit (Copy=%d)", ctx->copy);*/
    if (tsk_prot_frame_snd (ctx->lwr_id,
                            ctx->lwr_copy,
                            ctx->id,
                            ctx->copy,
                            DL_DATA_REQ,
                            size,
                            data) == false)
        return false;
    ctx->pro_send++;
	snd = ctx->pro_send;
	rcv = (ctx_peer == NULL) ? 0 : ctx_peer->pro_recv;
    jprintf ("up: (%d):snd: Recv(%03d), Send(%03d) : %03d pc reliable",
		ctx->copy, rcv, snd, (rcv * 100) / (snd == 0 ? 1 : snd));
    fprintf (stderr, "Upper(%d -> %d): Send %d, Recv %d [SEND]\n",
                ctx->copy, ctx->peer,
                snd, rcv);
    return true;
  }
static boolean_t tsk_prot_frame_snd (tResourceId dst_id,
                                     tResourceCopy dst_copy,
                                     tResourceId src_id,
                                     tResourceCopy src_copy,
                                     word type,
                                     int size,
                                     u_byte_t* data)
  {
    MSGPTR msg = NULL;
    BufferDescriptor* descr = NULL;

    if ((msg = NewMessage (src_id)) == NULL)
        goto snd_fail;
    msg->type = type;
    msg->length = 0;
    msg->parameter [0] = dst_copy;
    msg->parameter [1] = src_copy;

    if (data != NULL)
      {
        if ((descr = GetBufferDescriptor (128)) == NULL)
            goto snd_fail;
        memcpy (GetDataPtrFromBufDesc (descr),
                data,
                size);
        SetLengthInBufDesc (descr, size);
        if (AddBufferStructPID (msg, descr) == FALSE)
            goto snd_fail;
        tsk_dump_buf (descr);
      }

    if (SendMessage (dst_id, msg) == FALSE)
        goto snd_fail;

    return true;

snd_fail:;
    if (msg != NULL)
        ReturnMessage (src_id, msg);
    if (descr != NULL)
        ReturnBufferDescriptor (descr);
    return false;
  }

/*  ---------------------------------------------------------------- */
/*  TASK */

static tsk_ctx tsk_ctx_list [_TASK_COPY];
static int tsk_ctx_list_size = _TASK_COPY;

/* Create Task */
static boolean_t tsk_init (void)
  {
    int index;
    for (index = 0;
         index < tsk_ctx_list_size;
         index++)
      {
        tsk_ctx* ctx = &tsk_ctx_list [index];
        ctx->active = false;
      }
    return true;
  }

/* Destroy Task */
static boolean_t tsk_destroy (void)
  {
    int index;
    for (index = 0;
         index < tsk_ctx_list_size;
         index++)
      {
        tsk_ctx* ctx = &tsk_ctx_list [index];
        if (ctx->active == true)
          {
            tsk_disconnect (ctx);
            tsk_free (ctx);
          }
      }
    return true;
  }

/* Allocate Task */
static tsk_ctx* tsk_allocate (tResourceCopy copy)
  {
    tsk_ctx* ctx;
    if ((ctx = &tsk_ctx_list [copy - 1])->active == true)
        return NULL;
    ctx->id = _TASK_ID;
    ctx->copy = copy;
    ctx->pro_count = 0;
    ctx->pro_send = 0;
    ctx->pro_recv = 0;
    ctx->lwr_id = 0;
    ctx->lwr_copy = 0;
    ctx->mode = 0;
	ctx->peer = copy;
    ctx->active = true;
    return ctx;
  }

/* Free Task */
static boolean_t tsk_free (tsk_ctx* ctx)
  {
    ctx->active = false;
    return true;
  }

/* Locate Task */
static tsk_ctx* tsk_locate (tResourceCopy copy)
  {
    tsk_ctx* ctx;
    if ((ctx = &tsk_ctx_list [copy - 1])->active == false)
        return NULL;
    return ctx;
  }

/* Next Task */
static tsk_ctx* tsk_next (int* index)
  {
    while ((*index) < tsk_ctx_list_size)
      {
        tsk_ctx* ctx = &tsk_ctx_list [(*index)++];
        if (ctx->active == true)
            return ctx;
      }
    return NULL;
  }

/* Config Task */
static boolean_t tsk_config (tsk_ctx* ctx, MSGPTR msg)
  {
    tResourceInfo info;
    u_byte_t mode;
	u_byte_t peer;
    if (rm_DecodeLowerLayer (msg, &info) == false)
        return false;
    ctx->lwr_id = info.Id;
    ctx->lwr_copy = info.Copy;
    if (IsolatePID (msg, 0x01, &mode, 1) == 0)
        return false;
    if (IsolatePID (msg, 0x02, &peer, 1) == 0)
        return false;
    ctx->mode = mode;
	ctx->peer = peer;
    return true;
  }

/* Connect Task */
static boolean_t tsk_connect (tsk_ctx* ctx)
  {
    if (tsk_prot_conn_snd (ctx) == false)
        return false;
    return true;
  }

/* Disconnect Task */
static boolean_t tsk_disconnect (tsk_ctx* ctx)
  {
    if (tsk_prot_disc_snd (ctx) == false)
        return false;
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  MANAGEMENT */

/* Initialise Instance */
static boolean_t tsk_mgmt_init (void)
  {
    return true;
  }

/* Connect Instance */
static boolean_t tsk_mgmt_conn (MSGPTR msg)
  {
    tResourceCopy copy;
    tsk_ctx* ctx;
    if ((copy = msg->parameter [0]) == 0)
        return false;
    if ((ctx = tsk_locate (copy)) != NULL)
        tsk_free (ctx);
    if ((ctx = tsk_allocate (copy)) == NULL)
        return false;
    if (tsk_config (ctx, msg) == false)
        return false;
    if (tsk_connect (ctx) == false)
        return false;
    jprintf ("up: Management Connected (Copy=%d)", ctx->copy);
    return true;
  }

/* Disconnect Instance */
static boolean_t tsk_mgmt_disc (MSGPTR msg)
  {
    tResourceCopy copy;
    tsk_ctx* ctx;
    if ((copy = msg->parameter [0]) == 0)
        return false;
    if ((ctx = tsk_locate (copy)) == NULL)
        return true;
    tsk_disconnect (ctx);
    jprintf ("up: Management Disconnected (Copy=%d)", ctx->copy);
    tsk_free (ctx);
    return true;
  }

/* Find Instance */
static tsk_ctx* tsk_mgmt_find (MSGPTR msg)
  {
    tResourceCopy copy;
    tsk_ctx* ctx;
    if ((copy = msg->parameter [0]) == 0)
        return NULL;
    if ((ctx = tsk_locate (copy)) == NULL)
        return NULL;
    return ctx;
  }

/*  ---------------------------------------------------------------- */

