
/* ------------------------------------------------------------------- */

#   include     "rdp_pckt.h"
#	include		"tputlty.h"

/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol -- Reliable Data Protocol RFC0908
 *  Matthew Gream, April 1997
 *  $Id: rdp_pckt.c,v 1.2 1997/07/22 14:49:06 matthewg Exp $
 *  $Log: rdp_pckt.c,v $
 *  Revision 1.2  1997/07/22 14:49:06  matthewg
 *  Fixed an integration bug that occurred because of changes to
 *  the frame relay encapsulation routines: now, when constructing
 *  a packet, a 16 byte offset is used to leave space for the fr
 *  encapsulation routines.
 *
 *  Revision 1.1  1997/06/25 02:21:05  matthewg
 *  Added Reliable Data Protocol (RFC-0908) in place of existing
 *  protocol.
 *
 */
/*  ---------------------------------------------------------------- */

#   define  RDP_Segment_Encode__Flags(seg_ptr, flg) \
    { \
      seg_ptr [0] = (seg_ptr [0] & ~(0x1F)) | ((flg) & 0x1F); \
    }

#   define  RDP_Segment_Encode__MBZ(seg_ptr) \
    { \
      seg_ptr [0] = (seg_ptr [0] & ~(0x20)) | 0x00; \
    }

#   define  RDP_Segment_Encode__Version(seg_ptr, ver) \
    { \
      seg_ptr [0] = (seg_ptr [0] & ~(0xA0)) | (((ver) << 6) & 0xA0); \
    }

#   define  RDP_Segment_Encode__Header_Length(seg_ptr, len) \
    { \
      seg_ptr [1] = ((len) >> 1); \
    }

#   define  RDP_Segment_Encode__Source_Port(seg_ptr, prt) \
    { \
      seg_ptr [2] = (prt); \
    }

#   define  RDP_Segment_Encode__Destination_Port(seg_ptr, prt) \
    { \
      seg_ptr [3] = (prt); \
    }

#   define  RDP_Segment_Encode__Data_Length(seg_ptr, len) \
    { \
      seg_ptr [4] = (len & 0xFF); \
      seg_ptr [5] = ((len >> 8) & 0xFF); \
    }

#   define  RDP_Segment_Encode__Sequence_Number(seg_ptr, seq) \
    { \
      seg_ptr [6] = (seq & 0xFF); \
      seg_ptr [7] = ((seq >> 8) & 0xFF); \
    }

#   define  RDP_Segment_Encode__Acknowledgement_Number(seg_ptr, ack) \
    { \
      seg_ptr [8] = (ack & 0xFF); \
      seg_ptr [9] = ((ack >> 8) & 0xFF); \
    }

#   define  RDP_Segment_Encode__Checksum(seg_ptr, chk) \
    { \
      seg_ptr [10] = (chk & 0xFF); \
      seg_ptr [11] = ((chk >> 8) & 0xFF); \
    }

#   define  RDP_Segment_Encode__Extended_Header(seg_ptr, len, ptr) \
    { u_byte_t hdr_len; \
      RDP_Segment_Decode__Header_Length (seg_ptr, &hdr_len); \
      memcpy (&seg_ptr [hdr_len], ptr, len); \
      RDP_Segment_Encode__Header_Length (seg_ptr, hdr_len + len); \
    }

#   define  RDP_Segment_Encode__Data(seg_ptr, len, ptr) \
    { u_byte_t hdr_len; \
      u_short_t dat_len; \
      RDP_Segment_Decode__Header_Length (seg_ptr, &hdr_len); \
      RDP_Segment_Decode__Data_Length (seg_ptr, &dat_len); \
      memcpy (&seg_ptr [hdr_len + dat_len], ptr, len); \
      RDP_Segment_Encode__Data_Length (seg_ptr, dat_len + len); \
    }

#   define  RDP_Segment_Decode__Flags(seg_ptr, flg) \
    { \
      (*flg) = (seg_ptr [0] & 0x1F); \
    }

#   define  RDP_Segment_Decode__MBZ(seg_ptr) \
    { \
      \
    }

#   define  RDP_Segment_Decode__Version(seg_ptr, ver) \
    { \
      (*ver) = ((seg_ptr [0] & 0xA0) >> 6); \
    }

#   define  RDP_Segment_Decode__Header_Length(seg_ptr, len) \
    { \
      (*len) = (seg_ptr [1] << 1); \
    }

#   define  RDP_Segment_Decode__Source_Port(seg_ptr, prt) \
    { \
      (*prt) = seg_ptr [2]; \
    }

#   define  RDP_Segment_Decode__Destination_Port(seg_ptr, prt) \
    { \
      (*prt) = seg_ptr [3]; \
    }

#   define  RDP_Segment_Decode__Data_Length(seg_ptr, len) \
    { \
      (*len) = (seg_ptr [4]) | \
               (seg_ptr [5] << 8); \
    }

#   define  RDP_Segment_Decode__Sequence_Number(seg_ptr, seq) \
    { \
      (*seq) = (seg_ptr [6]) | \
               (seg_ptr [7] << 8); \
    }

#   define  RDP_Segment_Decode__Acknowledgement_Number(seg_ptr, ack) \
    { \
      (*ack) = (seg_ptr [8]) | \
               (seg_ptr [9] << 8); \
    }

#   define  RDP_Segment_Decode__Checksum(seg_ptr, chk) \
    { \
      (*chk) = (seg_ptr [10]) | \
               (seg_ptr [11] << 8); \
    }

#   define  RDP_Segment_Decode__Extended_Header(seg_ptr, len, ptr) \
    { u_byte_t hdr_len; \
      RDP_Segment_Decode__Header_Length (seg_ptr, &hdr_len); \
      hdr_len -= 12; \
      memcpy (ptr, &seg_ptr [12], Min ((*len), hdr_len)); \
      (*len) = Min ((*len), hdr_len); \
    }

#   define  RDP_Segment_Decode__Data(seg_ptr, len, ptr) \
    { u_byte_t hdr_len; \
      u_short_t dat_len; \
      RDP_Segment_Decode__Header_Length (seg_ptr, &hdr_len); \
      RDP_Segment_Decode__Data_Length (seg_ptr, &dat_len); \
      memcpy (ptr, &seg_ptr [hdr_len], Min ((*len), dat_len)); \
      (*len) = Min ((*len), dat_len); \
    }

#   define  RDP_Segment_Decode__Segment_Size(seg_ptr, len) \
    { u_byte_t hdr_len; \
      u_short_t dat_len; \
      RDP_Segment_Decode__Header_Length (seg_ptr, &hdr_len); \
      RDP_Segment_Decode__Data_Length (seg_ptr, &dat_len); \
      (*len) = (hdr_len + dat_len); \
    }

#   define  RDP_Segment_Encode__Extended_Header_Acknowledgement_Number(seg_ptr, n, seq) \
    { \
      seg_ptr [0 + (n << 1)] = (seq & 0xFF); \
      seg_ptr [1 + (n << 1)] = ((seq >> 8) & 0xFF); \
    }

/*  ---------------------------------------------------------------- */
/*  Deliver Segment -- deliver the segment down to the lower layers.
 */

boolean_t rdp_func_DeliverSegment (rdp_state_info_t* info,
                                   tp_pk_t* pkt)
  {
#   ifdef   DEBUG_RDP_SEVERE
    tp_print (tp_print_debug, "RDP(%d): Deliver Segment", g_tp_copy);
    tp_prhex (tp_print_debug, " > ", tp_pk_sze_get (pkt), tp_pk_dat_get (pkt));
#   endif
    if (info->lower_output_hnd == NULL || info->lower_output_ctx == NULL)
        return false;
    if (info->lower_output_hnd (info->lower_output_ctx, pkt) == false)
        return false;
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Encode Segment -- encode all of the segment elements into
 *      the segment.
 */

boolean_t rdp_func_EncodeSegment (rdp_state_info_t* info,
                                  tp_pk_t* pkt,
                                  tp_flg_t flags,
                                  tp_ser_t serial,
                                  tp_seq_t seq,
                                  tp_seq_t ack,
                                  u_short_t hedr_sze, u_byte_t* hedr_ptr,
                                  u_short_t data_sze, u_byte_t* data_ptr)

  {
    u_byte_t*   seg_ptr = tp_pk_dat_get (pkt);
    u_short_t   seg_max = tp_pk_sze_max_get (pkt);
    u_short_t   seg_sze;

    /* Check Length */
    if ((hedr_sze + data_sze + 12) > seg_max)
        return false;

    /* Encode Header */
    RDP_Segment_Encode__Flags (seg_ptr, flags);
    RDP_Segment_Encode__MBZ (seg_ptr);
    RDP_Segment_Encode__Version (seg_ptr, RDP_PKT_VERSION);
    RDP_Segment_Encode__Header_Length (seg_ptr, 12);
    RDP_Segment_Encode__Source_Port (seg_ptr, serial);
    RDP_Segment_Encode__Destination_Port (seg_ptr, 0);
    RDP_Segment_Encode__Data_Length (seg_ptr, 0);
    RDP_Segment_Encode__Sequence_Number (seg_ptr, seq);
    RDP_Segment_Encode__Acknowledgement_Number (seg_ptr, ack);
    RDP_Segment_Encode__Checksum (seg_ptr, 0);

    /* Encode Extended Header */
    if (hedr_sze > 0 && hedr_ptr != NULL)
        RDP_Segment_Encode__Extended_Header (seg_ptr, hedr_sze, hedr_ptr);

    /* Encoded Data */
    if (data_sze > 0 && data_ptr != NULL)
        RDP_Segment_Encode__Data (seg_ptr, data_sze, data_ptr);

    /* Compute & Encode Checksum */
    RDP_Segment_Decode__Segment_Size (seg_ptr, &seg_sze);
    RDP_Segment_Encode__Checksum (seg_ptr,
                                  rdp_func_ChecksumSegment (seg_sze,
                                                            seg_ptr));

    /* Set Size */
    tp_pk_sze_set (pkt, seg_sze);

    /* Succeed */
    return true;
  }

/* ------------------------------------------------------------------- */
/* Decode Segment -- decode all of the segment elements from the
 *  segment.
 */
boolean_t rdp_func_DecodeSegment (rdp_state_info_t* info,
                                  tp_pk_t* pkt,
                                  tp_flg_t* flags,
                                  tp_ser_t* serial,
                                  tp_seq_t* seq,
                                  tp_seq_t* ack,
                                  u_short_t* hedr_sze, u_byte_t* hedr_ptr,
                                  u_short_t* data_sze, u_byte_t* data_ptr)

  {
    u_byte_t*   seg_ptr = tp_pk_dat_get (pkt);
    u_short_t   seg_sze;
    u_short_t   chk;

    /* Decode, Compute and Verify Checksum */
    RDP_Segment_Decode__Checksum (seg_ptr, &chk);
    RDP_Segment_Encode__Checksum (seg_ptr, 0);
    RDP_Segment_Decode__Segment_Size (seg_ptr, &seg_sze);
    if (rdp_func_ChecksumSegment (seg_sze, seg_ptr) != chk)
        return false;

    /* Decode Header */
    if (flags != NULL)
        RDP_Segment_Decode__Flags (seg_ptr, flags);
    if (serial != NULL)
        RDP_Segment_Decode__Source_Port (seg_ptr, serial);
    if (seq != NULL)
        RDP_Segment_Decode__Sequence_Number (seg_ptr, seq);
    if (ack != NULL)
        RDP_Segment_Decode__Acknowledgement_Number (seg_ptr, ack);

    /* Decode Extended Header */
    if (hedr_sze != NULL && (*hedr_sze) > 0 && hedr_ptr != NULL)
        RDP_Segment_Decode__Extended_Header (seg_ptr, hedr_sze, hedr_ptr);

    /* Decode Data */
    if (data_sze != NULL && (*data_sze) > 0 && data_ptr != NULL)
        RDP_Segment_Decode__Data (seg_ptr, data_sze, data_ptr);

    /* Succeed */
    return true;
  }

/* ------------------------------------------------------------------- */
/* Discard Segment -- throw a segment away.
 */

boolean_t rdp_func_DiscardSegment (rdp_state_info_t* info,
                                   tp_pk_t* pkt)
  {
    /* Destroy Packet */
    tp_pk_free (pkt);

    /* Succeed */
    return true;
  }

/* ------------------------------------------------------------------- */
/* SendSegmentSYN -- send a SYN.
 */

boolean_t rdp_func_SendSegmentSYN (rdp_state_info_t* info,
                                   tp_seq_t seq,
                                   tp_seq_t max,
                                   u_short_t maxbuf,
                                   u_short_t options)
  {
    tp_pk_t* pkt;
    u_byte_t extd_header [6];
    u_byte_t* data_ptr = NULL;
    u_short_t data_sze = 0;
    u_byte_t* extd_ptr = extd_header;
    u_short_t extd_sze = 6;

#   ifdef   DEBUG_RDP
    tp_print (tp_print_debug, "RDP(%d): SendSegmentSYN (S=%d,M=%d)", 
		g_tp_copy, seq, max);
#   endif

    /* Create Packet */
    if ((pkt = tp_pk_allocate (NULL)) == NULL)
        return false;
    if (tp_pk_dat_create (pkt) == NULL)
        { tp_pk_free (pkt); return false; }
    tp_pk_dat_offset (pkt);

    /* Create Extended Header */
    extd_header [0] = max & 0xFF;                   /* Max. # of Outstanding */
    extd_header [1] = (max >> 8) & 0xFF;
    extd_header [2] = maxbuf & 0xFF;                /* Max. Segment Size */
    extd_header [3] = (maxbuf >> 8) & 0xFF;
    extd_header [4] = options & 0xFF;               /* Options Flag Field */
    extd_header [5] = (options >> 8) & 0xFF;

    /* Encode Segment */
    if (rdp_func_EncodeSegment (info,
                               pkt,                 /* Packet */
                               RDP_PKT_FLAG_SYN,    /* Flags */
                               0,                   /* Serial */
                               seq,                 /* Sequence Number */
                               0,                   /* Acknowledgement Number */
                               extd_sze, extd_ptr,  /* Extended Header */
                               data_sze, data_ptr) == false)   /* Data */
      { tp_pk_free (pkt); return false; }

    /* Deliver Segment */
    if (rdp_func_DeliverSegment (info,
                                pkt) == false)
        { tp_pk_free (pkt); return false; }

    /* Succeed */
    return true;
  }

/* ------------------------------------------------------------------- */
/* SendSegmentSYNACK -- send a SYN/ACK.
 */

boolean_t rdp_func_SendSegmentSYNACK (rdp_state_info_t* info,
                                      tp_seq_t seq,
                                      tp_seq_t ack,
                                      u_short_t max,
                                      u_short_t maxbuf,
                                      u_short_t options)
  {
    tp_pk_t* pkt;
    u_byte_t extd_header [6];
    u_byte_t* data_ptr = NULL;
    u_short_t data_sze = 0;
    u_byte_t* extd_ptr = extd_header;
    u_short_t extd_sze = 6;

#   ifdef   DEBUG_RDP
    tp_print (tp_print_debug, "RDP(%d): SendSegmentSYNACK (S=%d,A=%d,M=%d)", 
		g_tp_copy, seq, ack, max);
#	endif

    /* Create Packet */
    if ((pkt = tp_pk_allocate (NULL)) == NULL)
        return false;
    if (tp_pk_dat_create (pkt) == NULL)
        { tp_pk_free (pkt); return false; }
    tp_pk_dat_offset (pkt);

    /* Create Extended Header */
    extd_header [0] = max & 0xFF;                   /* Max. # of Outstanding */
    extd_header [1] = (max >> 8) & 0xFF;
    extd_header [2] = maxbuf & 0xFF;                /* Max. Segment Size */
    extd_header [3] = (maxbuf >> 8) & 0xFF;
    extd_header [4] = options & 0xFF;               /* Options Flag Field */
    extd_header [5] = (options >> 8) & 0xFF;

    /* Excode Segment */
    if (rdp_func_EncodeSegment (info,
                               pkt,                 /* Packet */
                               RDP_PKT_FLAG_SYN|RDP_PKT_FLAG_ACK,    /* Flags */
                               0,                   /* Serial */
                               seq,                 /* Sequence Number */
                               ack,                 /* Acknowledgement Number */
                               extd_sze, extd_ptr,      /* Extended Header */
                               data_sze, data_ptr) == false)   /* Data */
        { tp_pk_free (pkt); return false; }

    /* Deliver Segment */
    if (rdp_func_DeliverSegment (info,
                                pkt) == false)
        { tp_pk_free (pkt); return false; }

    /* Succeed */
    return true;
  }

/* ------------------------------------------------------------------- */
/* SendSegmentACK -- send a ACK.
 */

boolean_t rdp_func_SendSegmentACK (rdp_state_info_t* info,
                                   tp_seq_t seq,
                                   tp_seq_t ack,
                                   u_short_t data_sze, u_byte_t* data_ptr)
  {
    tp_pk_t* pkt;
    u_byte_t* extd_ptr = NULL;
    u_short_t extd_sze = 0;

#   ifdef   DEBUG_RDP
    tp_print (tp_print_debug, "RDP(%d): SendSegmentACK (S=%d,A=%d,L=%d)", 
		g_tp_copy, seq, ack, data_sze);
#	endif

    /* Create Packet */
    if ((pkt = tp_pk_allocate (NULL)) == NULL)
        return false;
    if (tp_pk_dat_create (pkt) == NULL)
        { tp_pk_free (pkt); return false; }
    tp_pk_dat_offset (pkt);

    /* Encode Segment */
    if (rdp_func_EncodeSegment (info,
                               pkt,                 /* Packet */
                               RDP_PKT_FLAG_ACK,    /* Flags */
                               0,                   /* Serial */
                               seq,                 /* Sequence Number */
                               ack,                 /* Acknowledgement Number */
                               extd_sze, extd_ptr,             /* Extended Header */
                               data_sze, data_ptr) == false)   /* Data */
        { tp_pk_free (pkt); return false; }

    /* Deliver Segment */
    if (rdp_func_DeliverSegment (info,
                                pkt) == false)
        { tp_pk_free (pkt); return false; }

    /* Succeed */
    return true;
  }

/* ------------------------------------------------------------------- */
/* SendSegmentEACK -- send a EACK.
 */

boolean_t rdp_func_SendSegmentEACK (rdp_state_info_t* info,
                                    tp_seq_t seq,
                                    tp_seq_t ack,
                                    int ack_cnt,
                                    tp_seq_t* ack_lst,
                                    u_short_t data_sze, u_byte_t* data_ptr)
  {
    tp_pk_t* pkt;
    u_byte_t extd_header [96];
    u_byte_t* extd_ptr = (u_byte_t*) extd_header;
    u_short_t extd_sze = 0;
    int cnt;

#   ifdef   DEBUG_RDP
    tp_print (tp_print_debug, "RDP(%d): SendSegmentEACK (S=%d,A=%d,N=%d,L=%d)",
        g_tp_copy, seq, ack, ack_cnt, data_sze);
#	endif

    /* Create Packet */
    if ((pkt = tp_pk_allocate (NULL)) == NULL)
        return false;
    if (tp_pk_dat_create (pkt) == NULL)
        { tp_pk_free (pkt); return false; }
    tp_pk_dat_offset (pkt);

    for (cnt = 0;
         cnt < ack_cnt && extd_sze < 96;
         cnt++)
      {
        RDP_Segment_Encode__Extended_Header_Acknowledgement_Number(extd_ptr, cnt, ack_lst [cnt]);
        extd_sze += 2;
      }

    /* Encode Segment */
    if (rdp_func_EncodeSegment (info,
                               pkt,                 /* Packet */
                               RDP_PKT_FLAG_ACK|RDP_PKT_FLAG_EACK,    /* Flags */
                               0,                   /* Serial */
                               seq,                 /* Sequence Number */
                               ack,                 /* Acknowledgement Number */
                               extd_sze, extd_ptr,             /* Extended Header */
                               data_sze, data_ptr) == false)   /* Data */
        { tp_pk_free (pkt); return false; }

    /* Deliver Segment */
    if (rdp_func_DeliverSegment (info,
                                pkt) == false)
        { tp_pk_free (pkt); return false; }

    /* Succeed */
    return true;
  }

/* ------------------------------------------------------------------- */
/* SendSegmentRST -- send a RST.
 */

boolean_t rdp_func_SendSegmentRST (rdp_state_info_t* info,
                                   tp_seq_t seq)
  {
    tp_pk_t* pkt;
    u_byte_t* data_ptr = NULL;
    u_short_t data_sze = 0;
    u_byte_t* extd_ptr = NULL;
    u_short_t extd_sze = 0;

#   ifdef   DEBUG_RDP
    tp_print (tp_print_debug, "RDP(%d): SendSegmentRST (S=%d)", 
		g_tp_copy, seq);
#	endif

    /* Create Packet */
    if ((pkt = tp_pk_allocate (NULL)) == NULL)
        return false;
    if (tp_pk_dat_create (pkt) == NULL)
        { tp_pk_free (pkt); return false; }
    tp_pk_dat_offset (pkt);

    /* Encode Segment */
    if (rdp_func_EncodeSegment (info,
                               pkt,                 /* Packet */
                               RDP_PKT_FLAG_RST,    /* Flags */
                               0,                   /* Serial */
                               seq,                 /* Sequence Number */
                               0,                   /* Acknowledgement Number */
                               extd_sze, extd_ptr,  /* Extended Header */
                               data_sze, data_ptr) == false)   /* Data */
        { tp_pk_free (pkt); return false; }

    /* Deliver Segment */
    if (rdp_func_DeliverSegment (info,
                                pkt) == false)
        { tp_pk_free (pkt); return false; }

    /* Succeed */
    return true;
  }

/* ------------------------------------------------------------------- */
/* SendSegmentRSTACK -- send a RST/ACK.
 */

boolean_t rdp_func_SendSegmentRSTACK (rdp_state_info_t* info,
                                      tp_seq_t seq,
                                      tp_seq_t ack)
  {
    tp_pk_t* pkt;
    u_byte_t* data_ptr = NULL;
    u_short_t data_sze = 0;
    u_byte_t* extd_ptr = NULL;
    u_short_t extd_sze = 0;

#   ifdef   DEBUG_RDP
    tp_print (tp_print_debug, "RDP(%d): SendSegmentRSTACK (S=%d,A=%d)", 
		g_tp_copy, seq, ack);
#	endif

    /* Create Packet */
    if ((pkt = tp_pk_allocate (NULL)) == NULL)
        return false;
    if (tp_pk_dat_create (pkt) == NULL)
        { tp_pk_free (pkt); return false; }
    tp_pk_dat_offset (pkt);

    /* Encode Segment */
    if (rdp_func_EncodeSegment (info,
                               pkt,                 /* Packet */
                               RDP_PKT_FLAG_RST,    /* Flags */
                               0,                   /* Serial */
                               seq,                 /* Sequence Number */
                               ack,                 /* Acknowledgement Number */
                               extd_sze, extd_ptr,  /* Extended Header */
                               data_sze, data_ptr) == false)   /* Data */
        { tp_pk_free (pkt); return false; }

    /* Deliver Segment */
    if (rdp_func_DeliverSegment (info,
                                pkt) == false)
        { tp_pk_free (pkt); return false; }

    /* Succeed */
    return true;
  }

/* ------------------------------------------------------------------- */
/* ChecksumSegment -- checksum a segment.
 */

u_short_t rdp_func_ChecksumSegment (u_short_t seg_sze,
                                    u_byte_t* seg_ptr)
  {
    return 0;
  }

/* ------------------------------------------------------------------- */
/* UpdateSegment -- extract the header from a segment.
 */

boolean_t rdp_func_UpdateSegment (rdp_state_info_t* info, tp_pk_t* pkt)
  {
    u_byte_t* seg_ptr = tp_pk_dat_get (pkt);
    u_byte_t  hedr_sze;
    u_short_t data_sze;
    u_byte_t* data_ptr;

    RDP_Segment_Decode__Header_Length (seg_ptr, &hedr_sze);
    RDP_Segment_Decode__Data_Length (seg_ptr, &data_sze);

    data_ptr = &seg_ptr [hedr_sze];

    /* Use Offset ? */
    memcpy (seg_ptr, data_ptr, data_sze);
    tp_pk_sze_set (pkt, data_sze);

    return true;
  }

/* ------------------------------------------------------------------- */

