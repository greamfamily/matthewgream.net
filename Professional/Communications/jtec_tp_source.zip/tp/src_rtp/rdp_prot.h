
#   ifndef  _RDP_PROT_H_
#   define  _RDP_PROT_H_

/* ------------------------------------------------------------------- */

#   include     "tp.h"
#   include     "tppackt.h"

/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol -- Reliable Data Protocol RFC0908
 *  Matthew Gream, April 1997
 *  $Id: rdp_prot.h,v 1.2 1997/07/22 14:49:07 matthewg Exp $
 *  $Log: rdp_prot.h,v $
 *  Revision 1.2  1997/07/22 14:49:07  matthewg
 *  Fixed an integration bug that occurred because of changes to
 *  the frame relay encapsulation routines: now, when constructing
 *  a packet, a 16 byte offset is used to leave space for the fr
 *  encapsulation routines.
 *
 *  Revision 1.1  1997/06/25 02:21:08  matthewg
 *  Added Reliable Data Protocol (RFC-0908) in place of existing
 *  protocol.
 *
 */
/*  ---------------------------------------------------------------- */

/* ------------------------------------------------------------------- */
/* Buffers */

#   define  RDP_DEFAULT_SND_MAX     (16)
#   define  RDP_DEFAULT_SBUF_MAX    (4096)

#   define  RDP_DEFAULT_RCV_MAX     (16)
#   define  RDP_DEFAULT_RBUF_MAX    (4096)

/* ------------------------------------------------------------------- */
/* Timers */

#   define  RDP_TIMER_CLOSE_WAIT    (10 SECONDS)
#   define  RDP_TIMER_RETRANSMIT    (500 MILLISECONDS)
#   define  RDP_TIMER_STATUS        (10 SECONDS)

#   define  RDP_TICK_RETRANSMIT     (2000 MILLISECONDS)
#   define  RDP_EAK_RETRANSMIT      (4)

/* ------------------------------------------------------------------- */
/* States */

typedef enum _rdp_state_t_
  {
    rdp_state_closed,
    rdp_state_listen,
    rdp_state_syn_sent,
    rdp_state_syn_rcvd,
    rdp_state_open,
    rdp_state_close_wait
  }
rdp_state_t;

/* ------------------------------------------------------------------- */
/* Connection Information */

typedef struct _rdp_state_info_t_
  {
    /* State */
    rdp_state_t state;

    /* Handlers */
    tp_pk_hnd_t lower_output_hnd;
    void*       lower_output_ctx;

    /* Send Variables */
    tp_seq_t snd_nxt;
    tp_seq_t snd_una;
    tp_seq_t snd_max;
    tp_seq_t snd_iss;

    /* Receive Variables */
    tp_seq_t rcv_cur;
    tp_seq_t rcv_max;
    tp_seq_t rcv_irs;
    tp_seq_t rcv_nxt;

    /* Other Vars */
    u_short_t eack_cnt;
    u_long_t syn_sent_tck;

    /* Buffers */
    word sbuf_max;
    word rbuf_max;

    /* Open Flags */
    boolean_t active_open;
    u_short_t options;

    /* Queues */
    tp_pk_t* rx_que_head;
    tp_pk_t* tx_que_head;

    /* Timers */
    u_long_t timer_close_wait;
    u_long_t timer_retransmit;
    u_long_t timer_status;

    /* Status */
    u_long_t rcv_stat_cnt;
    u_long_t rcv_stat_byt;
    u_long_t snd_stat_cnt;
    u_long_t snd_stat_byt;
    u_long_t snd_stat_rsnd_cnt;
    u_long_t snd_stat_rsnd_byt;

  }
rdp_state_info_t;

/* ------------------------------------------------------------------- */

/* Control Events */
boolean_t   rdp_event_OpenRequest (rdp_state_info_t* info, boolean_t active);
boolean_t   rdp_event_CloseRequest (rdp_state_info_t* info);
boolean_t   rdp_event_StatusRequest (rdp_state_info_t* info);

/* Data Events */
boolean_t   rdp_event_ReceiveRequest (rdp_state_info_t* info, tp_pk_t** pkt);
boolean_t   rdp_event_SendRequest (rdp_state_info_t* info, tp_pk_t* pkt);
boolean_t   rdp_event_SegmentArrival (rdp_state_info_t* info, tp_pk_t* pkt);

/* Timer Events */
boolean_t   rdp_event_Timeout (rdp_state_info_t* info, word tck);
boolean_t   rdp_event_RetransmissionTimeout (rdp_state_info_t* info);
boolean_t   rdp_event_CloseWaitTimeout (rdp_state_info_t* info);
boolean_t   rdp_event_StatusTimeout (rdp_state_info_t* info);

/* ------------------------------------------------------------------- */

#   endif   /*_RDP_PROT_H_*/

