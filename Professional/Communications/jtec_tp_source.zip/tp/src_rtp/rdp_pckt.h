
#   ifndef  _RDP_PCKT_H_
#   define  _RDP_PCKT_H_

/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol -- Reliable Data Protocol RFC0908
 *  Matthew Gream, April 1997
 *  $Id: rdp_pckt.h,v 1.1 1997/06/25 02:21:06 matthewg Exp $
 *  $Log: rdp_pckt.h,v $
 *  Revision 1.1  1997/06/25 02:21:06  matthewg
 *  Added Reliable Data Protocol (RFC-0908) in place of existing
 *  protocol.
 *
 */
/*  ---------------------------------------------------------------- */

/* ------------------------------------------------------------------- */

#   include     "rdp_prot.h"

/* ------------------------------------------------------------------- */
/* Control Flags */

#   define      RDP_PKT_FLAG_NULL           (0x00)
#   define      RDP_PKT_FLAG_SYN            (0x01 << 0)
#   define      RDP_PKT_FLAG_ACK            (0x01 << 1)
#   define      RDP_PKT_FLAG_EACK           (0x01 << 2)
#   define      RDP_PKT_FLAG_RST            (0x01 << 3)
#   define      RDP_PKT_FLAG_NUL            (0x01 << 4)

/* ------------------------------------------------------------------- */
/* Header / Data */

#   define      rdp_pkt_seg_hdr(pkt)        (tp_pk_dat_get (pkt))
#   define      rdp_pkt_seg_ehdr(pkt)       (&(rdp_pkt_seg_hdr (pkt) [0]))

/* ------------------------------------------------------------------- */
/* Header Fields */

#   define      rdp_pkt_seg_size(pkt)       (tp_pk_sze_get (pkt))
#   define      rdp_pkt_seg_flags(pkt)      (tp_pk_inf_flg (&(pkt)->header))
#   define      rdp_pkt_seg_seq(pkt)        (tp_pk_inf_seq (&(pkt)->header))
#   define      rdp_pkt_seg_ack(pkt)        (tp_pk_inf_ack (&(pkt)->header))

#   define      RDP_PKT_VERSION             (0x01)

/* ------------------------------------------------------------------- */
/* Extended Header Fields (SYN) */

#   define      rdp_pkt_seg_max(hdr)        ((hdr [12]) | (hdr [13] << 8))
#   define      rdp_pkt_seg_bmax(hdr)       ((hdr [14]) | (hdr [15] << 8))
#   define      rdp_pkt_seg_opts(hdr)       ((hdr [16]) | (hdr [17] << 8))

#   define      RDP_PKT_OPTION_NULL         (0x0000)
#   define      RDP_PKT_OPTION_SDM          (0x0001 << 0)
#   define      RDP_PKT_OPTION_16BITSEQ     (0x0001 << 1)
#   define      RDP_PKT_OPTION_CCITT16CHK   (0x0001 << 2)

#   define      RDP_PKT_OPTION_DEFAULT      (RDP_PKT_OPTION_SDM|RDP_PKT_OPTION_16BITSEQ|RDP_PKT_OPTION_CCITT16CHK)

/* ------------------------------------------------------------------- */
/* Extended Header Fields (EACK) */

#   define      rdp_pkt_seg_eack_cnt(hdr)   ((hdr [1]) - 6)
#   define      rdp_pkt_seg_eack_get(hdr,n) ((hdr [12 + ((n) << 1)]) | (hdr [13 + ((n) << 1)] << 8))

/* ------------------------------------------------------------------- */
/* Other Header Information */

#   define      rdp_pkt_seg_tck(pkt)        (tp_pk_tck_get (pkt))

/* ------------------------------------------------------------------- */
/* Send Segments */

boolean_t rdp_func_SendSegmentSYN (rdp_state_info_t* info, tp_seq_t seq, tp_seq_t max, u_short_t maxbuf, u_short_t options);
boolean_t rdp_func_SendSegmentSYNACK (rdp_state_info_t* info, tp_seq_t seq, tp_seq_t ack, tp_seq_t max, u_short_t maxbuf, u_short_t options);
boolean_t rdp_func_SendSegmentACK (rdp_state_info_t* info, tp_seq_t seq, tp_seq_t ack, u_short_t data_len, u_byte_t* data_ptr);
boolean_t rdp_func_SendSegmentEACK (rdp_state_info_t* info, tp_seq_t seq, tp_seq_t ack, int ack_cnt, tp_seq_t* ack_lst, u_short_t data_len, u_byte_t* data_ptr);
boolean_t rdp_func_SendSegmentRST (rdp_state_info_t* info, tp_seq_t seq);
boolean_t rdp_func_SendSegmentRSTACK (rdp_state_info_t* info, tp_seq_t seq, tp_seq_t ack);

/* ------------------------------------------------------------------- */
/* Manipulate Segments */

boolean_t rdp_func_UpdateSegment (rdp_state_info_t* info, tp_pk_t* pkt);
boolean_t rdp_func_DiscardSegment (rdp_state_info_t* info, tp_pk_t* pkt);
u_short_t rdp_func_ChecksumSegment (u_short_t seg_sze, u_byte_t* seg_ptr);

/* ------------------------------------------------------------------- */

#   endif   /*_RDP_PCKT_H_*/

