
/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol
 *  Matthew Gream, April 1997
 *  $Id: rtpproto.c,v 1.10 1997/07/22 14:49:08 matthewg Exp $
 *  $Log: rtpproto.c,v $
 *  Revision 1.10  1997/07/22 14:49:08  matthewg
 *  Fixed an integration bug that occurred because of changes to
 *  the frame relay encapsulation routines: now, when constructing
 *  a packet, a 16 byte offset is used to leave space for the fr
 *  encapsulation routines.
 *
 *  Revision 1.9  1997/06/25 02:21:11  matthewg
 *  Added Reliable Data Protocol (RFC-0908) in place of existing
 *  protocol.
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */

#   include     "rtpproto.h"
#   include     "tputlty.h"

/*  ---------------------------------------------------------------- */
/*  Create */

boolean_t tp_pr_rtp_create (void)
  {
    tp_print (tp_print_info, "Reliable Transport Protocol Enabled");
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Destroy */

boolean_t tp_pr_rtp_destroy (void)
  {
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Constructor */

boolean_t tp_pr_rtp_ctor (tp_pr_rtp_ctx* ctx)
  {
    ctx->rdp_info.state = rdp_state_closed;
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Destructor */

boolean_t tp_pr_rtp_dtor (tp_pr_rtp_ctx* ctx)
  {
    ctx->rdp_info.state = rdp_state_closed;
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Configure */

boolean_t tp_pr_rtp_config (tp_pr_rtp_ctx* ctx, MSGPTR msg)
  {
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Status */

boolean_t tp_pr_rtp_status (tp_pr_rtp_ctx* ctx)
  {
    tp_print (tp_print_none, "Proto-RTP (%08X):", ctx);

    if (rdp_event_StatusRequest (&ctx->rdp_info) == false)
        return false;

    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Connect */

boolean_t tp_pr_rtp_connect (tp_pr_rtp_ctx* ctx)
  {
    tp_print (tp_print_info, "RTP(%d): Connect", g_tp_copy);

    if (rdp_event_OpenRequest (&ctx->rdp_info, true) == false)
      {
        tp_pr_rtp_exception (ctx, "RDP Open Failed");
        return false;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Disconnect */

boolean_t tp_pr_rtp_disconnect (tp_pr_rtp_ctx* ctx)
  {
    tp_print (tp_print_info, "RTP(%d): Disconnect", g_tp_copy);

    if (rdp_event_CloseRequest (&ctx->rdp_info) == false)
        return false;

    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Exception */

boolean_t tp_pr_rtp_exception (void* ref, char* msg)
  {
    tp_pr_rtp_ctx* ctx = ref;

    tp_print (tp_print_info, "RTP(%d): Failure", g_tp_copy);

    rdp_event_CloseRequest (&ctx->rdp_info);

    if (ctx->excpt_handler == NULL)
        return false;
    if (ctx->excpt_handler (ctx->excpt_ctx, msg) == false)
        return false;

    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Set Lower */

boolean_t tp_pr_rtp_lower_set (tp_pr_rtp_ctx* ctx, tp_pk_hnd_t hnd, void* ref)
  {
    ctx->rdp_info.lower_output_hnd = hnd;
    ctx->rdp_info.lower_output_ctx = ref;
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Set Upper */

boolean_t tp_pr_rtp_upper_set (tp_pr_rtp_ctx* ctx, tp_pk_hnd_t hnd, void* ref)
  {
    ctx->upper_handler = hnd;
    ctx->upper_ctx = ref;
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Set Exception */

boolean_t tp_pr_rtp_excpt_set (tp_pr_rtp_ctx* ctx, tp_msg_hnd_t hnd, void* ref)
  {
    ctx->excpt_handler = hnd;
    ctx->excpt_ctx = ref;
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Upper Input */

boolean_t tp_pr_rtp_upper_input (void* ref, tp_pk_t* pkt)
  {
    tp_pr_rtp_ctx* ctx = ref;

    tp_print (tp_print_debug, "RTP(%d): Upper Input", g_tp_copy);

    if (rdp_event_SendRequest (&ctx->rdp_info, pkt) == false)
      {
        tp_pr_rtp_exception (ctx, "RDP Send Failed");
        return false;
      }

#   ifdef   DEBUG_PROTO_RTP_XX
    rdp_event_StatusRequest (&ctx->rdp_info);
#   endif

    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Lower Input */

boolean_t tp_pr_rtp_lower_input (void* ref, tp_pk_t* pkt)
  {
    tp_pr_rtp_ctx* ctx = ref;

    tp_print (tp_print_debug, "RTP(%d): Lower Input", g_tp_copy);

    if (rdp_event_SegmentArrival (&ctx->rdp_info, pkt) == false)
        ;

#   ifdef   DEBUG_PROTO_RTP_XX
    rdp_event_StatusRequest (&ctx->rdp_info);
#   endif

    while (rdp_event_ReceiveRequest (&ctx->rdp_info, &pkt) == true && pkt != NULL)
      {
        if (ctx->upper_handler == NULL ||
            ctx->upper_handler (ctx->upper_ctx, pkt) == false)
          {
            tp_pk_free (pkt);
          }
      }

#   ifdef   DEBUG_PROTO_RTP_XX
    rdp_event_StatusRequest (&ctx->rdp_info);
#   endif

    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Timer Input */

boolean_t tp_pr_rtp_timer_input (void* ref, word tck)
  {
    tp_pr_rtp_ctx* ctx = ref;

#   ifdef   DEBUG_PROTO_RTP
    tp_print (tp_print_debug, "RTP(%d): Timer Expiry", g_tp_copy);
#   endif

    if (rdp_event_Timeout (&ctx->rdp_info, tck) == false)
        return false;

#   ifdef   DEBUG_PROTO_RTP_XX
    rdp_event_StatusRequest (&ctx->rdp_info);
#   endif

    return true;
  }

/*  ---------------------------------------------------------------- */

