
#   ifndef      _RTP_PROTO_H_
#   define      _RTP_PROTO_H_

/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol
 *  Matthew Gream, April 1997
 *  $Id: rtpproto.h,v 1.5 1997/06/25 02:21:12 matthewg Exp $
 *  $Log: rtpproto.h,v $
 *  Revision 1.5  1997/06/25 02:21:12  matthewg
 *  Added Reliable Data Protocol (RFC-0908) in place of existing
 *  protocol.
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */

#   include     "tp.h"
#   include     "tppackt.h"

#   include     "rdp_prot.h"

/*  ---------------------------------------------------------------- */

typedef struct _tp_pr_rtp_ctx_
  {
    boolean_t           active;

    tp_msg_hnd_t        excpt_handler;
    void*               excpt_ctx;
    tp_pk_hnd_t         upper_handler;
    void*               upper_ctx;

    rdp_state_info_t    rdp_info;
  }
tp_pr_rtp_ctx;

/*  ---------------------------------------------------------------- */

boolean_t   tp_pr_rtp_create        (void);
boolean_t   tp_pr_rtp_destroy       (void);

boolean_t   tp_pr_rtp_ctor          (tp_pr_rtp_ctx* ctx);
boolean_t   tp_pr_rtp_dtor          (tp_pr_rtp_ctx* ctx);

boolean_t   tp_pr_rtp_config        (tp_pr_rtp_ctx* ctx, MSGPTR msg);
boolean_t   tp_pr_rtp_connect       (tp_pr_rtp_ctx* ctx);
boolean_t   tp_pr_rtp_disconnect    (tp_pr_rtp_ctx* ctx);
boolean_t   tp_pr_rtp_status        (tp_pr_rtp_ctx* ctx);

boolean_t   tp_pr_rtp_lower_set     (tp_pr_rtp_ctx* ctx, tp_pk_hnd_t hnd, void* ref);
boolean_t   tp_pr_rtp_upper_set     (tp_pr_rtp_ctx* ctx, tp_pk_hnd_t hnd, void* ref);
boolean_t   tp_pr_rtp_excpt_set     (tp_pr_rtp_ctx* ctx, tp_msg_hnd_t hnd, void* ref);

boolean_t   tp_pr_rtp_exception     (void* ref, char* msg);

boolean_t   tp_pr_rtp_upper_input   (void* ref, tp_pk_t* pkt);
boolean_t   tp_pr_rtp_lower_input   (void* ref, tp_pk_t* pkt);
boolean_t   tp_pr_rtp_timer_input   (void* ref, word tck);

/*  ---------------------------------------------------------------- */

#   endif       /*_RTP_PROTO_H_*/

