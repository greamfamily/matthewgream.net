
/* ------------------------------------------------------------------- */

#   include     "rdp_func.h"
#   include     "rdp_pckt.h"
#   include     "tputlty.h"

/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol -- Reliable Data Protocol RFC0908
 *  Matthew Gream, April 1997
 *  $Id: rdp_func.c,v 1.1 1997/06/25 02:21:04 matthewg Exp $
 *  $Log: rdp_func.c,v $
 *  Revision 1.1  1997/06/25 02:21:04  matthewg
 *  Added Reliable Data Protocol (RFC-0908) in place of existing
 *  protocol.
 *
 */
/*  ---------------------------------------------------------------- */

/* ------------------------------------------------------------------- */
/* InitConnectionRecord -- initialise the connection record's
 *  values to a starting state; including queues and timers.
 */
boolean_t rdp_func_InitConnectionRecord (rdp_state_info_t* info)
  {
    info->state = rdp_state_closed;

    info->snd_nxt = 0;
    info->snd_una = 0;
    info->snd_max = 0;
    info->snd_iss = 0;

    info->rcv_cur = 0;
    info->rcv_max = 0;
    info->rcv_irs = 0;
    info->rcv_nxt = 0;

    info->sbuf_max = 0;
    info->rbuf_max = 0;

    info->rcv_stat_byt = 0;
    info->rcv_stat_cnt = 0;
    info->snd_stat_byt = 0;
    info->snd_stat_cnt = 0;
    info->snd_stat_rsnd_byt = 0;
    info->snd_stat_rsnd_cnt = 0;

    if (rdp_func_StopCloseWaitTimer (info) == false)
        return false;
    if (rdp_func_StopRetransmitTimer (info) == false)
        return false;
    if (rdp_func_StopStatusTimer (info) == false)
        return false;

    if (rdp_func_RxQueueInit (info) == false)
        return false;
    if (rdp_func_TxQueueInit (info) == false)
        return false;

    return true;
  }

/* ------------------------------------------------------------------- */
/* TermConnectionRecord -- terminate the connection record's
 *  values to an ending state; including queues and timers.
 */
boolean_t rdp_func_TermConnectionRecord (rdp_state_info_t* info)
  {
    rdp_func_RxQueueTerm (info);
    rdp_func_TxQueueTerm (info);

    rdp_func_StopCloseWaitTimer (info);
    rdp_func_StopRetransmitTimer (info);
    rdp_func_StopStatusTimer (info);

    return true;
  }

/* ------------------------------------------------------------------- */
/* Print Error -- show an error to the user.
 */
boolean_t rdp_func_PrintError (rdp_state_info_t* info,
                               const char* msg)
  {
    tp_print (tp_print_warn, "RDP(%d): Error- %s", g_tp_copy, msg);
    return true;
  }

/* ------------------------------------------------------------------- */
/* Print Signal -- show a signal to the user.
 */
boolean_t rdp_func_PrintSignal (rdp_state_info_t* info,
                                const char* msg)
  {
    tp_print (tp_print_info, "RDP(%d): Info- %s", g_tp_copy, msg);
    return true;
  }

/* ------------------------------------------------------------------- */
/* Rx Queue Init -- initialise the Rx Queue.
 */
boolean_t rdp_func_RxQueueInit (rdp_state_info_t* info)
  {
    info->rx_que_head = NULL;
    return true;
  }

/* ------------------------------------------------------------------- */
/* Rx Queue Term -- terminate the Rx Queue.
 */
boolean_t rdp_func_RxQueueTerm (rdp_state_info_t* info)
  {
    tp_pk_t* pkt;
    while ((pkt = info->rx_que_head) != NULL)
      {
        info->rx_que_head = pkt->next;
        tp_pk_free (pkt);
      }
    return true;
  }

/* ------------------------------------------------------------------- */
/* Rx Queue Status -- show status for the Rx Queue.
 */
boolean_t rdp_func_RxQueueStatus (rdp_state_info_t* info)
  {
    char buffer [120];
    u_long_t cnt = 0;
    tp_pk_t* pkt;
    char* ptr = buffer;

    for (pkt = info->rx_que_head;
         pkt != NULL;
         pkt = pkt->next)
      {
        sprintf (ptr, "%d, ", rdp_pkt_seg_seq (pkt));
        while (*ptr != '\0')
            ptr++;
        cnt++;
      }
    *ptr = '\0';
    tp_print (tp_print_none, "  Rx Queue: (%d) - %s", cnt, buffer);
    return true;
  }

/* ------------------------------------------------------------------- */
/* Rx Queue Insert -- insert an item into the Rx Queue.
 */
boolean_t rdp_func_RxQueueInsert (rdp_state_info_t* info,
                                  tp_seq_t seq,
                                  tp_pk_t* pkt)
  {
    if (info->rx_que_head == NULL)
      {
        info->rx_que_head = pkt;
      }
    else
      {
        tp_pk_t* epkt = info->rx_que_head;
        while (epkt->next != NULL)
            epkt = epkt->next;
        epkt->next = pkt;
      }
    pkt->next = NULL;
    return true;
  }

/* ------------------------------------------------------------------- */
/* Rx Queue Extract -- extract an item from the Rx Queue.
 */
boolean_t rdp_func_RxQueueExtract (rdp_state_info_t* info,
                                   tp_seq_t seq,
                                   tp_pk_t** pkt)
  {
    tp_pk_t* opkt = NULL;
    for ((*pkt) = info->rx_que_head;
         (*pkt) != NULL;
         (*pkt) = (*pkt)->next)
      {
        if (rdp_pkt_seg_seq ((*pkt)) == seq)
          {
            if (opkt == NULL)
                info->rx_que_head = (*pkt)->next;
            else
                opkt->next = (*pkt)->next;
            (*pkt)->next = NULL;
            return true;
          }
        opkt = (*pkt);
      }
    return false;
  }

/* ------------------------------------------------------------------- */
/* Rx Queue Generate Ack List -- generate a list of all sequences in
 *  the queue that we will need to acknowledge.
 */
boolean_t rdp_func_RxQueueGenerateAckList (rdp_state_info_t* info,
                                           u_long_t* len,
                                           tp_seq_t* lst)
  {
    tp_pk_t* pkt = NULL;
    u_long_t cnt = 0;
    for (pkt = info->rx_que_head;
         pkt != NULL && cnt < (*len);
         pkt = pkt->next)
      {
        lst [cnt++] = rdp_pkt_seg_seq (pkt);
      }
    (*len) = cnt;
    return (cnt == 0) ? false : true;
  }

/* ------------------------------------------------------------------- */
/* Rx Queue Check -- check that an item is in the Rx Queue.
 */
boolean_t rdp_func_RxQueueCheck (rdp_state_info_t* info,
                                 tp_seq_t seq)
  {
    tp_pk_t* pkt;
    for (pkt = info->rx_que_head;
         pkt != NULL;
         pkt = pkt->next)
      {
        if (rdp_pkt_seg_seq (pkt) == seq)
            return true;
      }
    return false;
  }

/* ------------------------------------------------------------------- */
/* Tx Queue Init -- initialise the transmitter's queue.
 */
boolean_t rdp_func_TxQueueInit (rdp_state_info_t* info)
  {
    info->tx_que_head = NULL;
    return true;
  }

/* ------------------------------------------------------------------- */
/* Tx Queue Term -- terminate the transmitter's queue.
 */
boolean_t rdp_func_TxQueueTerm (rdp_state_info_t* info)
  {
    tp_pk_t* pkt;
    while ((pkt = info->tx_que_head) != NULL)
      {
        info->tx_que_head = pkt->next;
        tp_pk_free (pkt);
      }
    return true;
  }

/* ------------------------------------------------------------------- */
/* Tx Queue Status -- show status for the Tx Queue.
 */
boolean_t rdp_func_TxQueueStatus (rdp_state_info_t* info)
  {
    char buffer [120];
    u_long_t cnt = 0;
    tp_pk_t* pkt;
    char* ptr = buffer;

    for (pkt = info->tx_que_head;
         pkt != NULL;
         pkt = pkt->next)
      {
        sprintf (ptr, "%d, ", rdp_pkt_seg_seq (pkt));
        while (*ptr != '\0')
            ptr++;
        cnt++;
      }
    *ptr = '\0';
    tp_print (tp_print_none, "  Tx Queue: (%d) - %s", cnt, buffer);
    return true;
  }

/* ------------------------------------------------------------------- */
/* Tx Queue Insert -- insert an item into the transmitter's queue.
 */
boolean_t rdp_func_TxQueueInsert (rdp_state_info_t* info,
                                  tp_seq_t seq,
                                  tp_pk_t* pkt)
  {
    if (info->tx_que_head == NULL)
      {
        info->tx_que_head = pkt;
      }
    else
      {
        tp_pk_t* epkt = info->tx_que_head;
        while (epkt->next != NULL)
            epkt = epkt->next;
        epkt->next = pkt;
      }
    pkt->next = NULL;
    return true;
  }

/* ------------------------------------------------------------------- */
/* Tx Queue Extract -- extract an item from the transmitter's queue.
 */
boolean_t rdp_func_TxQueueExtract (rdp_state_info_t* info,
                                   tp_seq_t seq,
                                   tp_pk_t** pkt)
  {
    tp_pk_t* opkt = NULL;
    for ((*pkt) = info->tx_que_head;
         (*pkt) != NULL;
         (*pkt) = (*pkt)->next)
      {
        if (rdp_pkt_seg_seq ((*pkt)) == seq)
          {
            if (opkt == NULL)
                info->tx_que_head = (*pkt)->next;
            else
                opkt->next = (*pkt)->next;
            (*pkt)->next = NULL;
            return true;
          }
        opkt = (*pkt);
      }
    return false;
  }

/* ------------------------------------------------------------------- */
/* Tx Queue Read -- read an item from the transmitter's queue.
 */
boolean_t rdp_func_TxQueueRead (rdp_state_info_t* info,
                                tp_seq_t seq,
                                tp_pk_t** pkt)
  {
    for ((*pkt) = info->tx_que_head;
         (*pkt) != NULL;
         (*pkt) = (*pkt)->next)
      {
        if (rdp_pkt_seg_seq ((*pkt)) == seq)
          {
            return true;
          }
      }
    return false;
  }

/* ------------------------------------------------------------------- */
/* Tx Queue Retransmit Expiry -- cause an expiry in the retransmit
 *  queue.
 */
boolean_t rdp_func_TxQueueRetransmitExpiry (rdp_state_info_t* info,
                                            u_long_t tck,
                                            u_long_t* len,
                                            tp_seq_t* lst)

  {
    tp_pk_t* pkt = NULL;
    u_long_t cnt = 0;
    for (pkt = info->tx_que_head;
         pkt != NULL && cnt < (*len);
         pkt = pkt->next)
      {
        if (tck > rdp_pkt_seg_tck (pkt))
          {
            rdp_pkt_seg_tck (pkt) = 0;
            lst [cnt++] = rdp_pkt_seg_seq (pkt);
          }
        else
          {
            rdp_pkt_seg_tck (pkt) -= tck;
          }
      }
    (*len) = cnt;
    return (cnt == 0) ? false : true;
  }

/* ------------------------------------------------------------------- */
/* Tx Queue Prune -- prune an item for the queue.
 */
boolean_t rdp_func_TxQueuePrune (rdp_state_info_t* info, tp_seq_t seq)
  {
    tp_pk_t* pkt;
    if (rdp_func_TxQueueExtract (info, seq, &pkt) == false)
        return false;
    if (tp_pk_free (pkt) == false)
        return false;
    return true;
  }

/* ------------------------------------------------------------------- */
/* Start Close Wait Timer -- start the timer.
 */
boolean_t rdp_func_StartCloseWaitTimer (rdp_state_info_t* info)
  {
    info->timer_close_wait = RDP_TIMER_CLOSE_WAIT;
    return true;
  }

/* ------------------------------------------------------------------- */
/* Stop Close Wait Timer -- stop the timer.
 */
boolean_t rdp_func_StopCloseWaitTimer (rdp_state_info_t* info)
  {
    info->timer_close_wait = 0;
    return true;
  }

/* ------------------------------------------------------------------- */
/* Expire Close Wait Timer -- decrement and expire the timer.
 */
boolean_t rdp_func_ExpireCloseWaitTimer (rdp_state_info_t* info,
                                         u_long_t tck)
  {
    if (tck > info->timer_close_wait)
      {
        info->timer_close_wait = 0;
        return true;
      }
    info->timer_close_wait -= tck;
    return false;
  }

/* ------------------------------------------------------------------- */
/* Start Retransmit Timer -- start the timer.
 */
boolean_t rdp_func_StartRetransmitTimer (rdp_state_info_t* info)
  {
    info->timer_retransmit = RDP_TIMER_RETRANSMIT;
    return true;
  }

/* ------------------------------------------------------------------- */
/* Stop Retransmit Timer -- stop the timer.
 */
boolean_t rdp_func_StopRetransmitTimer (rdp_state_info_t* info)
  {
    info->timer_retransmit = 0;
    return true;
  }

/* ------------------------------------------------------------------- */
/* Expire Retransmit Timer -- decrement and expire the timer.
 */
boolean_t rdp_func_ExpireRetransmitTimer (rdp_state_info_t* info,
                                          u_long_t tck)
  {
    if (tck > info->timer_retransmit)
      {
        info->timer_retransmit = 0;
        return true;
      }
    info->timer_retransmit -= tck;
    return false;
  }

/* ------------------------------------------------------------------- */
/* Start Status Timer -- start the timer.
 */
boolean_t rdp_func_StartStatusTimer (rdp_state_info_t* info)
  {
    info->timer_status = RDP_TIMER_STATUS;
    return true;
  }

/* ------------------------------------------------------------------- */
/* Stop Status Timer -- stop the timer.
 */
boolean_t rdp_func_StopStatusTimer (rdp_state_info_t* info)
  {
    info->timer_status = 0;
    return true;
  }

/* ------------------------------------------------------------------- */
/* Expire Status Timer -- decrement and expire the timer.
 */
boolean_t rdp_func_ExpireStatusTimer (rdp_state_info_t* info,
                                          u_long_t tck)
  {
    if (tck > info->timer_status)
      {
        info->timer_status = 0;
        return true;
      }
    info->timer_status -= tck;
    return false;
  }

/* ------------------------------------------------------------------- */
/* Generate Random ISS -- generate a random ISS.
 */
tp_seq_t rdp_func_GenerateRandomISS (rdp_state_info_t* info)
  {
    /*
     * lcg: x(n+1) = a + [b * x(n)] mod n
     * n = 65521
     * b = 17
     * a = 3
     * x(0) = 1
     * holes: 0, 1, 2, 12285
     */
    static u_long_t  mod = 65521;
    static u_long_t  mul = 17;
    static u_long_t  off = 3;
    static u_short_t nxt = 1;

    nxt = off + (u_short_t) ((u_long_t) ((u_long_t) mul * (u_long_t) nxt) % (u_long_t) mod);

    return (tp_seq_t) nxt;
  }

/* ------------------------------------------------------------------- */

