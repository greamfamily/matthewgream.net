
#   ifndef  _RDP_FUNC_H_
#   define  _RDP_FUNC_H_

/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol -- Reliable Data Protocol RFC0908
 *  Matthew Gream, April 1997
 *  $Id: rdp_func.h,v 1.1 1997/06/25 02:21:05 matthewg Exp $
 *  $Log: rdp_func.h,v $
 *  Revision 1.1  1997/06/25 02:21:05  matthewg
 *  Added Reliable Data Protocol (RFC-0908) in place of existing
 *  protocol.
 *
 */
/*  ---------------------------------------------------------------- */

/* ------------------------------------------------------------------- */

#   include     "rdp_prot.h"

/* ------------------------------------------------------------------- */
/* Connection Records */

boolean_t rdp_func_InitConnectionRecord (rdp_state_info_t* info);
boolean_t rdp_func_TermConnectionRecord (rdp_state_info_t* info);

/* ------------------------------------------------------------------- */
/* Messages */

boolean_t rdp_func_PrintError (rdp_state_info_t* info, const char* msg);
boolean_t rdp_func_PrintSignal (rdp_state_info_t* info, const char* msg);

/* ------------------------------------------------------------------- */
/* Rx Queue */

boolean_t rdp_func_RxQueueInit (rdp_state_info_t* info);
boolean_t rdp_func_RxQueueTerm (rdp_state_info_t* info);
boolean_t rdp_func_RxQueueStatus (rdp_state_info_t* info);
boolean_t rdp_func_RxQueueInsert (rdp_state_info_t* info, tp_seq_t seq, tp_pk_t* pkt);
boolean_t rdp_func_RxQueueExtract (rdp_state_info_t* info, tp_seq_t seq, tp_pk_t** pkt);
boolean_t rdp_func_RxQueueGenerateAckList (rdp_state_info_t* info, u_long_t* len, tp_seq_t* lst);
boolean_t rdp_func_RxQueueCheck (rdp_state_info_t* info, tp_seq_t seq);

/* ------------------------------------------------------------------- */
/* Tx Queue */

boolean_t rdp_func_TxQueueInit (rdp_state_info_t* info);
boolean_t rdp_func_TxQueueTerm (rdp_state_info_t* info);
boolean_t rdp_func_TxQueueStatus (rdp_state_info_t* info);
boolean_t rdp_func_TxQueueInsert (rdp_state_info_t* info, tp_seq_t seq, tp_pk_t* pkt);
boolean_t rdp_func_TxQueueExtract (rdp_state_info_t* info, tp_seq_t seq, tp_pk_t** pkt);
boolean_t rdp_func_TxQueueRead (rdp_state_info_t* info, tp_seq_t seq, tp_pk_t** pkt);
boolean_t rdp_func_TxQueueRetransmitExpiry (rdp_state_info_t* info, u_long_t tck, u_long_t* len, tp_seq_t* lst);
boolean_t rdp_func_TxQueuePrune (rdp_state_info_t* info, tp_seq_t seq);

/* ------------------------------------------------------------------- */
/* Timers */

boolean_t rdp_func_StartCloseWaitTimer (rdp_state_info_t* info);
boolean_t rdp_func_StopCloseWaitTimer (rdp_state_info_t* info);
boolean_t rdp_func_ExpireCloseWaitTimer (rdp_state_info_t* info, u_long_t tck);

boolean_t rdp_func_StartRetransmitTimer (rdp_state_info_t* info);
boolean_t rdp_func_StopRetransmitTimer (rdp_state_info_t* info);
boolean_t rdp_func_ExpireRetransmitTimer (rdp_state_info_t* info, u_long_t tck);

boolean_t rdp_func_StartStatusTimer (rdp_state_info_t* info);
boolean_t rdp_func_StopStatusTimer (rdp_state_info_t* info);
boolean_t rdp_func_ExpireStatusTimer (rdp_state_info_t* info, u_long_t tck);

/* ------------------------------------------------------------------- */
/* Miscellaneous */

tp_seq_t rdp_func_GenerateRandomISS (rdp_state_info_t* info);

/* ------------------------------------------------------------------- */

#   endif   /*_RDP_FUNC_H_*/

