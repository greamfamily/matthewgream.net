
/* ------------------------------------------------------------------- */

#   include     "rdp_prot.h"
#   include     "rdp_func.h"
#   include     "rdp_pckt.h"
#   include     "tputlty.h"

/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol -- Reliable Data Protocol RFC0908
 *  Matthew Gream, April 1997
 *  $Id: rdp_prot.c,v 1.2 1997/07/22 14:49:06 matthewg Exp $
 *  $Log: rdp_prot.c,v $
 *  Revision 1.2  1997/07/22 14:49:06  matthewg
 *  Fixed an integration bug that occurred because of changes to
 *  the frame relay encapsulation routines: now, when constructing
 *  a packet, a 16 byte offset is used to leave space for the fr
 *  encapsulation routines.
 *
 *  Revision 1.1  1997/06/25 02:21:07  matthewg
 *  Added Reliable Data Protocol (RFC-0908) in place of existing
 *  protocol.
 *
 */
/*  ---------------------------------------------------------------- */

static const char* rdp_pkt_options (u_short_t options)
  {
    static char temp [40];
    temp [0] = '\0';
    if (options & RDP_PKT_OPTION_SDM)
        strcat (temp, "SDM ");
    if (options & RDP_PKT_OPTION_16BITSEQ)
        strcat (temp, "16BITSEQ ");
    if (options & RDP_PKT_OPTION_CCITT16CHK)
        strcat (temp, "CCITT16CHK ");
    return temp;
  }

static const char* rdp_state_name (rdp_state_t state)
  {
    switch (state)
      {
        case rdp_state_closed:
            return "closed";
        case rdp_state_listen:
            return "listen";
        case rdp_state_syn_sent:
            return "syn_sent";
        case rdp_state_syn_rcvd:
            return "syn_rcvd";
        case rdp_state_open:
            return "open";
        case rdp_state_close_wait:
            return "close_wait";
        default:
            return "???";
      }
  }

/* ------------------------------------------------------------------- */

boolean_t rdp_event_OpenRequest (rdp_state_info_t* info, boolean_t active)
  {
    /* Open Request -- Open the Connection
        Closed -- initialise the connection record,
            setup the default values, and if a passive
            open then go to the Listen state, else if
            an Active open, then send a SYN and go to
            the Syn Sent state.
     */

    switch (info->state)
      {
        case rdp_state_closed:


            /******************************************************
             * CLOSED -- Open Request                             *
             ******************************************************/

            if (rdp_func_InitConnectionRecord (info) == false)
                return false;

            info->snd_iss = rdp_func_GenerateRandomISS (info);
            info->snd_nxt = SEQ_ADD (info->snd_iss, 1);
            info->snd_una = info->snd_iss;
            info->snd_max = RDP_DEFAULT_SND_MAX;
            info->rcv_max = RDP_DEFAULT_RCV_MAX;
            info->sbuf_max = RDP_DEFAULT_SBUF_MAX;
            info->rbuf_max = RDP_DEFAULT_RBUF_MAX;
            info->active_open = active;
            info->options = RDP_PKT_OPTION_DEFAULT;
            info->eack_cnt = 0;

            rdp_func_StartStatusTimer (info);

            switch (info->active_open)
              {
                case false: /* Passive Open */

#   ifdef   DEBUG_RDP
                    tp_print (tp_print_debug, "RDP(%d): CLOSED->LISTEN: Passive Open (ISS=%d)", g_tp_copy, info->snd_iss);
#   endif
                    info->state = rdp_state_listen;
                    return true;

                case true: /* Active Open */

#   ifdef   DEBUG_RDP
                    tp_print (tp_print_debug, "RDP(%d): CLOSED->SYN_SENT: Active Open (ISS=%d)", g_tp_copy, info->snd_iss);
#   endif
                    rdp_func_SendSegmentSYN (info,
                                             info->snd_iss,
                                             info->snd_max,
                                             info->rbuf_max,
                                             info->options);
                    rdp_func_StartRetransmitTimer (info);
                    info->syn_sent_tck = RDP_TICK_RETRANSMIT;
                    info->state = rdp_state_syn_sent;
                    return true;
              }

            break;

        case rdp_state_listen:
        case rdp_state_syn_sent:
        case rdp_state_syn_rcvd:
        case rdp_state_open:
        case rdp_state_close_wait:

            rdp_func_PrintError (info, "Connection Already Open");
            return false;
      }

    return true;
  }

/* ------------------------------------------------------------------- */

boolean_t rdp_event_CloseRequest (rdp_state_info_t* info)
  {
    /* Close Request -- Close the Connection
        Open -- send an RST and go to the Close Wait state,
            starting the Close Wait Timer.
        Listen -- go to the Closed state and terminate
            the connection record.
        Syn Recv, Syn Sent -- go to the Closed state and
            and send back an RST.
        Else -- show an error!
     */

    switch (info->state)
      {
        case rdp_state_open:


            /******************************************************
             * OPEN -- Close Request                              *
             ******************************************************/

#   ifdef   DEBUG_RDP
            tp_print (tp_print_debug, "RDP(%d): OPEN->CLOSE_WAIT: Close", g_tp_copy);
#   endif
            rdp_func_SendSegmentRST (info,
                                     info->snd_nxt);
            rdp_func_StartCloseWaitTimer (info);
            info->state = rdp_state_close_wait;
            return true;


        case rdp_state_listen:


            /******************************************************
             * LISTEN -- Close Request                            *
             ******************************************************/

#   ifdef   DEBUG_RDP
            tp_print (tp_print_debug, "RDP(%d): LISTEN->CLOSED: Close", g_tp_copy);
#   endif
            rdp_func_TermConnectionRecord (info);
            info->state = rdp_state_closed;
            return true;


        case rdp_state_syn_rcvd:
        case rdp_state_syn_sent:


            /******************************************************
             * SYN RCVD / SYN SENT -- Close Request               *
             ******************************************************/

#   ifdef   DEBUG_RDP
            tp_print (tp_print_debug, "RDP(%d): SYN_SENT/RCVD->CLOSED: Close", g_tp_copy);
#   endif
            rdp_func_SendSegmentRST (info,
                                     info->snd_nxt);
            rdp_func_TermConnectionRecord (info);
            info->state = rdp_state_closed;
            return true;


        case rdp_state_close_wait:

            rdp_func_PrintError (info, "Connection Closing");
            return false;


        case rdp_state_closed:

            rdp_func_PrintError (info, "Connection Not Open");
            return false;
      }

    return true;
  }

/* ------------------------------------------------------------------- */

boolean_t rdp_event_ReceiveRequest (rdp_state_info_t* info, tp_pk_t** pkt)
  {
    /* Receive Request -- Upper wants to Receive some Data
        Open -- try to extract from the queue with the
            current Rcv Nxt sequence, and if so then do an
            increment of the Rcv Nxt.
     */

    switch (info->state)
      {
        case rdp_state_open:


            /******************************************************
             * OPEN -- Receive Request                            *
             ******************************************************/

            if (rdp_func_RxQueueExtract (info,
                                         info->rcv_nxt,
                                         pkt) == false)
                return false;

#   ifdef   DEBUG_RDP
            tp_print (tp_print_debug, "RDP(%d): OPEN: Receive (Seq=%d)", g_tp_copy, info->rcv_nxt);
#   endif
            info->rcv_stat_byt += tp_pk_sze_get ((*pkt));
            info->rcv_stat_cnt ++;
            info->rcv_nxt = SEQ_ADD (info->rcv_nxt, 1);
            return true;

        case rdp_state_listen:
        case rdp_state_syn_rcvd:
        case rdp_state_syn_sent:

            return false;

        case rdp_state_closed:
        case rdp_state_close_wait:

            rdp_func_PrintError (info, "Connection Not Open");
            return false;
      }

    return true;
  }

/* ------------------------------------------------------------------- */

boolean_t rdp_event_SendRequest (rdp_state_info_t* info, tp_pk_t* pkt)
  {
    /* Send Request -- Send Data on the Connection.
        Open -- check if room for the packet, and if so then
            put packet into TxQueue and and update Snd Nxt,
            then send the packet with an ACK.
        Listen, Syn Recv, Syn Sent -- if there is room, put
            into the Tx Queue without sending.
     */

    switch (info->state)
      {
        case rdp_state_open:


            /******************************************************
             * OPEN -- Send Request                               *
             ******************************************************/

#   ifdef   DEBUG_RDP
            tp_print (tp_print_debug, "RDP(%d): OPEN: Send (Seq=%d)", g_tp_copy, info->snd_nxt);
#   endif
            if (SEQ_RNG (info->snd_una,
                         SEQ_ADD (info->snd_una, info->snd_max),
                         info->snd_nxt))
              {
                rdp_pkt_seg_tck (pkt) = RDP_TICK_RETRANSMIT;
                rdp_pkt_seg_seq (pkt) = info->snd_nxt;

                if (rdp_func_TxQueueInsert (info,
                                            info->snd_nxt,
                                            pkt) == false)
                    return false;

                if (rdp_func_SendSegmentACK (info,
                                             info->snd_nxt,
                                             info->rcv_cur,
                                             tp_pk_sze_get (pkt), tp_pk_dat_get (pkt)) == true)
                  {
                    info->snd_stat_byt += tp_pk_sze_get (pkt);
                    info->snd_stat_cnt ++;
                  }

                info->snd_nxt = SEQ_ADD (info->snd_nxt, 1);

                return true;
              }
            else
              {
                rdp_func_PrintError (info, "Insufficient Resources to Send Data");
                return false;
              }
            break;


        case rdp_state_syn_rcvd:
        case rdp_state_syn_sent:
        case rdp_state_listen:


            /******************************************************
             * SYN RCVD / SYN SENT / LISTEN -- Send Request       *
             ******************************************************/

#   ifdef   DEBUG_RDP
            tp_print (tp_print_debug, "RDP(%d): SYN_RCVD/SYN_SENT/LISTEN: Send (Seq=%d)", g_tp_copy, info->snd_nxt);
#   endif
            if (SEQ_RNG (info->snd_una,
                         SEQ_ADD (info->snd_una, info->snd_max),
                         info->snd_nxt))
              {

                rdp_pkt_seg_tck (pkt) = RDP_TICK_RETRANSMIT;
                rdp_pkt_seg_seq (pkt) = info->snd_nxt;

                if (rdp_func_TxQueueInsert (info,
                                            info->snd_nxt,
                                            pkt) == false)
                    return false;

                info->snd_nxt = SEQ_ADD (info->snd_nxt, 1);

                return true;
              }
            else
              {
                rdp_func_PrintError (info, "Insufficient Resources to Send Data");
                return false;
              }
            break;


        case rdp_state_closed:
        case rdp_state_close_wait:

            rdp_func_PrintError (info, "Connection Not Open");
            return false;
      }

    return true;
  }

/* ------------------------------------------------------------------- */

boolean_t rdp_event_StatusRequest (rdp_state_info_t* info)
  {
    /* Status Request -- show information about the Connection.
        All -- get status.
     */

    switch (info->state)
      {
        case rdp_state_closed:
        case rdp_state_listen:
        case rdp_state_syn_sent:
        case rdp_state_syn_rcvd:
        case rdp_state_open:
        case rdp_state_close_wait:


            /******************************************************
             * * -- Status Request                                *
             ******************************************************/

            tp_print (tp_print_none, "RDP(%d): Status", g_tp_copy);
            tp_print (tp_print_none, "  State: %s",
                rdp_state_name (info->state));
            tp_print (tp_print_none, "  Send Window: ISS=%d, Max=%d, Next=%d, Unack=%d",
                info->snd_iss, info->snd_max, info->snd_nxt, info->snd_una);
            tp_print (tp_print_none, "  Recv Window: IRS=%d, Max=%d, Next=%d, Curnt=%d",
                info->rcv_irs, info->rcv_max, info->rcv_nxt, info->rcv_cur);
            tp_print (tp_print_none, "  Buffers: Send=%d, Recv=%d",
                info->sbuf_max, info->rbuf_max);
            tp_print (tp_print_none, "  Open Mode: %s",
                (info->active_open == true) ? "Active" : "Passive");
            tp_print (tp_print_none, "  Timers: CloseWait=%d, Retransmit=%d, Status=%d, SynSent=%d",
                info->timer_close_wait, info->timer_retransmit, info->timer_status, info->syn_sent_tck);
            rdp_func_TxQueueStatus (info);
            rdp_func_RxQueueStatus (info);
            tp_print (tp_print_none, "  Send Stat: Pkt=%d, Byt=%d",
                info->snd_stat_cnt, info->snd_stat_byt);
            tp_print (tp_print_none, "  Recv Stat: Pkt=%d, Byt=%d",
                info->rcv_stat_cnt, info->rcv_stat_byt);
            tp_print (tp_print_none, "  Retx Stat: Pkt=%d, Byt=%d",
                info->snd_stat_rsnd_cnt, info->snd_stat_rsnd_byt);

            return true;
      }

    return true;
  }

/* ------------------------------------------------------------------- */

boolean_t rdp_event_SegmentArrival (rdp_state_info_t* info, tp_pk_t* pkt)
  {
    /* Segment Arrival -- process the arrival of a Segment.
        Closed -- reply with RST or RST/ACK depending on the
            packet, discard all others.
        Close Wait -- transfer to the Closed state when we
            get a RST, discard all others.
        Listen -- transfer to the Syn Rcvd state when we
            get a SYN, discard RSTs, and deliver RSTs upon
            receipt of ACK/NULs.
        Syn Sent -- transfer to the Open state when we get
            a SYN/ACK (and reply with a ACK), transfer to
            the Syn Rcvd state when we get a SYN (and reply
            with a SYN/ACK), transfer to the Closed state
            when we get a RST, and send an RST in reply to
            an ACK. Discard others.
        Syn Rcvd -- If the packet is not in range, reply
            with an ACK. If an RST, then go back to Listen
            state if we are passive, or Closed state if we
            are active opens. If a SYN, then reply with a
            RST and goto Closed state. If an EACK, then
            send an RST. If an ACK matching the ISS, then
            go Open, otherwise send back an RST. Finally,
            if was ACK with ISS going to Open, then put
            data in buffer and reply with ACK.
        Open -- If packet is not in range, reply with an
            ACK. If an RST, goto Close Wait state. If a
            NUL, then deliver an ACK. If a SYN, then
            send back an RST and goto Closed state. If
            an ACK, then prune the Queue, same deal if
            an EACK. Finally, if data, then extract and
            put data into Recv buffers and send either
            an ACK or EACK. Discard all others.
     */

    if (rdp_func_DecodeSegment (info,
                                pkt,
                                & rdp_pkt_seg_flags (pkt),
                                NULL,
                                & rdp_pkt_seg_seq (pkt),
                                & rdp_pkt_seg_ack (pkt),
                                NULL, NULL,
                                NULL, NULL) == false)
      {
#   ifdef   DEBUG_RDP
        tp_print (tp_print_debug, "RDP(%d): SegArrival: Invalid Segment", g_tp_copy);
#   endif
        return false;
      }

    switch (info->state)
      {
        case rdp_state_closed:


            /******************************************************
             * CLOSED -- Segment RST                              *
             ******************************************************/

            if ((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_RST)) == (RDP_PKT_FLAG_RST))
              {
#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): CLOSED: Receive RST (Seq=%d,Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif
                rdp_func_DiscardSegment (info,
                                         pkt);
                return true;
              }


            /******************************************************
             * CLOSED -- Segment ACK                              *
             ******************************************************/

            if ((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_ACK)) == (RDP_PKT_FLAG_ACK))
              {
#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): CLOSED: Receive ACK (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif
                rdp_func_SendSegmentRST (info,
                                         SEQ_ADD (rdp_pkt_seg_ack (pkt), 1));
                rdp_func_DiscardSegment (info,
                                         pkt);
                return true;
              }


            /******************************************************
             * CLOSED -- Segment *                                *
             ******************************************************/

              {
#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): CLOSED: Receive ??? (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif
                rdp_func_SendSegmentRSTACK (info,
                                            0,
                                            info->rcv_cur);
                rdp_func_DiscardSegment (info,
                                         pkt);
                return true;
              }


        case rdp_state_close_wait:


            /******************************************************
             * CLOSE WAIT -- Segment RST                          *
             ******************************************************/

            if ((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_RST)) == (RDP_PKT_FLAG_RST))
              {
#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): CLOSE_WAIT->CLOSED: Receive RST (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif
                rdp_func_StopCloseWaitTimer (info);
                rdp_func_DiscardSegment (info,
                                         pkt);
                rdp_func_TermConnectionRecord (info);
                info->state = rdp_state_closed;
                return true;
              }


            /******************************************************
             * CLOSE WAIT -- Segment *                            *
             ******************************************************/

              {
#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): CLOSE_WAIT: Receive ??? (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif
                rdp_func_DiscardSegment (info,
                                         pkt);
                return true;
              }


        case rdp_state_listen:


            /******************************************************
             * LISTEN -- Segment RST                              *
             ******************************************************/

            if ((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_RST)) == (RDP_PKT_FLAG_RST))
              {
#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): LISTEN: Receive RST (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif
                rdp_func_DiscardSegment (info,
                                         pkt);
                return true;
              }


            /******************************************************
             * LISTEN -- Segment ACK                              *
             ******************************************************/

            if ((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_ACK)) == (RDP_PKT_FLAG_ACK))
              {
#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): LISTEN: Receive ACK (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif
                rdp_func_SendSegmentRST (info,
                                         SEQ_ADD (rdp_pkt_seg_ack (pkt), 1));
                rdp_func_DiscardSegment (info,
                                         pkt);
                return true;
              }


            /******************************************************
             * LISTEN -- Segment SYN                              *
             ******************************************************/

            if ((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_SYN)) == (RDP_PKT_FLAG_SYN))
              {
#   if defined (DEBUG_RDP) || 1
                tp_print (tp_print_debug, "RDP(%d): LISTEN->SYN_RCVD: Receive SYN (Seq=%d, Ack=%d, Max=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt), rdp_pkt_seg_max (rdp_pkt_seg_ehdr (pkt)));
                tp_print (tp_print_debug, "RDP(%d):   Options: %s", g_tp_copy, rdp_pkt_options (info->options));
#   endif
                if (rdp_pkt_seg_opts (rdp_pkt_seg_ehdr (pkt)) != info->options)
                  {
                    tp_print (tp_print_warn, "RDP(%d): LISTEN: Incompatible Options: Sending RST|ACK", g_tp_copy);
                    rdp_func_SendSegmentRSTACK (info,
                                                0,
                                                info->rcv_cur);
                    rdp_func_DiscardSegment (info,
                                             pkt);
                    return true;
                  }

                info->rcv_irs = rdp_pkt_seg_seq (pkt);
                info->rcv_cur = info->rcv_irs;
                info->rcv_nxt = SEQ_ADD (info->rcv_irs, 1);
                info->snd_max = rdp_pkt_seg_max (rdp_pkt_seg_ehdr (pkt));
                info->sbuf_max = rdp_pkt_seg_bmax (rdp_pkt_seg_ehdr (pkt));
                rdp_func_SendSegmentSYNACK (info,
                                            info->snd_iss,
                                            info->rcv_cur,
                                            info->rcv_max,
                                            info->rbuf_max,
                                            info->options);
                rdp_func_DiscardSegment (info,
                                         pkt);
                info->state = rdp_state_syn_rcvd;
                return true;
              }


            /******************************************************
             * LISTEN -- Segment *                                *
             ******************************************************/

              {
#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): LISTEN: Receive ??? (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif
                rdp_func_DiscardSegment (info,
                                         pkt);
                return true;
              }


        case rdp_state_syn_sent:


            /******************************************************
             * SYN SENT -- Segment ACK & ~ISS                     *
             ******************************************************/

            if (((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_ACK)) == (RDP_PKT_FLAG_ACK)) && rdp_pkt_seg_ack (pkt) != info->snd_iss)
              {
#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): SYN_SENT: Receive ACK [out of order] (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif
                rdp_func_SendSegmentRST (info,
                                         SEQ_ADD (rdp_pkt_seg_ack (pkt), 1));
                rdp_func_DiscardSegment (info,
                                         pkt);
                return true;
              }


            /******************************************************
             * SYN SENT -- Segment RST/ACK                        *
             ******************************************************/

            if ((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_RST|RDP_PKT_FLAG_ACK)) == (RDP_PKT_FLAG_RST|RDP_PKT_FLAG_ACK))
              {
#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): SYN_SENT: Receive RST|ACK (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif
                rdp_func_PrintSignal (info, "Connection Refused");
                rdp_func_TermConnectionRecord (info);
                rdp_func_DiscardSegment (info,
                                         pkt);
                info->state = rdp_state_closed;
                return true;
              }


            /******************************************************
             * SYN SENT -- Segment RST                            *
             ******************************************************/

            if ((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_RST)) == (RDP_PKT_FLAG_RST))
              {
#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): SYN_SENT: Receive RST (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif
                rdp_func_DiscardSegment (info,
                                         pkt);
                return true;
              }


            /******************************************************
             * SYN SENT -- Segment SYN/ACK                        *
             ******************************************************/

            if ((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_SYN|RDP_PKT_FLAG_ACK)) == (RDP_PKT_FLAG_SYN|RDP_PKT_FLAG_ACK))
              {
                tp_seq_t seq;
                u_long_t cnt = 0;

                if (rdp_pkt_seg_opts (rdp_pkt_seg_ehdr (pkt)) != info->options)
                  {
                    tp_print (tp_print_warn, "RDP(%d): SYN_SENT: Incompatible Options: Sending RST|ACK", g_tp_copy);
                    rdp_func_SendSegmentRSTACK (info,
                                                0,
                                                info->rcv_cur);
                    rdp_func_TermConnectionRecord (info);
                    rdp_func_DiscardSegment (info,
                                             pkt);
                    info->state = rdp_state_closed;
                    return true;
                  }

#   if  defined(DEBUG_RDP) || 1
                tp_print (tp_print_debug, "RDP(%d): SYN_SENT->OPEN: Receive SYN|ACK (Seq=%d, Ack=%d, Max=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt), rdp_pkt_seg_max (rdp_pkt_seg_ehdr (pkt)));
                tp_print (tp_print_debug, "RDP(%d):   Options: %s", g_tp_copy, rdp_pkt_options (info->options));
#   endif

                info->rcv_irs = rdp_pkt_seg_seq (pkt);
                info->rcv_cur = info->rcv_irs;
                info->rcv_nxt = SEQ_ADD (info->rcv_irs, 1);
                info->snd_max = rdp_pkt_seg_max (rdp_pkt_seg_ehdr (pkt));
                info->sbuf_max = rdp_pkt_seg_bmax (rdp_pkt_seg_ehdr (pkt));

                info->snd_una = rdp_pkt_seg_ack (pkt);
                info->state = rdp_state_open;

                for (seq = info->snd_una;
                     seq != info->snd_nxt;
                     SEQ_INC (seq))
                  {
                    tp_pk_t* pkt;
                    if (rdp_func_TxQueueRead (info,
                                              seq,
                                              &pkt) == true)
                      {
                        if (rdp_func_SendSegmentACK (info,
                                                     rdp_pkt_seg_seq (pkt),
                                                     info->rcv_cur,
                                                     tp_pk_sze_get (pkt), tp_pk_dat_get (pkt)) == true)
                          {
                            info->snd_stat_byt += tp_pk_sze_get (pkt);
                            info->snd_stat_cnt ++;
                          }
                        cnt++;
                      }
                  }

                if (cnt == 0)
                  {
                    rdp_func_SendSegmentACK (info,
                                             info->snd_nxt,
                                             info->rcv_cur,
                                             0, NULL);
                  }

                rdp_func_DiscardSegment (info,
                                         pkt);
                return true;
              }


            /******************************************************
             * SYN SENT -- Segment SYN                            *
             ******************************************************/

            if ((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_SYN)) == (RDP_PKT_FLAG_SYN))
              {
                if (rdp_pkt_seg_opts (rdp_pkt_seg_ehdr (pkt)) != info->options)
                  {
                    tp_print (tp_print_warn, "RDP(%d): SYN_SENT: Incompatible Options: Sending RST|ACK", g_tp_copy);
                    rdp_func_SendSegmentRSTACK (info,
                                                0,
                                                info->rcv_cur);
                    rdp_func_TermConnectionRecord (info);
                    rdp_func_DiscardSegment (info,
                                             pkt);
                    info->state = rdp_state_closed;
                    return true;
                  }

#   if defined (DEBUG_RDP) || 1
                    tp_print (tp_print_debug, "RDP(%d): SYN_SENT->SYN_RCVD: Receive SYN (Seq=%d, Ack=%d, Max=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt), rdp_pkt_seg_max (rdp_pkt_seg_ehdr (pkt)));
                    tp_print (tp_print_debug, "RDP(%d):   Options: %s", g_tp_copy, rdp_pkt_options (info->options));
#   endif

                info->rcv_irs = rdp_pkt_seg_seq (pkt);
                info->rcv_cur = info->rcv_irs;
                info->rcv_nxt = SEQ_ADD (info->rcv_irs, 1);
                info->snd_max = rdp_pkt_seg_max (rdp_pkt_seg_ehdr (pkt));
                info->sbuf_max = rdp_pkt_seg_bmax (rdp_pkt_seg_ehdr (pkt));

                info->state = rdp_state_syn_rcvd;
                rdp_func_SendSegmentSYNACK (info,
                                            info->snd_iss,
                                            info->rcv_cur,
                                            info->rcv_max,
                                            info->rbuf_max,
                                            info->options);

                rdp_func_DiscardSegment (info,
                                         pkt);
                return true;
              }


            /******************************************************
             * SYN SENT -- Segment *                              *
             ******************************************************/

              {
#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): SYN_SENT: Receive ??? (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif
                rdp_func_DiscardSegment (info,
                                         pkt);
                return true;
              }


        case rdp_state_syn_rcvd:


            /******************************************************
             * SYN RCVD -- Segment Check                          *
             ******************************************************/

            if (SEQ_RNG (info->rcv_irs,
                         SEQ_ADD (info->rcv_cur, (info->rcv_max * 2)),
                         rdp_pkt_seg_seq (pkt)))
              {
                /* OK */
              }
            else
              {
#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): SYN_RCVD: Receive Out of Order (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif

                rdp_func_SendSegmentACK (info,
                                         info->snd_nxt,
                                         info->rcv_cur,
                                         0, NULL);
                rdp_func_DiscardSegment (info,
                                         pkt);
                return true;
              }


            /******************************************************
             * SYN RCVD -- Segment RST                            *
             ******************************************************/

            if ((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_RST)) == (RDP_PKT_FLAG_RST))
              {
                if (info->active_open == false)
                  {
#   if defined (DEBUG_RDP) || 1
                    tp_print (tp_print_debug, "RDP(%d): SYN_RCVD->LISTEN: Receive RST (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif

                    rdp_func_DiscardSegment (info,
                                             pkt);
                    info->state = rdp_state_listen;
                    return true;
                  }
                else
                  {
#   if defined (DEBUG_RDP) || 1
                    tp_print (tp_print_debug, "RDP(%d): SYN_RCVD->CLOSED: Receive RST (Seq=%d, Ack=%d, Max=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif
                    rdp_func_PrintSignal (info, "Connection Refused");
                    rdp_func_DiscardSegment (info,
                                             pkt);
                    rdp_func_TermConnectionRecord (info);
                    info->state = rdp_state_closed;
                    return true;
                  }
              }


            /******************************************************
             * SYN RCVD -- Segment SYN/~ACK                       *
             ******************************************************/

            if (((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_SYN)) == (RDP_PKT_FLAG_SYN)) && !((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_ACK)) == (RDP_PKT_FLAG_ACK)))
              {
#   if defined(DEBUG_RDP) || 1
                tp_print (tp_print_debug, "RDP(%d): SYN_RCVD->CLOSED: Receive SYN (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif

                rdp_func_SendSegmentRST (info,
                                         SEQ_ADD (rdp_pkt_seg_ack (pkt), 1));
                rdp_func_PrintSignal (info, "Connection Reset");
                rdp_func_DiscardSegment (info,
                                         pkt);
                rdp_func_TermConnectionRecord (info);
                info->state = rdp_state_closed;
                return true;
              }


            /******************************************************
             * SYN RCVD -- Segment EACK                           *
             ******************************************************/

            if ((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_EACK)) == (RDP_PKT_FLAG_EACK))
              {
#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): SYN_RCVD: Receive EACK (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif
                rdp_func_SendSegmentRST (info,
                                         SEQ_ADD (rdp_pkt_seg_ack (pkt), 1));
                rdp_func_DiscardSegment (info,
                                         pkt);
                return true;
              }


            /******************************************************
             * SYN RCVD -- Segment ACK                            *
             ******************************************************/

            if ((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_ACK)) == (RDP_PKT_FLAG_ACK))
              {
                if (rdp_pkt_seg_ack (pkt) == info->snd_iss)
                  {
                    tp_seq_t seq;
                    u_long_t cnt = 0;

#   if defined (DEBUG_RDP) || 1
                    tp_print (tp_print_debug, "RDP(%d): SYN_RCVD->OPEN: Receive ACK [in order] (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif

                    info->state = rdp_state_open;

                    for (seq = info->snd_una;
                         seq != info->snd_nxt;
                         SEQ_INC (seq))
                      {
                        tp_pk_t* pkt;
                        if (rdp_func_TxQueueRead (info,
                                                  seq,
                                                  &pkt) == true)
                          {
                            if (rdp_func_SendSegmentACK (info,
                                                         rdp_pkt_seg_seq (pkt),
                                                         info->rcv_cur,
                                                         tp_pk_sze_get (pkt), tp_pk_dat_get (pkt)) == true)
                              {
                                info->snd_stat_byt += tp_pk_sze_get (pkt);
                                info->snd_stat_cnt ++;
                              }
                            cnt++;
                          }
                      }

                    if (cnt == 0)
                      {
                        rdp_func_SendSegmentACK (info,
                                                 info->snd_nxt,
                                                 info->rcv_cur,
                                                 0, NULL);
                      }
                  }
                else
                  {

#   ifdef   DEBUG_RDP
                    tp_print (tp_print_debug, "RDP(%d): SYN_RCVD: Receive ACK [out of order] (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif

                    rdp_func_SendSegmentRST (info,
                                             SEQ_ADD (rdp_pkt_seg_ack (pkt), 1));
                    rdp_func_DiscardSegment (info,
                                             pkt);
                    return true;
                  }
              }
            else
              {
                rdp_func_DiscardSegment (info,
                                         pkt);
                return true;
              }


            /******************************************************
             * SYN RCVD -- Segment Data                           *
             ******************************************************/

            rdp_func_UpdateSegment (info,
                                    pkt);

            if (rdp_pkt_seg_size (pkt) > 0)
              {
                rdp_func_RxQueueInsert (info,
                                        rdp_pkt_seg_seq (pkt),
                                        pkt);
                info->rcv_stat_byt += tp_pk_sze_get (pkt);
                info->rcv_stat_cnt ++;

                if (SEQ_ADD (info->rcv_cur, 1) == rdp_pkt_seg_seq (pkt))
                  {
#   if defined (DEBUG_RDP) || 1
                    tp_print (tp_print_debug, "RDP(%d): SYN_RCVD: Receive Data [in order] (Seq=%d, Ack=%d, Len=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt), rdp_pkt_seg_size (pkt));
#   endif

                    while (rdp_func_RxQueueCheck (info, SEQ_ADD (info->rcv_cur, 1)) == true)
                      {
                        SEQ_INC (info->rcv_cur);
                      }

                    rdp_func_SendSegmentACK (info,
                                             info->snd_nxt,
                                             info->rcv_cur,
                                             0, NULL);
                    return true;
                  }
                else
                  {
                    u_long_t len = 32;
                    tp_seq_t lst [32];
#   if defined(DEBUG_RDP) || 1
                    tp_print (tp_print_debug, "RDP(%d): SYN_RCVD: Receive Data [out of order] (Seq=%d, Ack=%d, Len=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt), rdp_pkt_seg_size (pkt));
#   endif
                    if (rdp_func_RxQueueGenerateAckList (info,
                                                         &len,
                                                         lst) == true)
                      {

                        while (rdp_func_RxQueueCheck (info, SEQ_ADD (info->rcv_cur, 1)) == true)
                          {
                            SEQ_INC (info->rcv_cur);
                          }

                        rdp_func_SendSegmentEACK (info,
                                                  info->snd_nxt,
                                                  info->rcv_cur,
                                                  len,
                                                  lst,
                                                  0, NULL);
                      }
                    else
                      {

                        while (rdp_func_RxQueueCheck (info, SEQ_ADD (info->rcv_cur, 1)) == true)
                          {
                            SEQ_INC (info->rcv_cur);
                          }

                        rdp_func_SendSegmentACK (info,
                                                 info->snd_nxt,
                                                 info->rcv_cur,
                                                 0, NULL);
                      }

                    return true;
                  }
              }


            /******************************************************
             * SYN RCVD -- Segment *                              *
             ******************************************************/

            rdp_func_DiscardSegment (info,
                                     pkt);
            return true;


        case rdp_state_open:


            /******************************************************
             * OPEN -- Segment Check                              *
             ******************************************************/

            if (SEQ_RNG (info->rcv_cur,
                         SEQ_ADD (info->rcv_cur, (info->rcv_max * 2)),
                         rdp_pkt_seg_seq (pkt)))
              {
                /* OK */
              }
            else
              {
#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): OPEN: Receive Out of Order (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif

                rdp_func_SendSegmentACK (info,
                                         info->snd_nxt,
                                         info->rcv_cur,
                                         0, NULL);
                rdp_func_DiscardSegment (info,
                                         pkt);
                return true;
              }


            /******************************************************
             * OPEN -- Segment RST                                *
             ******************************************************/

            if ((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_RST)) == (RDP_PKT_FLAG_RST))
              {
#   if defined(DEBUG_RDP) || 1
                tp_print (tp_print_debug, "RDP(%d): OPEN->CLOSE_WAIT: Receive RST (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif

                rdp_func_PrintSignal (info, "Connection Reset");
                rdp_func_DiscardSegment (info,
                                         pkt);
                info->state = rdp_state_close_wait;
                return true;
              }


            /******************************************************
             * OPEN -- Segment SYN                                *
             ******************************************************/

            if ((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_SYN)) == (RDP_PKT_FLAG_SYN))
              {
#   if  0
#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): OPEN->CLOSED: Receive SYN (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif

                rdp_func_SendSegmentRST (info,
                                         SEQ_ADD (rdp_pkt_seg_ack (pkt), 1));
                rdp_func_PrintSignal (info, "Connection Reset");
#   endif
                rdp_func_DiscardSegment (info,
                                         pkt);
#   if  0
                rdp_func_TermConnectionRecord (info);
                info->state = rdp_state_closed;
#   endif
                return true;
              }


            /******************************************************
             * OPEN -- Segment ACK                                *
             ******************************************************/

            if ((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_ACK)) == (RDP_PKT_FLAG_ACK))
              {
#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): OPEN: Receive ACK (Seq=%d, Ack=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt));
#   endif

                if (SEQ_RNG (info->snd_una,
                             info->snd_nxt,
                             rdp_pkt_seg_ack (pkt)))
                  {
                    tp_seq_t seq = info->snd_una;

                    if (!((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_EACK)) == (RDP_PKT_FLAG_EACK)) &&
                        SEQ_ADD (info->snd_una, 1) == rdp_pkt_seg_ack (pkt))
                      {
#   ifdef   DEBUG_RDP
                        tp_print (tp_print_debug, "RDP(%d): OPEN: Reset EACK Count", g_tp_copy);
#   endif
                        info->eack_cnt = 0;
                      }

                    info->snd_una = rdp_pkt_seg_ack (pkt);

                    while (seq != SEQ_ADD (info->snd_una, 1))
                      {
                        if (rdp_func_TxQueuePrune (info, seq) == true)
                          {
#   ifdef   DEBUG_RDP
                            tp_print (tp_print_debug, "RDP(%d): OPEN: Prune TxQueue (Seq=%d)", g_tp_copy, seq);
#   endif
                          }
                        SEQ_INC (seq);
                      }
                  }
              }


            /******************************************************
             * OPEN -- Segment EACK                               *
             ******************************************************/

            if ((rdp_pkt_seg_flags (pkt) & (RDP_PKT_FLAG_EACK)) == (RDP_PKT_FLAG_EACK))
              {
#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): OPEN: Receive EACK (Seq=%d, Ack=%d, Cnt=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt), rdp_pkt_seg_eack_cnt (rdp_pkt_seg_ehdr (pkt)));
#   endif
                info->eack_cnt++;
#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): OPEN: Update EACK Count (%d)", g_tp_copy, info->eack_cnt);
#   endif
                if (rdp_pkt_seg_eack_cnt (rdp_pkt_seg_ehdr (pkt)) > 0)
                  {
                    int cnt;
                    for (cnt = 0;
                         cnt < rdp_pkt_seg_eack_cnt (rdp_pkt_seg_ehdr (pkt));
                         cnt++)
                      {
                        tp_seq_t seq = rdp_pkt_seg_eack_get (rdp_pkt_seg_ehdr (pkt), cnt);
/*                        printf ("EACK_Seq(%d)\n", seq);*/
                        if (rdp_func_TxQueuePrune (info, seq) == true)
                          {
#   ifdef   DEBUG_RDP
                            tp_print (tp_print_debug, "RDP(%d): OPEN: Prune TxQueue (Seq=%d)", g_tp_copy, seq);
#   endif
                          }
                      }
                  }
                /*MG: back to back eacks, so force a retransmit of everything
                  still in the queue .. */
                if (info->eack_cnt >= RDP_EAK_RETRANSMIT)
                  {
                    tp_seq_t seq;
                    tp_pk_t* npkt;

#   if defined (DEBUG_RDP) || 1
                    tp_print (tp_print_debug, "RDP(%d): OPEN: Duplicate EACK's: Retransmit", g_tp_copy);
#   endif

                    info->eack_cnt = 0;
                    for (seq = info->snd_una;
                         seq != info->snd_nxt;
                         SEQ_INC (seq))
                      {
                        if (rdp_func_TxQueueRead (info,
                                                  seq,
                                                  &npkt) == true)
                          {

                            rdp_pkt_seg_tck (npkt) = RDP_TICK_RETRANSMIT;

                            if (rdp_func_SendSegmentACK (info,
                                                         rdp_pkt_seg_seq (npkt),
                                                         info->rcv_cur,
                                                         tp_pk_sze_get (npkt), tp_pk_dat_get (npkt)) == true)
                              {
                                info->snd_stat_rsnd_byt += tp_pk_sze_get (npkt);
                                info->snd_stat_rsnd_cnt ++;
                              }
                          }
                      }
                  }
              }


            /******************************************************
             * OPEN -- Segment Data                               *
             ******************************************************/

            rdp_func_UpdateSegment (info,
                                    pkt);

            if (rdp_pkt_seg_size (pkt) > 0)
              {
                rdp_func_RxQueueInsert (info,
                                        rdp_pkt_seg_seq (pkt),
                                        pkt);
                info->rcv_stat_byt += tp_pk_sze_get (pkt);
                info->rcv_stat_cnt ++;
                if (SEQ_ADD (info->rcv_cur, 1) == rdp_pkt_seg_seq (pkt))
                  {
#   if defined (DEBUG_RDP) || 1
                    tp_print (tp_print_debug, "RDP(%d): OPEN: Receive Data [in order] (Seq=%d, Ack=%d, Len=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt), rdp_pkt_seg_size (pkt));
#   endif
                    while (rdp_func_RxQueueCheck (info, SEQ_ADD (info->rcv_cur, 1)) == true)
                      {
                        SEQ_INC (info->rcv_cur);
                      }

                    rdp_func_SendSegmentACK (info,
                                             info->snd_nxt,
                                             info->rcv_cur,
                                             0, NULL);
                    return true;
                  }
                else
                  {
                    u_long_t len = 32;
                    tp_seq_t lst [32];
#   if defined(DEBUG_RDP) || 1
                    tp_print (tp_print_debug, "RDP(%d): OPEN: Receive Data [out of order] (Seq=%d, Ack=%d, Len=%d)", g_tp_copy, rdp_pkt_seg_seq (pkt), rdp_pkt_seg_ack (pkt), rdp_pkt_seg_size (pkt));
#   endif
                    if (rdp_func_RxQueueGenerateAckList (info,
                                                         &len,
                                                         lst) == true)
                      {

                        while (rdp_func_RxQueueCheck (info, SEQ_ADD (info->rcv_cur, 1)) == true)
                          {
                            SEQ_INC (info->rcv_cur);
                          }

                        rdp_func_SendSegmentEACK (info,
                                                  info->snd_nxt,
                                                  info->rcv_cur,
                                                  len,
                                                  lst,
                                                  0, NULL);
                      }
                    else
                      {

                        while (rdp_func_RxQueueCheck (info, SEQ_ADD (info->rcv_cur, 1)) == true)
                          {
                            SEQ_INC (info->rcv_cur);
                          }

                        rdp_func_SendSegmentACK (info,
                                                 info->snd_nxt,
                                                 info->rcv_cur,
                                                 0, NULL);
                      }

                    return true;
                  }
              }


            /******************************************************
             * OPEN -- Segment *                                  *
             ******************************************************/

            rdp_func_DiscardSegment (info,
                                     pkt);
            return true;
      }

    return true;
  }

/* ------------------------------------------------------------------- */

boolean_t rdp_event_Timeout (rdp_state_info_t* info, word tck)
  {
    /* Timeout -- handle a timer expiry.
        Open -- expire and handle a retransmit timer.
        Close Wait -- expire and handle a close wait timer.
     */

    switch (info->state)
      {
        case rdp_state_open:
        case rdp_state_syn_sent:

            if (rdp_func_ExpireRetransmitTimer (info, tck) == true)
              {
                rdp_event_RetransmissionTimeout (info);
                rdp_func_StartRetransmitTimer (info);
              }

            break;

        case rdp_state_close_wait:

            if (rdp_func_ExpireCloseWaitTimer (info, tck) == true)
              {
                rdp_event_CloseWaitTimeout (info);
              }

            break;

        case rdp_state_listen:
        case rdp_state_syn_rcvd:
        case rdp_state_closed:

            break;
      }

    if (rdp_func_ExpireStatusTimer (info, tck) == true)
      {
        rdp_event_StatusTimeout (info);
        rdp_func_StartStatusTimer (info);
      }

    return true;
  }

/* ------------------------------------------------------------------- */

boolean_t rdp_event_RetransmissionTimeout (rdp_state_info_t* info)
  {
    /* Retransmission Timeout -- handle a retransmission timeout.
        Open -- find out which packets have had their retransmit
            timer expired for them, and then read these packets
            out and send them back into the network.
        Syn Sent -- resend the syn packet.
     */

    switch (info->state)
      {
        case rdp_state_open:
          {
            u_long_t len = 32;
            tp_seq_t lst [32];
            u_long_t cnt;
            tp_pk_t* pkt;

            if (rdp_func_TxQueueRetransmitExpiry (info,
                                                  RDP_TIMER_RETRANSMIT,
                                                  &len,
                                                  lst) == false)
                return false;

#   ifdef   DEBUG_RDP
            tp_print (tp_print_debug, "RDP(%d): OPEN: Retransmission Timeout (Len=%d)", g_tp_copy, len);
#   endif

            for (cnt = 0;
                 cnt < len;
                 cnt++)
              {
                if (rdp_func_TxQueueRead (info,
                                          lst [cnt],
                                          &pkt) == true)
                  {

                    rdp_pkt_seg_tck (pkt) = RDP_TICK_RETRANSMIT;

                    if (rdp_func_SendSegmentACK (info,
                                                 rdp_pkt_seg_seq (pkt),
                                                 info->rcv_cur,
                                                 tp_pk_sze_get (pkt), tp_pk_dat_get (pkt)) == true)
                      {
                        info->snd_stat_rsnd_byt += tp_pk_sze_get (pkt);
                        info->snd_stat_rsnd_cnt ++;
                      }
                  }
              }

            return true;
          }

        case rdp_state_syn_sent:
          {
            if (info->syn_sent_tck < RDP_TIMER_RETRANSMIT)
              {
                info->syn_sent_tck = RDP_TICK_RETRANSMIT;

#   ifdef   DEBUG_RDP
                tp_print (tp_print_debug, "RDP(%d): SYN_SENT: Retransmission Timeout", g_tp_copy);
#   endif

                rdp_func_SendSegmentSYN (info,
                                         info->snd_iss,
                                         info->snd_max,
                                         info->rbuf_max,
                                         info->options);
              }
            else
              {
                info->syn_sent_tck -= RDP_TIMER_RETRANSMIT;
              }

            return true;
          }

        case rdp_state_closed:
        case rdp_state_listen:
        case rdp_state_syn_rcvd:
        case rdp_state_close_wait:

            rdp_func_PrintError (info, "Retransmit Timeout in Invalid State");
            return false;
      }

    return true;
  }

/* ------------------------------------------------------------------- */

boolean_t rdp_event_CloseWaitTimeout (rdp_state_info_t* info)
  {
    /* CloseWait Timeout -- handle a timeout in the close-wait
       state.
        Closed -- set the connection to be closed and clear
            down the operating context.
     */

    switch (info->state)
      {
        case rdp_state_close_wait:

#   if defined (DEBUG_RDP) || 1
            tp_print (tp_print_debug, "RDP(%d): CLOSE_WAIT->CLOSED: Close Wait Timeout", g_tp_copy);
#   endif

            rdp_func_TermConnectionRecord (info);
            info->state = rdp_state_closed;
            return true;

        case rdp_state_listen:
        case rdp_state_syn_sent:
        case rdp_state_syn_rcvd:
        case rdp_state_open:
        case rdp_state_closed:

            rdp_func_PrintError (info, "CloseWait Timeout in Invalid State");
            return false;
      }

    return true;
  }

/* ------------------------------------------------------------------- */

boolean_t rdp_event_StatusTimeout (rdp_state_info_t* info)
  {
    /* Status Timeout -- handle a timeout to show status.
     */

    switch (info->state)
      {
        case rdp_state_close_wait:
        case rdp_state_listen:
        case rdp_state_syn_sent:
        case rdp_state_syn_rcvd:
        case rdp_state_open:
        case rdp_state_closed:

            rdp_event_StatusRequest (info);
            return false;
      }

    return true;
  }

/* ------------------------------------------------------------------- */

