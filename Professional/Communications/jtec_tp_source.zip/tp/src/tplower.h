
#   ifndef      _LOWER_H_
#   define      _LOWER_H_

/*  ---------------------------------------------------------------- */
#   include     "tp.h"
#   include     "tppackt.h"
#   include     <rm_res.h>
#   include     <pdatadef.h>
#   include     <frencap.h>

/*  ---------------------------------------------------------------- */

#   define      TP_LW_LIST_SIZE            (TP_INSTANCE_MAX)

/*  ---------------------------------------------------------------- */

typedef struct _tp_lw_ctx_                          /* ctx: defn     */
  {
    boolean_t           active;                     /* ctx: active   */

    tp_pk_hnd_t         upper_handler;              /* upr: handler  */
    void*               upper_ctx;                  /* upr: context  */

    tResourceCopy       lower_copy;                 /* lwr: copy     */
    tResourceInfo       lower_resource;             /* lwr: resource */

    tp_msg_hnd_t        excpt_handler;              /* exp: handler  */
    void*               excpt_ctx;                  /* exp: context  */

    VirtualCircuitID    virtual_circuit_id;         /* frm: ident    */
    FRFrameDataType     frame_type;                 /* frm: type     */

#   ifdef   TP_LOOPBACK_ENABLED
    boolean_t           loopback_enabled;
    tResourceCopy       loopback_copy;
#   endif

  } tp_lw_ctx;                                      /* ctx: defn     */

/*  ---------------------------------------------------------------- */

boolean_t       tp_lw_create           (void);
boolean_t       tp_lw_destroy          (void);

boolean_t       tp_lw_message          (MSGPTR msg);
boolean_t       tp_lw_control          (MSGPTR msg);

tp_lw_ctx*      tp_lw_allocate         (tResourceCopy copy);
tp_lw_ctx*      tp_lw_locate_noFR      (tResourceCopy copy);
tp_lw_ctx*      tp_lw_locate_FR        (dword address);

boolean_t       tp_lw_free             (tp_lw_ctx* ctx);
boolean_t       tp_lw_config           (tp_lw_ctx* ctx, MSGPTR msg);
boolean_t       tp_lw_connect          (tp_lw_ctx* ctx);
boolean_t       tp_lw_disconnect       (tp_lw_ctx* ctx);
boolean_t       tp_lw_status           (tp_lw_ctx* ctx);

boolean_t       tp_lw_lower_set        (tp_lw_ctx* ctx, tResourceInfo* info);
boolean_t       tp_lw_upper_set        (tp_lw_ctx* ctx, tp_pk_hnd_t hnd, void* ref);
boolean_t       tp_lw_excpt_set        (tp_lw_ctx* ctx, tp_msg_hnd_t hnd, void* ref);

boolean_t       tp_lw_upper_output     (tp_lw_ctx* ctx, tp_pk_t* pkt);
boolean_t       tp_lw_lower_output     (tp_lw_ctx* ctx, word typ, tp_pk_t* pkt);
boolean_t       tp_lw_excpt_output     (tp_lw_ctx* ctx, char* msg);

boolean_t       tp_lw_upper_input      (void* ref, tp_pk_t* pkt);
boolean_t       tp_lw_lower_input      (void* ref, MSGPTR msg);
boolean_t       tp_lw_timer_input      (void* ref, word tck);

boolean_t       tp_pk_enc_lower_FR     (tp_pk_t* pkt, MSGPTR msg, dword address, FRFrameDataType type);
boolean_t       tp_pk_dec_lower_FR     (tp_pk_t* pkt, MSGPTR msg, dword* address, FRFrameDataType* type);
boolean_t       tp_pk_enc_lower        (tp_pk_t* pkt, MSGPTR msg);
boolean_t       tp_pk_dec_lower        (tp_pk_t* pkt, MSGPTR msg);

/*  ---------------------------------------------------------------- */

#   endif       /*_LOWER_H_*/

