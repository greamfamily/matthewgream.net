
#   ifndef      _RMGMT_H_
#   define      _RMGMT_H_

/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol
 *  Matthew Gream, April 1997
 *  $Id: tprmgmt.h,v 1.6 1997/06/14 03:49:16 matthewg Exp $
 *  $Log: tprmgmt.h,v $
 *  Revision 1.6  1997/06/14 03:49:16  matthewg
 *  Added Statistics Information; inserted logic to handle DL_ESTABLISH_REQ
 *  and DL_RELEASE_REQ to synchronise end points; generate DL_RELEASE_IND
 *  when error count exceeds 10 to flush queues and clear tx/rx states.
 *
 *  Revision 1.5  1997/06/11 00:05:51  matthewg
 *  Enhanced debugging and reporting.
 *
 *  Revision 1.4  1997/06/02 08:24:27  matthewg
 *  Updated copy count and other sizes to refine .bss/.data usage.
 *
 *  Revision 1.3  1997/05/08 06:12:01  matthewg
 *  Integrated/build/test of reliable part of software.
 *
 *  Revision 1.2  1997/04/29 00:37:09  matthewg
 *  First pass after greenhills build.
 *
 *  Revision 1.1.1.1  1997/04/28 10:55:48  matthewg
 *  Transport Protocol software. This transport protocol is used to
 *  carry reliable or unreliable data across frame relay through
 *  either an unreliable or reliable (sliding window) transport
 *  protocol.
 *
 *  Initial checkin: Unrelable protocol PC emulation testing complete.
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */

#   include     "tp.h"
#   include     "tpupper.h"
#   include     "tplower.h"
#   include     "tpproto.h"
#   include     <rm_res.h>

/*  ---------------------------------------------------------------- */

#   define      TP_RM_LIST_SZ            (TP_INSTANCE_MAX)

/*  ---------------------------------------------------------------- */

typedef struct _tp_rm_ctx_                          /* ctx: defn     */
  {
    boolean_t       active;                         /* ctx: active   */
    tResourceCopy   copy;                           /* ctx: copy     */
    tp_lw_ctx*      lower_ctx;                      /* ctx: lower    */
    tp_pr_ctx*      proto_ctx;                      /* ctx: upper    */
    tp_up_ctx*      upper_ctx;                      /* ctx: proto    */
    tResourceInfo   upper_resource;                 /* upr: resource */
    tResourceInfo   lower_resource;                 /* lwr: resource */
  }
tp_rm_ctx;                                          /* ctx: defn     */

/*  ---------------------------------------------------------------- */

boolean_t       tp_rm_create               (void);
boolean_t       tp_rm_destroy              (void);

boolean_t       tp_rm_message              (MSGPTR msg);

boolean_t       tp_rm_accpt_connect        (MSGPTR msg);
boolean_t       tp_rm_accpt_disconnect     (MSGPTR msg);
boolean_t       tp_rm_accpt_control        (MSGPTR msg);
boolean_t       tp_rm_issue_disconnect     (tResourceCopy copy);
boolean_t       tp_rm_issue_signon         (tResourceId id, tResourceCopy copy, tResourceVersion vers, tResourceName name);
boolean_t       tp_rm_issue_signoff        (tResourceId id);

tp_rm_ctx*      tp_rm_locate               (tResourceCopy copy);
tp_rm_ctx*      tp_rm_allocate             (tResourceCopy copy, tp_ex_typ type);
boolean_t       tp_rm_status               (tResourceCopy copy);

boolean_t       tp_rm_free                 (tp_rm_ctx* ctx);
boolean_t       tp_rm_config               (tp_rm_ctx* ctx, MSGPTR msg);
boolean_t       tp_rm_connect              (tp_rm_ctx* ctx);
boolean_t       tp_rm_disconnect           (tp_rm_ctx* ctx);

boolean_t       tp_rm_except               (void* ref, char* msg);

/*  ---------------------------------------------------------------- */

#   endif       /*_RMGMT_H_*/

