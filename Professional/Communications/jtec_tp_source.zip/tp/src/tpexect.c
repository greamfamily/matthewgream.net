
/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol
 *  Matthew Gream, April 1997
 *  $Id: tpexect.c,v 1.5 1997/06/25 02:24:26 matthewg Exp $
 *  $Log: tpexect.c,v $
 *  Revision 1.5  1997/06/25 02:24:26  matthewg
 *  Added MSG FUNC TYPE inversion for loopedback task.
 *
 *  Revision 1.4  1997/06/14 03:49:11  matthewg
 *  Added Statistics Information; inserted logic to handle DL_ESTABLISH_REQ
 *  and DL_RELEASE_REQ to synchronise end points; generate DL_RELEASE_IND
 *  when error count exceeds 10 to flush queues and clear tx/rx states.
 *
 *  Revision 1.3  1997/06/11 00:05:46  matthewg
 *  Enhanced debugging and reporting.
 *
 *  Revision 1.2  1997/05/20 02:03:09  matthewg
 *  Integration Update.
 *
 *  Revision 1.1.1.1  1997/04/28 10:55:47  matthewg
 *  Transport Protocol software. This transport protocol is used to
 *  carry reliable or unreliable data across frame relay through
 *  either an unreliable or reliable (sliding window) transport
 *  protocol.
 *
 *  Initial checkin: Unrelable protocol PC emulation testing complete.
 *
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */
/*  Executive: Headers */

#   include     "tpexect.h"
#   include     "tptask.h"
#   include     "tputlty.h"
#   include     "tptimer.h"
#   include     "tplower.h"
#   include     "tpupper.h"
#   include     "tprmgmt.h"
#   include     "tppackt.h"
#   include     "tpproto.h"

#   include     <bufintf.h>

/*  ---------------------------------------------------------------- */
/*  Executive: Create */

boolean_t tp_exect_create (void)
  {
    if (tp_ut_create () == false)
        return false;
    if (tp_tm_create () == false)
        return false;
    if (tp_pk_create () == false)
        return false;
    if (tp_up_create () == false)
        return false;
    if (tp_lw_create () == false)
        return false;
    if (tp_pr_create () == false)
        return false;
    if (tp_rm_create () == false)
        return false;
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Executive: Execute */

boolean_t tp_exect_execute (void)
  {
#   ifdef   DEBUG_EXECT
    tp_print (tp_print_debug, "exect (): execute");
#   endif

    JexecEnableTaskSuspension (_TASK_ID);
    while (1)
      {
        MSGPTR msg;
#   ifdef   DEBUG_EXECT
        tp_print (tp_print_debug, "exect (): wait msg");
#   endif
        while ((msg = JexecGetMessage (_TASK_ID)) == NULL)
            JexecRelinquish ();
#   ifdef   DEBUG_EXECT
        tp_print (tp_print_debug, "exect (): proc msg");
#   endif
        switch (ISOLAY (msg->type))
          {
            case MANAGEMENT_PRIMS:
#   ifdef   DEBUG_EXECT
                tp_print (tp_print_debug, "exect (): mgmt msg");
#   endif
                if (tp_rm_message (msg) == false)
                    tp_print (tp_print_error, "exect (): mgmt msg invalid (%x)", msg->type);
                break;
            case DATALINK_PRIMS:
                if (msg->source_id == _TASK_ID)
                  {
                    /* Invert */
                    switch (msg->type & FUNC_TYPE_MASK)
                      {
                        case IND_PRIMS:
                            msg->type = (msg->type & ~(FUNC_TYPE_MASK)) | REQ_PRIMS;
                            break;
                        case CON_PRIMS:
                            msg->type = (msg->type & ~(FUNC_TYPE_MASK)) | RES_PRIMS;
                            break;
                        case REQ_PRIMS:
                            msg->type = (msg->type & ~(FUNC_TYPE_MASK)) | IND_PRIMS;
                            break;
                        case RES_PRIMS:
                            msg->type = (msg->type & ~(FUNC_TYPE_MASK)) | CON_PRIMS;
                            break;
                      }
                  }
                switch (ISOTYP (msg->type))
                  {
                    case REQ_PRIMS:
                    case RES_PRIMS:
#   ifdef   DEBUG_EXECT
                        tp_print (tp_print_debug, "exect (): uppr msg");
#   endif
                        if (tp_up_message (msg) == false)
                          {
                            BufferDescriptor* descr = NULL;
                            if (IsolateBufferStructPID (msg, &descr))
                                ReturnBufferDescriptor (descr);
                            tp_print (tp_print_error, "exect (): uppr msg invalid (%x)", msg->type);
                          }
                        break;
                    case CON_PRIMS:
                    case IND_PRIMS:
#   ifdef   DEBUG_EXECT
                        tp_print (tp_print_debug, "exect (): lowr msg");
#   endif
                        if (tp_lw_message (msg) == false)
                          {
                            BufferDescriptor* descr = NULL;
                            if (IsolateBufferStructPID (msg, &descr))
                                ReturnBufferDescriptor (descr);
                            tp_print (tp_print_error, "exect (): lowr msg invalid (%x)", msg->type);
                          }
                        break;
                    default:
                        break;
                  }
                break;
            case JEXEC_PRIMS:
#   ifdef   DEBUG_EXECT
                tp_print (tp_print_debug, "exect (): jexe msg");
#   endif
                switch (msg->type)
                  {
                    case JEXEC_START_UP:
					case JEXEC_COMMAND:
                        if (tp_ut_message (msg) == false)
                            tp_print (tp_print_error, "exect (): jexe util msg invalid (%x)", msg->type);
                        break;
                    case JEXEC_TIMER_EXPIRY:
                        if (tp_tm_message (msg) == false)
                            tp_print (tp_print_error, "exect (): jexe timr msg invalid (%x)", msg->type);
                        break;
                    case JEXEC_STATUS_REPORT:
                        tp_rm_status (msg->parameter [0]);
                        break;
                    default:
                        break;
                  }
                break;
            default:
                tp_print (tp_print_warn, "exect (): othr msg (%x)", msg->type);
                break;
          }
        JexecReturnMessage (_TASK_ID, msg);
      }
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Executive: Destroy */

boolean_t tp_exect_destroy (void)
  {
    if (tp_rm_destroy () == false)
        ;
    if (tp_pr_destroy () == false)
        ;
    if (tp_lw_destroy () == false)
        ;
    if (tp_up_destroy () == false)
        ;
    if (tp_pk_destroy () == false)
        ;
    if (tp_tm_destroy () == false)
        ;
    if (tp_ut_destroy () == false)
        ;
    return true;
  }

/*  ---------------------------------------------------------------- */

