
/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol
 *  Matthew Gream, April 1997
 *  $Id: tpupper.c,v 1.12 1997/09/08 01:19:10 matthewg Exp $
 *  $Log: tpupper.c,v $
 *  Revision 1.12  1997/09/08 01:19:10  matthewg
 *  Added dump for input/output of messages.
 *
 *  Revision 1.11  1997/06/25 02:23:29  matthewg
 *  Added DEBUGGING levels.
 *
 *  Revision 1.10  1997/06/17 06:30:18  matthewg
 *  Miscellaneous debugging changes.
 *
 *  Revision 1.9  1997/06/16 02:02:00  matthewg
 *  Fast Packet Interface changes.
 *
 *  Revision 1.8  1997/06/14 03:49:18  matthewg
 *  Added Statistics Information; inserted logic to handle DL_ESTABLISH_REQ
 *  and DL_RELEASE_REQ to synchronise end points; generate DL_RELEASE_IND
 *  when error count exceeds 10 to flush queues and clear tx/rx states.
 *
 *  Revision 1.7  1997/06/11 00:05:52  matthewg
 *  Enhanced debugging and reporting.
 *
 *  Revision 1.6  1997/05/20 02:03:09  matthewg
 *  Integration Update.
 *
 *  Revision 1.5  1997/05/16 07:10:16  matthewg
 *  Modifications for integration (resource copy == 0); major
 *  step in testing achieved for reliable transport protocol.
 *
 *  Revision 1.4  1997/05/08 06:12:04  matthewg
 *  Integrated/build/test of reliable part of software.
 *
 *  Revision 1.3  1997/05/05 08:14:24  matthewg
 *  Modifications for in target build.
 *
 *  Revision 1.2  1997/04/29 00:37:16  matthewg
 *  First pass after greenhills build.
 *
 *  Revision 1.1.1.1  1997/04/28 10:55:48  matthewg
 *  Transport Protocol software. This transport protocol is used to
 *  carry reliable or unreliable data across frame relay through
 *  either an unreliable or reliable (sliding window) transport
 *  protocol.
 *
 *  Initial checkin: Unrelable protocol PC emulation testing complete.
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */
/*
 *  This file implements the upper layer for the transport protocol.
 *  This layer uses a message based interface with the upper layer,
 *  the upper layer address is configured via. the resource manager
 *  through upper layer resource information pids provided in a
 *  configuration message.
 */
/*  ---------------------------------------------------------------- */

#   include     "tpupper.h"
#   include     "tptask.h"
#   include     "tputlty.h"
#   include     "tppackt.h"
#   include     <dl_msgs.h>
#   include     <bufintf.h>

/*  ---------------------------------------------------------------- */

static tp_up_ctx    tp_up_list [TP_UP_LIST_SIZE];
static int          tp_up_list_size = TP_UP_LIST_SIZE;

/*  ---------------------------------------------------------------- */

boolean_t tp_up_create (void)
  {
    int index;
    for (index = 0;
         index < tp_up_list_size;
         index++)
      {
        tp_up_ctx* ctx = &tp_up_list [index];
        ctx->active = false;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_up_destroy (void)
  {
    int index;
    for (index = 0;
         index < tp_up_list_size;
         index++)
      {
        tp_up_ctx* ctx = &tp_up_list [index];
        if (ctx->active == true)
          {
            tp_up_disconnect (ctx);
            tp_up_free (ctx);
          }
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_up_message (MSGPTR msg)
  {
    tp_up_ctx* ctx;

#   ifdef   DEBUG_UPPER
	tp_print (tp_print_debug, "up_message ():");
    tp_dump (tp_print_debug, msg);
#	endif

    if ((ctx = tp_up_locate (msg->parameter [0])) == NULL)
      {
        tp_print (tp_print_warn, "up_message (): invalid copy (%d)", msg->parameter [0]);
        return false;
      }

    g_tp_copy = ctx->upper_copy;

    if (tp_up_upper_input (ctx, msg) == false)
      {
        tp_print (tp_print_warn, "up_message (): lower input failed");
        return false;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_up_control (MSGPTR msg)
  {
#	ifdef	DEBUG_UPPER
    tp_print (tp_print_debug, "up_control ():");
#	endif

    return true;
  }

/*  ---------------------------------------------------------------- */

tp_up_ctx* tp_up_allocate (tResourceCopy copy)
  {
    tp_up_ctx* ctx;

#   ifdef   DEBUG_UPPER
	tp_print (tp_print_debug, "up_allocate ():");
#	endif

    ctx = &tp_up_list [copy];
    if (ctx->active == true)
        return NULL;

    ctx->lower_activate = NULL;
    ctx->lower_output = NULL;
    ctx->lower_ctx = NULL;
    ctx->excpt_handler = NULL;
    ctx->excpt_ctx = NULL;
    ctx->upper_copy = copy;
    ctx->upper_resource.Id = RM_RESOURCE_ID_NULL;
    ctx->upper_resource.Copy = RM_RESOURCE_COPY_NULL;
    ctx->upper_resource.Module = MM_MODULE_ID_NULL;
    ctx->active = true;

    return ctx;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_up_free (tp_up_ctx* ctx)
  {
#	ifdef	DEBUG_UPPER
	tp_print (tp_print_debug, "up_free ():");
#	endif

    ctx->active = false;

    return true;
  }

/*  ---------------------------------------------------------------- */

tp_up_ctx* tp_up_locate (tResourceCopy copy)
  {
    tp_up_ctx* ctx;

#   ifdef   DEBUG_UPPER
	tp_print (tp_print_debug, "up_locate ():");
#	endif

    ctx = &tp_up_list [copy];
    if (ctx->active == false)
        return NULL;

    return ctx;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_up_config (tp_up_ctx* ctx, MSGPTR msg)
  {
#	ifdef	DEBUG_UPPER
	tp_print (tp_print_debug, "up_config ():");
#	endif

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_up_status (tp_up_ctx* ctx)
  {
#   ifdef   DEBUG_UPPER
    tp_print (tp_print_debug, "up_status ():");
#	endif

    tp_print (tp_print_none, "Upper (%08X): Copy %d", ctx, ctx->upper_copy);
    tp_print (tp_print_none, "  Lower Layer: Out %08X, Act %08X, Ctx %08X", ctx->lower_output, ctx->lower_activate, ctx->lower_ctx);
    tp_print (tp_print_none, "  Upper Layer: ResId %04X, ResCopy %d", ctx->upper_resource.Id, ctx->upper_resource.Copy);

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_up_connect (tp_up_ctx* ctx)
  {
#	ifdef	DEBUG_UPPER
	tp_print (tp_print_debug, "up_connect ():");
#	endif

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_up_disconnect (tp_up_ctx* ctx)
  {
#	ifdef	DEBUG_UPPER
	tp_print (tp_print_debug, "up_disconnect ():");
#	endif

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_up_lower_except (void* ref, char* msg)
  {
    tp_up_ctx* ctx = ref;

#   ifdef   DEBUG_UPPER
    tp_print (tp_print_debug, "up_lower_excpt ():");
#	endif

    if (tp_up_upper_output (ctx, DL_RELEASE_IND, NULL) == false)
        ;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_up_lower_input (void* ref, tp_pk_t* pkt)
  {
    tp_up_ctx* ctx = ref;

#   ifdef   DEBUG_UPPER
	tp_print (tp_print_debug, "up_lower_input ():");
#	endif

    if (tp_up_upper_output (ctx, DL_DATA_IND, pkt) == false)
        return false;
    if (tp_pk_free (pkt) == false)
        return false;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_up_upper_input (void* ref, MSGPTR msg)
  {
    tp_up_ctx* ctx = ref;

/*#   ifdef   DEBUG_UPPER*/
    tp_print (tp_print_debug, "Upper Input ():");
     tp_dump (tp_print_debug, msg);
/*#   endif*/

    switch (msg->type)
      {
        case DL_ESTABLISH_REQ:

#   ifdef   DEBUG_UPPER
            tp_print (tp_print_debug, " > DL_ESTABLISH_REQ");
#   endif
            if (tp_up_lower_activate (ctx, true) == false)
                return false;
            break;

        case DL_RELEASE_REQ:

#   ifdef   DEBUG_UPPER
            tp_print (tp_print_debug, " > DL_RELEASE_REQ");
#   endif
            if (tp_up_lower_activate (ctx, false) == false)
                return false;
            break;

        case DL_DATA_REQ:

#   ifdef   DEBUG_UPPER
            tp_print (tp_print_debug, " > DL_DATA_REQ");
#   endif
              {
                tp_pk_t* pkt;

                if ((pkt = tp_pk_allocate (NULL)) == NULL)
                  {
                    tp_print (tp_print_warn, "up_upper_input (): packet allocation failed");
                    return false;
                  }

                if (tp_pk_dec_upper (pkt, msg) == false)
                  {
                    tp_print (tp_print_warn, "up_upper_input (): packet decode failed");
                    tp_pk_free (pkt);
                    return false;
                  }

                if (tp_up_lower_output (ctx, pkt) == false)
                  {
                    tp_pk_free (pkt);
                    return true;
                  }
              }

            break;

        default:

            return false;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_up_timer_input (void* ref, word tck)
  {
    tp_up_ctx* ctx = ref;

#   ifdef   DEBUG_UPPER
	tp_print (tp_print_debug, "up_timer_input ():");
#	endif

    return false;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_up_upper_set (tp_up_ctx* ctx, tResourceInfo* info)
  {
    memcpy (&ctx->upper_resource,
           info,
           sizeof (ctx->upper_resource));

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_up_lower_set (tp_up_ctx* ctx, tp_pk_hnd_t output_hnd, tp_actv_hnd_t activate_hnd, void* ref)
  {
    ctx->lower_output = output_hnd;
    ctx->lower_activate = activate_hnd;
    ctx->lower_ctx = ref;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_up_excpt_set (tp_up_ctx* ctx, tp_msg_hnd_t hnd, void* ref)
  {
    ctx->excpt_handler = hnd;
    ctx->excpt_ctx = ref;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_up_lower_activate (tp_up_ctx* ctx, boolean_t state)
  {
#	ifdef	DEBUG_UPPER
    tp_print (tp_print_debug, "up_lower_activate ():");
#	endif

    if (ctx->lower_activate == NULL)
        return false;
    if (ctx->lower_activate (ctx->lower_ctx, state) == false)
        return false;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_up_lower_output (tp_up_ctx* ctx, tp_pk_t* pkt)
  {
#	ifdef	DEBUG_UPPER
	tp_print (tp_print_debug, "up_lower_output ():");
#	endif

    if (ctx->lower_output == NULL)
        return false;
    if (ctx->lower_output (ctx->lower_ctx, pkt) == false)
        return false;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_up_upper_output (tp_up_ctx* ctx, word type, tp_pk_t* pkt)
  {
    MSGPTR msg;

    if (ctx->upper_resource.Id == RM_RESOURCE_ID_NULL)
        return false;

    if ((msg = JexecNewMessage (_TASK_ID)) == NULL)
        return false;

    msg->type = type;
    msg->parameter [0] = ctx->upper_resource.Copy;
    msg->parameter [1] = ctx->upper_copy;
    msg->length = 0;

    if (pkt != NULL && tp_pk_enc_upper (pkt, msg) == false)
      {
        JexecReturnMessage (_TASK_ID, msg);
        return false;
      }

/*#   ifdef   DEBUG_UPPER*/
    tp_print (tp_print_debug, "Upper Output ():");
     tp_dump (tp_print_debug, msg);
/*#   endif*/

    if (JexecSendMessage (ctx->upper_resource.Id, msg) == FALSE)
      {
		tp_pk_dec_upper (pkt, msg);
        JexecReturnMessage (_TASK_ID, msg);
        return false;
      }

#   ifdef   DEBUG_UPPER
    switch (type)
      {
        case DL_DATA_IND:
            tp_print (tp_print_debug, " > DL_DATA_IND");
            break;
        case DL_RELEASE_IND:
            tp_print (tp_print_debug, " > DL_RELEASE_IND");
            break;
        case DL_ESTABLISH_IND:
            tp_print (tp_print_debug, " > DL_ESTABLISH_IND");
            break;
      }
#   endif

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_up_excpt_output (tp_up_ctx* ctx, char* msg)
  {
#	ifdef	DEBUG_UPPER
	tp_print (tp_print_debug, "up_excpt_output ():");
#	endif

    if (ctx->excpt_handler == NULL)
        return false;
    if (ctx->excpt_handler (ctx->excpt_ctx, msg) == false)
        return false;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_enc_upper (tp_pk_t* pkt, MSGPTR msg)
  {
#   ifdef   DEBUG_UPPER
	tp_print (tp_print_debug, "pk_enc_upper ():");
#	endif

    if (pkt->data == NULL)
        return false;

    if (AddBufferStructPID (msg, pkt->data) == FALSE)
        return false;

    pkt->data = NULL;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_dec_upper (tp_pk_t* pkt, MSGPTR msg)
  {
#   ifdef   DEBUG_UPPER
	tp_print (tp_print_debug, "pk_dec_upper ():");
#	endif

    if (pkt->data != NULL)
        return false;

    if (IsolateBufferStructPID (msg, &pkt->data) == FALSE)
        return false;

    return true;
  }

/*  ---------------------------------------------------------------- */

