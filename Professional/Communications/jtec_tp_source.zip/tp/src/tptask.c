
/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol
 *  Matthew Gream, April 1997
 *  $Id: tptask.c,v 1.6 1997/06/14 03:49:16 matthewg Exp $
 *  $Log: tptask.c,v $
 *  Revision 1.6  1997/06/14 03:49:16  matthewg
 *  Added Statistics Information; inserted logic to handle DL_ESTABLISH_REQ
 *  and DL_RELEASE_REQ to synchronise end points; generate DL_RELEASE_IND
 *  when error count exceeds 10 to flush queues and clear tx/rx states.
 *
 *  Revision 1.5  1997/05/19 02:37:51  matthewg
 *  Fixed stack length.
 *
 *  Revision 1.4  1997/05/13 22:34:52  matthewg
 *  Minor changes while testing.
 *
 *  Revision 1.3  1997/05/05 08:14:23  matthewg
 *  Modifications for in target build.
 *
 *  Revision 1.2  1997/04/29 00:37:11  matthewg
 *  First pass after greenhills build.
 *
 *  Revision 1.1.1.1  1997/04/28 10:55:47  matthewg
 *  Transport Protocol software. This transport protocol is used to
 *  carry reliable or unreliable data across frame relay through
 *  either an unreliable or reliable (sliding window) transport
 *  protocol.
 *
 *  Initial checkin: Unrelable protocol PC emulation testing complete.
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */
/*  Task: Headers */

#   include     "tptask.h"
#   include     "tpexect.h"
#   include     <monpub.h>

#   ifdef  RM_RESMGMT_ENABLED
#   include    <rm_res.h>
#   include    <rm_res_l.h>
#   include    <rm_res_n.h>
#   endif

/*  ---------------------------------------------------------------- */
/*  Task: Data */

static u_long_t Stack_TransportProtocol [_TASK_STSZ];

/*  ---------------------------------------------------------------- */
/*  Task: Install */

boolean Install_TransportProtocol (void)
  {
    jprintf ("Install: Transport Protocol");

    if (JexecInstallTask (
            _TASK_ID,
            _TASK_OPTS,
            (void *) Execute_TransportProtocol,
            (int *) &Stack_TransportProtocol [_TASK_STSZ],
            NULL,
            _TASK_RESV,
            0,
            sizeof (Stack_TransportProtocol),
            _TASK_PRIO) == FALSE)
      {
        jprintf ("tp: install failed");
        return FALSE;
      }
    return TRUE;
  }

/*  ---------------------------------------------------------------- */
/*  Task: Remove */

boolean Remove_TransportProtocol (void)
  {
    jprintf ("Remove: Transport Protocol");

    if (JexecRemoveTask (
            _TASK_ID) == FALSE)
      {
        jprintf ("tp: remove failed");
        return FALSE;
      }
    return TRUE;
  }

/*  ---------------------------------------------------------------- */
/*  Task: Execute */

void Execute_TransportProtocol (void)
  {
#   ifdef  RM_RESMGMT_ENABLED

#   ifdef   RM_RESMGMT_DEBUG
    jprintf ("Fp Transport (): Resource Sign On");
#   endif

    /*
     * Resource Module:
     *  Sign On to the Resource Manager to let it know that
     *  the Transport Protocol is present.
     */
    rm_IssueSignOnMessage (_TASK_ID,
                           RM_RESOURCE_ID_FP_TRANSPORT,
                           _TASK_COPY,
                           0,
                           "Fp Transport",
                           0x0100);
#endif

    if (tp_exect_create () == false)
      {
        jprintf ("tp: create failed");
      }
    else if (tp_exect_execute () == false)
      {
        jprintf ("tp: execute failed");
      }
    else if (tp_exect_destroy () == false)
      {
        jprintf ("tp: destroy failed");
      }

#ifdef  RM_RESMGMT_ENABLED

#   ifdef   RM_RESMGMT_DEBUG
    jprintf ("Fp Transport (): Resource Sign Off");
#   endif

    /*
     * Resource Module:
     *  Sign Off to the Resource Manager to let it know that
     *  the Transport Protocol is not present.
     */
    rm_IssueSignOffMessage (_TASK_ID,
                            RM_RESOURCE_ID_FP_TRANSPORT,
                            _TASK_COPY,
                            0,
                            "Fp Transport",
                            0x0100);
#endif

    return;
  }

/*  ---------------------------------------------------------------- */

