
/*  ---------------------------------------------------------------- */
/*
 *  Data Terminal
 *  Matthew Gream, April 1997
 *  $Id: tptimer.c,v 1.7 1997/06/25 02:22:23 matthewg Exp $
 *  $Log: tptimer.c,v $
 *  Revision 1.7  1997/06/25 02:22:23  matthewg
 *  Added copy field. Changed timer resolution from 100 to 250 ms.
 *
 *  Revision 1.6  1997/06/17 06:30:17  matthewg
 *  Miscellaneous debugging changes.
 *
 *  Revision 1.5  1997/06/14 03:49:18  matthewg
 *  Added Statistics Information; inserted logic to handle DL_ESTABLISH_REQ
 *  and DL_RELEASE_REQ to synchronise end points; generate DL_RELEASE_IND
 *  when error count exceeds 10 to flush queues and clear tx/rx states.
 *
 *  Revision 1.4  1997/05/22 03:45:56  matthewg
 *  fixed bug in timer
 *
 *  Revision 1.3  1997/05/18 22:41:33  matthewg
 *  Minor bug fixes.
 *
 *  Revision 1.2  1997/05/08 01:05:11  matthewg
 *  Did first pass integration, added emulation files, completed emulation
 *  testing, fixed problems with buffers, made other minor changes.
 *
 *  Revision 1.1.1.1  1997/05/06 04:39:16  matthewg
 *  Data Terminal source code for testing (loopback/generator/terminator
 *  stuff for a data stream).
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */
/*  Timer: Headers */

#   include     "tptimer.h"
#   include     "tptask.h"
#   include     "tputlty.h"

/*  ---------------------------------------------------------------- */
/*  Timer: Data */

static tp_tm_ctx        tp_tm_list [TP_TM_LIST_SZ];
static int              tp_tm_list_size             = TP_TM_LIST_SZ;
static u_byte_t         tp_tm_jexec_tm_handle       = 0;
static u_short_t        tp_tm_jexec_tm_active       = false;
static u_short_t        tp_tm_jexec_tm_ticks        = (250 MILLISECONDS);
static int              tp_tm_active                = 0;

/*  ---------------------------------------------------------------- */
/*  Timer: Create */

boolean_t tp_tm_create (void)
  {
    int index;
    for (index = 0;
         index < tp_tm_list_size;
         index++)
      {
        tp_tm_ctx* ctx = &tp_tm_list [index];
        ctx->active = false;
      }
    if (tp_tm_jexec_create () == false)
        return false;
    tp_tm_active = 0;
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Timer: Destroy */

boolean_t tp_tm_destroy (void)
  {
    tp_tm_jexec_stop ();
    tp_tm_jexec_destroy ();
    return false;
  }

/*  ---------------------------------------------------------------- */
/* Timer: Message */

boolean_t tp_tm_message (MSGPTR msgptr)
  {
    if (msgptr->type != JEXEC_TIMER_EXPIRY)
        return false;
    tp_tm_process (tp_tm_jexec_ticks ());
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Timer: Process */

boolean_t tp_tm_process (word ticks)
  {
    int index;
#   ifdef   DEBUG_TIMER
    tp_print (tp_print_debug, "tp_tm_expire: %u ticks", ticks);
#   endif
    for (index = 0;
         index < tp_tm_list_size;
         index++)
      {
        tp_tm_ctx* ctx = &tp_tm_list [index];
        if (ctx->active == true)
            tp_tm_expire (ctx, ticks);
      }
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Timer: Allocate */

tp_tm_ctx* tp_tm_allocate (void)
  {
    int index;
    for (index = 0;
         index < tp_tm_list_size;
         index++)
      {
        tp_tm_ctx* ctx = &tp_tm_list [index];
        if (ctx->active == false)
          {
            if (tp_tm_active == 0)
              {
                if (tp_tm_jexec_start () == false)
                    return NULL;
              }
            tp_tm_active++;
            ctx->handler = NULL;
            ctx->handler_ctx = NULL;
            ctx->ticks_start = 0;
            ctx->ticks_remain = 0;
            ctx->active = true;
            ctx->copy = g_tp_copy;
            return ctx;
          }
      }
    return NULL;
  }

/*  ---------------------------------------------------------------- */
/*  Timer: Free */

boolean_t tp_tm_free (tp_tm_ctx* ctx)
  {
    ctx->active = false;
    tp_tm_active--;
    if (tp_tm_active == 0)
        tp_tm_jexec_stop ();
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Timer: Set Handler */

boolean_t tp_tm_handler_set (tp_tm_ctx* ctx, tp_tm_hnd_t hnd, void* ref)
  {
    ctx->handler = hnd;
    ctx->handler_ctx = ref;
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Timer: Set Ticks */

boolean_t tp_tm_ticks_set (tp_tm_ctx* ctx, word tck)
  {
    ctx->ticks_start = tck;
    ctx->ticks_remain = tck;
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Timer: Expire */

boolean_t tp_tm_expire (tp_tm_ctx* ctx, word tck)
  {
    if (ctx->ticks_remain > tck)
      { ctx->ticks_remain -= tck; return false; }
#   ifdef   DEBUG_TIMER
    tp_print (tp_print_debug, "tp_tm_expire: %08X, %08X", ctx->handler, ctx->handler_ctx);
#   endif
    ctx->ticks_remain -= tck;
    ctx->active = false;
    g_tp_copy = ctx->copy;
    if (ctx->handler == NULL)
        return false;
    ctx->handler (ctx->handler_ctx, ctx->ticks_start - ctx->ticks_remain);
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Timer: Jexec Create */

boolean_t tp_tm_jexec_create (void)
  {
    if ((tp_tm_jexec_tm_handle = JexecGetTimer (_TASK_ID)) == 0)
        return false;
#   ifdef   DEBUG_TIMER
    tp_print (tp_print_debug, "tp_tm_jexec_create: %d", tp_tm_jexec_tm_handle);
#   endif
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Timer: Jexec Destroy */

boolean_t tp_tm_jexec_destroy (void)
  {
#   ifdef   DEBUG_TIMER
    tp_print (tp_print_debug, "tp_tm_jexec_destroy: %d", tp_tm_jexec_tm_handle);
#   endif
    if (JexecReturnTimer (_TASK_ID,
                          tp_tm_jexec_tm_handle) == 0)
        return false;
    tp_tm_jexec_tm_handle = 0;
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Timer: Jexec Start */

boolean_t tp_tm_jexec_start (void)
  {
    if (tp_tm_jexec_tm_active == true)
        return false;
    if (tp_tm_jexec_tm_handle == 0)
        return false;
    if (JexecStartTimer (_TASK_ID,
                         tp_tm_jexec_tm_handle,
                         0xDE,
                         0xAD,
                         tp_tm_jexec_tm_ticks,
                         TIMER_CONTINUOUS) == FALSE)
        return false;
    tp_tm_jexec_tm_active = true;
#   ifdef   DEBUG_TIMER
    tp_print (tp_print_debug, "tp_tm_jexec_start: %d ticks", tp_tm_jexec_tm_ticks);
#   endif
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Timer: Jexec Stop */

boolean_t tp_tm_jexec_stop (void)
  {
    if (tp_tm_jexec_tm_active == false)
        return true;
#   ifdef   DEBUG_TIMER
    tp_print (tp_print_debug, "tp_tm_jexec_stop");
#   endif
    if (JexecStopTimer (_TASK_ID,
                        tp_tm_jexec_tm_handle) == FALSE)
        return false;
    tp_tm_jexec_tm_active = false;
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Timer: Jexec Active */

boolean_t tp_tm_jexec_active (void)
  {
    return tp_tm_jexec_tm_active;
  }

/*  ---------------------------------------------------------------- */
/*  Timer: Jexec Ticks */

word tp_tm_jexec_ticks (void)
  {
    return tp_tm_jexec_tm_ticks;
  }

/*  ---------------------------------------------------------------- */

