
#   ifndef      _TIMER_H_
#   define      _TIMER_H_

/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol 
 *  Matthew Gream, April 1997
 *  $Id: tptimer.h,v 1.5 1997/06/25 02:22:24 matthewg Exp $
 *  $Log: tptimer.h,v $
 *  Revision 1.5  1997/06/25 02:22:24  matthewg
 *  Added copy field. Changed timer resolution from 100 to 250 ms.
 *
 *  Revision 1.4  1997/06/02 08:24:30  matthewg
 *  Updated copy count and other sizes to refine .bss/.data usage.
 *
 *  Revision 1.3  1997/05/08 06:12:03  matthewg
 *  Integrated/build/test of reliable part of software.
 *
 *  Revision 1.1.1.1  1997/05/06 04:39:16  matthewg
 *  Data Terminal source code for testing (loopback/generator/terminator
 *  stuff for a data stream).
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */

#   include     "tp.h"

/*  ---------------------------------------------------------------- */

#   define      TP_TM_LIST_SZ                   (TP_INSTANCE_MAX)

/*  ---------------------------------------------------------------- */

typedef boolean_t (*tp_tm_hnd_t) (void*,word);      /* handler       */

typedef struct _tp_tm_ctx_                          /* ctx: defn     */
  {
    boolean_t       active;                         /* ctx: active   */
    word            ticks_start;                    /* time start    */
    word            ticks_remain;                   /* time remain   */
    tp_tm_hnd_t     handler;                        /* tm: hnd       */
    void*           handler_ctx;                    /* tm: ctx       */
    u_byte_t        copy;                           /* tm: copy      */
  }
tp_tm_ctx;                                          /* ctx: defn     */

/*  ---------------------------------------------------------------- */

boolean_t       tp_tm_create            (void);
boolean_t       tp_tm_destroy           (void);

boolean_t       tp_tm_message           (MSGPTR msgptr);
boolean_t       tp_tm_process           (word ticks);

tp_tm_ctx*      tp_tm_allocate          (void);
boolean_t       tp_tm_free              (tp_tm_ctx* ctx);
boolean_t       tp_tm_handler_set       (tp_tm_ctx* ctx, tp_tm_hnd_t hnd, void* ref);
boolean_t       tp_tm_ticks_set         (tp_tm_ctx* ctx, word tck);
boolean_t       tp_tm_expire            (tp_tm_ctx* ctx, word tck);

boolean_t       tp_tm_jexec_create      (void);
boolean_t       tp_tm_jexec_destroy     (void);
boolean_t       tp_tm_jexec_start       (void);
boolean_t       tp_tm_jexec_stop        (void);
boolean_t       tp_tm_jexec_active      (void);
word            tp_tm_jexec_ticks       (void);

/*  ---------------------------------------------------------------- */

#   endif       /*_TIMER_H_*/

