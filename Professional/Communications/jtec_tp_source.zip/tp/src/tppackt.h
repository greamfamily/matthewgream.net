
#   ifndef      _PACKT_H_
#   define      _PACKT_H_

/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol
 *  Matthew Gream, April 1997
 *  $Id: tppackt.h,v 1.9 1997/09/08 01:19:08 matthewg Exp $
 *  $Log: tppackt.h,v $
 *  Revision 1.9  1997/09/08 01:19:08  matthewg
 *  Added dump for input/output of messages.
 *
 *  Revision 1.8  1997/07/22 14:46:11  matthewg
 *  #defined out the code for performing lower layer loopbacks
 *  and also added in a macro to add an offset in the packets
 *  to fix this problem with the frame relay encapsulation not
 *  having enough space to put a header in.
 *
 *  Revision 1.7  1997/06/25 02:25:26  matthewg
 *  Modified header to work with new protocol.
 *
 *  Revision 1.6  1997/06/16 02:02:00  matthewg
 *  Fast Packet Interface changes.
 *
 *  Revision 1.5  1997/06/14 03:49:13  matthewg
 *  Added Statistics Information; inserted logic to handle DL_ESTABLISH_REQ
 *  and DL_RELEASE_REQ to synchronise end points; generate DL_RELEASE_IND
 *  when error count exceeds 10 to flush queues and clear tx/rx states.
 *
 *  Revision 1.4  1997/06/02 08:24:26  matthewg
 *  Updated copy count and other sizes to refine .bss/.data usage.
 *
 *  Revision 1.3  1997/05/13 22:34:51  matthewg
 *  Minor changes while testing.
 *
 *  Revision 1.2  1997/04/29 00:37:07  matthewg
 *  First pass after greenhills build.
 *
 *  Revision 1.1.1.1  1997/04/28 10:55:48  matthewg
 *  Transport Protocol software. This transport protocol is used to
 *  carry reliable or unreliable data across frame relay through
 *  either an unreliable or reliable (sliding window) transport
 *  protocol.
 *
 *  Initial checkin: Unrelable protocol PC emulation testing complete.
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */

#   include     "tp.h"
#   include     <dl_std.h>
#   include     <dl_xdef.h>
#   include     <bufintf.h>

/*  ---------------------------------------------------------------- */

typedef struct _tp_pk_inf_t_
  {
    tp_ser_t            ser;        /* Serial Number */
    tp_flg_t            flg;        /* Flags */
    tp_seq_t            seq;        /* Sequence Number */
    tp_seq_t            ack;        /* Acknowledgement Number */
  } tp_pk_inf_t;

typedef struct _tp_pk_t_
  {
    boolean_t           active;     /* Active? */
    struct _tp_pk_t_*   next;       /* Pointer to Next */
    tp_pk_inf_t         header;     /* Packet Header */
    u_long_t            tck;        /* Packet Lifetime */
    BufferDescriptor*   data;       /* Packet Data */
  } tp_pk_t;

typedef boolean_t (*tp_pk_hnd_t) (void* ref, tp_pk_t*);

/*  ---------------------------------------------------------------- */

#   define      TP_PK_LIST_SZ                   (512)

/*  ---------------------------------------------------------------- */

#   define      tp_pk_sze_min_get(pkt)          (0)
#   define      tp_pk_sze_max_get(pkt)          ((pkt)->data == NULL ? 0 : GetMaxBufferLengthFromBufDesc ((pkt)->data))
#   define      tp_pk_sze_get(pkt)              ((pkt)->data == NULL ? 0 : GetLengthFromBufDesc ((pkt)->data))
#   define      tp_pk_dat_get(pkt)              ((pkt)->data == NULL ? 0 : GetDataPtrFromBufDesc ((pkt)->data))

#   define      tp_pk_sze_min_set(pkt,s)        (0)
#   define      tp_pk_sze_max_set(pkt,s)        { if ((pkt)->data != NULL) SetMaxBufferLengthInBufDesc ((pkt)->data, (s)); }
#   define      tp_pk_sze_set(pkt,s)            { if ((pkt)->data != NULL) SetLengthInBufDesc ((pkt)->data, (s)); }

#   define      tp_pk_nxt_get(pkt)              ((pkt)->next)
#   define      tp_pk_nxt_set(pkt,next)         ((pkt)->next = (next))
#   define      tp_pk_tck_get(pkt)              ((pkt)->tck)
#   define      tp_pk_tck_set(pkt,tck)          ((pkt)->tck = (tck))

#   define      tp_pk_inf_sze                   (sizeof (tp_ser_t) + \
                                                 sizeof (tp_flg_t) + \
                                                 sizeof (tp_seq_t) + \
                                                 sizeof (tp_seq_t))
#   define      tp_pk_inf_pid_sze               (2)
#   define      tp_pk_inf_flg(inf)              ((inf)->flg)
#   define      tp_pk_inf_seq(inf)              ((inf)->seq)
#   define      tp_pk_inf_ack(inf)              ((inf)->ack)
#   define      tp_pk_inf_ser(inf)              ((inf)->ser)

#   define      tp_pk_dat_create(pkt)           (((pkt)->data = GetBufferDescriptor (cDL_MediumBufferSize)) == NULL ? false : true)
#   if      0
#   define      tp_pk_dat_offset(pkt)           (SetOffsetInBufDesc ((pkt)->data, 16))
#   else
#   define      tp_pk_dat_offset(pkt)
#   endif
#   define      tp_pk_dat_destroy(pkt)          (ReturnBufferDescriptor ((pkt)->data) == FALSE  ? false : true)

/*  ---------------------------------------------------------------- */

boolean_t       tp_pk_create      (void);
boolean_t       tp_pk_destroy     (void);

tp_pk_t*        tp_pk_allocate    (tp_pk_t* pkt);
tp_pk_t*        tp_pk_free        (tp_pk_t* pkt);

boolean_t       tp_pk_inf_set     (tp_pk_t* pkt, tp_pk_inf_t* inf);
boolean_t       tp_pk_inf_get     (tp_pk_t* pkt, tp_pk_inf_t* inf);
boolean_t       tp_pk_inf_clr     (tp_pk_t* pkt);

boolean_t       tp_pk_hdr_ins     (tp_pk_t* pkt);
boolean_t       tp_pk_hdr_rem     (tp_pk_t* pkt);

/*  ---------------------------------------------------------------- */

#   endif       /*_PACKT_H_*/

