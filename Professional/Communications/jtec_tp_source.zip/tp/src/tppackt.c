
/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol
 *  Matthew Gream, April 1997
 *  $Id: tppackt.c,v 1.7 1997/06/25 02:25:26 matthewg Exp $
 *  $Log: tppackt.c,v $
 *  Revision 1.7  1997/06/25 02:25:26  matthewg
 *  Modified header to work with new protocol.
 *
 *  Revision 1.6  1997/06/16 02:01:59  matthewg
 *  Fast Packet Interface changes.
 *
 *  Revision 1.5  1997/06/14 03:49:12  matthewg
 *  Added Statistics Information; inserted logic to handle DL_ESTABLISH_REQ
 *  and DL_RELEASE_REQ to synchronise end points; generate DL_RELEASE_IND
 *  when error count exceeds 10 to flush queues and clear tx/rx states.
 *
 *  Revision 1.4  1997/06/02 08:24:24  matthewg
 *  Updated copy count and other sizes to refine .bss/.data usage.
 *
 *  Revision 1.3  1997/05/16 07:10:14  matthewg
 *  Modifications for integration (resource copy == 0); major
 *  step in testing achieved for reliable transport protocol.
 *
 *  Revision 1.2  1997/05/13 22:34:51  matthewg
 *  Minor changes while testing.
 *
 *  Revision 1.1.1.1  1997/04/28 10:55:48  matthewg
 *  Transport Protocol software. This transport protocol is used to
 *  carry reliable or unreliable data across frame relay through
 *  either an unreliable or reliable (sliding window) transport
 *  protocol.
 *
 *  Initial checkin: Unrelable protocol PC emulation testing complete.
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */

#   include     "tppackt.h"
#   include     "tptask.h"
#   include     "tputlty.h"

/*  ---------------------------------------------------------------- */

static tp_pk_t          tp_pk_list [TP_PK_LIST_SZ];
static int              tp_pk_list_sze = TP_PK_LIST_SZ;

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_pid_set (u_byte_t* data, u_short_t* off)
  {
    data [(*off)++] = PID_TP_PACKET_INFO;
    data [(*off)++] = tp_pk_inf_sze;
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_pid_get (u_byte_t* data, u_short_t* off)
  {
    if (data [(*off)++] != PID_TP_PACKET_INFO)
        return false;
    if (data [(*off)++] != tp_pk_inf_sze)
        return false;
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_pid_fnd (u_byte_t* data, u_short_t len, u_short_t* off)
  {
    for (*off = 0;
         *off < len;
         *off += (data [*off + 1] + 2))
      {
        if (data [*off + 0] == PID_TP_PACKET_INFO &&
            data [*off + 1] == tp_pk_inf_sze)
          {
            return true;
          }
      }
    return false;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_ser_set (u_byte_t* data, u_short_t* off, tp_ser_t ser)
  {
    data [(*off)++] = ser & 0xFF;
    data [(*off)++] = (ser >> 8) & 0xFF;
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_ser_get (u_byte_t* data, u_short_t* off, tp_ser_t* ser)
  {
    (*ser) = (data [(*off)++] & 0xFF);
    (*ser) = ((*ser) << 8) | (data [(*off)++] & 0xFF);
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_flg_set (u_byte_t* data, u_short_t* off, tp_flg_t flg)
  {
    data [(*off)++] = flg;
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_flg_get (u_byte_t* data, u_short_t* off, tp_flg_t* flg)
  {
    (*flg) = data [(*off)++];
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_seq_set (u_byte_t* data, u_short_t* off, tp_seq_t seq)
  {
    data [(*off)++] = seq;
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_seq_get (u_byte_t* data, u_short_t* off, tp_seq_t* seq)
  {
    (*seq) = data [(*off)++];
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  ---------------------------------------------------------------- */

boolean_t tp_pk_create (void)
  {
    int index;
    for (index = 0;
         index < tp_pk_list_sze;
         index++)
      {
        tp_pk_t* pkt = &tp_pk_list [index];
        pkt->active = false;
      }
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_destroy (void)
  {
    int index;
    for (index = 0;
         index < tp_pk_list_sze;
         index++)
      {
        tp_pk_t* pkt = &tp_pk_list [index];
        if (pkt->active == true)
          {
            if (pkt->data != NULL)
                tp_pk_dat_destroy (pkt);
          }
      }
    return true;
  }

/*  ---------------------------------------------------------------- */

tp_pk_t* tp_pk_allocate (tp_pk_t* pkt)
  {
    tp_pk_t* new_pkt;
    static int idx = 0;
    int cnt;
#	ifdef	DEBUG_PACKT
	tp_print (tp_print_debug, "pk_allocate ():");
#	endif

    for (cnt = 0, new_pkt = NULL;
         cnt < tp_pk_list_sze && new_pkt == NULL;
         cnt++)
      {
        if (tp_pk_list [idx].active == false)
            new_pkt = &tp_pk_list [idx];
        if (++idx == tp_pk_list_sze)
            idx = 0;
      }
    if (new_pkt == NULL)
        return NULL;

    new_pkt->data = NULL;
    new_pkt->next = NULL;
    new_pkt->tck = 0;
    new_pkt->header.ser = 0;
    new_pkt->header.seq = 0;
    new_pkt->header.ack = 0;
    new_pkt->header.flg = 0;
    if (pkt != NULL)
      {
        if (tp_pk_dat_create (new_pkt) == false)
            return NULL;
        memcpy (tp_pk_dat_get (new_pkt),
                tp_pk_dat_get (pkt),
                tp_pk_sze_get (pkt));
        tp_pk_sze_set (new_pkt, tp_pk_sze_get (pkt));
        memcpy (&new_pkt->header,
                &pkt->header,
                sizeof (tp_pk_inf_t));
      }
    new_pkt->active = true;

    return new_pkt;
  }

/*  ---------------------------------------------------------------- */

tp_pk_t* tp_pk_free (tp_pk_t* pkt)
  {
#	ifdef	DEBUG_PACKT
	tp_print (tp_print_debug, "pk_free ():");
#	endif
    if (pkt->data != NULL)
        tp_pk_dat_destroy (pkt);
    pkt->active = false;
    return pkt;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_inf_set (tp_pk_t* pkt, tp_pk_inf_t* inf)
  {
    pkt->header = *inf;
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_inf_clr (tp_pk_t* pkt)
  {
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_inf_get (tp_pk_t* pkt, tp_pk_inf_t* inf)
  {
    *inf = pkt->header;
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_hdr_ins (tp_pk_t* pkt)
  {
    u_byte_t  arr [80];
    u_short_t len = tp_pk_sze_get (pkt);
    u_byte_t* dat = tp_pk_dat_get (pkt);
    u_short_t off = 0;
    u_short_t idx;

    if (tp_pk_pid_set (arr, &off) == false)
        return false;

    if (tp_pk_ser_set (arr, &off, pkt->header.ser) == false)
        return false;
    if (tp_pk_flg_set (arr, &off, pkt->header.flg) == false)
        return false;
    if (tp_pk_seq_set (arr, &off, pkt->header.seq) == false)
        return false;
    if (tp_pk_seq_set (arr, &off, pkt->header.ack) == false)
        return false;

    for (idx = len; idx-- > 0;)
        dat [off + idx] = dat [idx];
    for (idx = 0; idx < off; idx++)
        dat [idx] = arr [idx];
    tp_pk_sze_set (pkt, (len + off));

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_hdr_rem (tp_pk_t* pkt)
  {
    u_short_t off = 0;
    u_short_t len = tp_pk_sze_get (pkt);
    u_byte_t* dat = tp_pk_dat_get (pkt);
    u_short_t idx;

    if (tp_pk_pid_get (dat, &off) == false)
        return false;

    if (tp_pk_ser_get (dat, &off, &pkt->header.ser) == false)
        return false;
    if (tp_pk_flg_get (dat, &off, &pkt->header.flg) == false)
        return false;
    if (tp_pk_seq_get (dat, &off, &pkt->header.seq) == false)
        return false;
    if (tp_pk_seq_get (dat, &off, &pkt->header.ack) == false)
        return false;

    for (idx = 0; idx < (len - off); idx++)
        dat [idx] = dat [idx + off];
    tp_pk_sze_set (pkt, (len - off));

    return true;
  }

/*  ---------------------------------------------------------------- */

