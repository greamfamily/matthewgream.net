
#   ifndef      _UTLTY_H_
#   define      _UTLTY_H_

/*  ---------------------------------------------------------------- */
/*
 *  Resource Management Configuration
 *  Matthew Gream, April 1997
 *  $Id: tputlty.h,v 1.3 1997/06/06 02:00:06 matthewg Exp $
 *  $Log: tputlty.h,v $
 *  Revision 1.3  1997/06/06 02:00:06  matthewg
 *  Changed Msg Reserve (why didn't this get checked in before ...)
 *
 *  Revision 1.2  1997/05/08 06:12:08  matthewg
 *  Integrated/build/test of reliable part of software.
 *
 *  Revision 1.1.1.1  1997/05/06 04:39:16  matthewg
 *  Data Terminal source code for testing (loopback/generator/terminator
 *  stuff for a data stream).
 *
 *  Revision 1.3  1997/05/01 02:37:48  matthewg
 *  Integration first stage.
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */

#   include     "tp.h"

/*  ---------------------------------------------------------------- */

typedef enum
  {
    tp_print_none = 0,                              /* print none    */
    tp_print_error = 1,                             /* print errors  */
    tp_print_warn = 2,                              /* print warns   */
    tp_print_info = 3,                              /* print infos   */
    tp_print_debug = 4                              /* print debugs  */
  } tp_print_t;

/*  ---------------------------------------------------------------- */

boolean_t   tp_ut_create (void);
boolean_t   tp_ut_destroy (void);
boolean_t   tp_ut_message (MSGPTR msg);

boolean_t   tp_print (tp_print_t lev, const char* fmt, ...);
boolean_t   tp_dump (tp_print_t, MSGPTR msg);
boolean_t   tp_prhex (tp_print_t lev, const char* pre, u_short_t len, const u_byte_t* dat);
tp_print_t  tp_print_get (void);
boolean_t   tp_print_set (tp_print_t lev);

/*  ---------------------------------------------------------------- */

#   endif       /*_UTLTY_H_*/

