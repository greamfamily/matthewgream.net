
#   ifndef  _TASK_H
#   define  _TASK_H

/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol
 *  Matthew Gream, April 1997
 *  $Id: tptask.h,v 1.6 1997/06/14 03:49:17 matthewg Exp $
 *  $Log: tptask.h,v $
 *  Revision 1.6  1997/06/14 03:49:17  matthewg
 *  Added Statistics Information; inserted logic to handle DL_ESTABLISH_REQ
 *  and DL_RELEASE_REQ to synchronise end points; generate DL_RELEASE_IND
 *  when error count exceeds 10 to flush queues and clear tx/rx states.
 *
 *  Revision 1.5  1997/06/06 02:00:05  matthewg
 *  Changed Msg Reserve (why didn't this get checked in before ...)
 *
 *  Revision 1.4  1997/06/02 08:24:29  matthewg
 *  Updated copy count and other sizes to refine .bss/.data usage.
 *
 *  Revision 1.3  1997/05/13 22:34:53  matthewg
 *  Minor changes while testing.
 *
 *  Revision 1.2  1997/04/29 00:37:13  matthewg
 *  First pass after greenhills build.
 *
 *  Revision 1.1.1.1  1997/04/28 10:55:48  matthewg
 *  Transport Protocol software. This transport protocol is used to
 *  carry reliable or unreliable data across frame relay through
 *  either an unreliable or reliable (sliding window) transport
 *  protocol.
 *
 *  Initial checkin: Unrelable protocol PC emulation testing complete.
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */

#   include     "tp.h"
#   include     <rmtaskid.h>

/*  ---------------------------------------------------------------- */

#   define      _TASK_ID                (JEXEC_TASKID_TRANSPORT_PROTOCOL)
#   define      _TASK_NAME              ("TP")
#   define      _TASK_STSZ              (3072)
#   define      _TASK_PRIO              (3)
#   define      _TASK_OPTS              (0)
#   define      _TASK_RESV              (60)
#   define      _TASK_COPY              (TP_INSTANCE_MAX)
#   define      _TASK_VERS              (0x0100)

/*  ---------------------------------------------------------------- */

boolean Install_TransportProtocol (void);
boolean Remove_TransportProtocol (void);
void Execute_TransportProtocol (void);

/*  ---------------------------------------------------------------- */

#   endif   /*_TASK_H*/

