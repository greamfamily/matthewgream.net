
#   ifndef      _UPPER_H_
#   define      _UPPER_H_

/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol
 *  Matthew Gream, April 1997
 *  $Id: tpupper.h,v 1.7 1997/06/16 02:02:01 matthewg Exp $
 *  $Log: tpupper.h,v $
 *  Revision 1.7  1997/06/16 02:02:01  matthewg
 *  Fast Packet Interface changes.
 *
 *  Revision 1.6  1997/06/14 03:49:19  matthewg
 *  Added Statistics Information; inserted logic to handle DL_ESTABLISH_REQ
 *  and DL_RELEASE_REQ to synchronise end points; generate DL_RELEASE_IND
 *  when error count exceeds 10 to flush queues and clear tx/rx states.
 *
 *  Revision 1.5  1997/06/11 00:05:53  matthewg
 *  Enhanced debugging and reporting.
 *
 *  Revision 1.4  1997/06/02 08:24:31  matthewg
 *  Updated copy count and other sizes to refine .bss/.data usage.
 *
 *  Revision 1.3  1997/05/05 08:14:25  matthewg
 *  Modifications for in target build.
 *
 *  Revision 1.2  1997/04/29 00:37:17  matthewg
 *  First pass after greenhills build.
 *
 *  Revision 1.1.1.1  1997/04/28 10:55:48  matthewg
 *  Transport Protocol software. This transport protocol is used to
 *  carry reliable or unreliable data across frame relay through
 *  either an unreliable or reliable (sliding window) transport
 *  protocol.
 *
 *  Initial checkin: Unrelable protocol PC emulation testing complete.
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */

#   include     "tp.h"
#   include     "tppackt.h"
#   include     <rm_res.h>

/*  ---------------------------------------------------------------- */

#   define      TP_UP_LIST_SIZE            (TP_INSTANCE_MAX)

/*  ---------------------------------------------------------------- */

typedef struct _tp_up_ctx_                          /* ctx: defn     */
  {
    boolean_t           active;                     /* ctx: active   */

    tp_pk_hnd_t         lower_output;               /* lwr: output   */
    tp_actv_hnd_t       lower_activate;             /* lwr: activate */
    void*               lower_ctx;                  /* lwr: context  */

    tResourceCopy       upper_copy;                 /* upr: copy     */
    tResourceInfo       upper_resource;             /* upr: resource */

    tp_msg_hnd_t        excpt_handler;              /* exp: handler  */
    void*               excpt_ctx;                  /* exp: context  */

  } tp_up_ctx;                                      /* ctx: defn     */

/*  ---------------------------------------------------------------- */

boolean_t       tp_up_create           (void);
boolean_t       tp_up_destroy          (void);

boolean_t       tp_up_message          (MSGPTR msg);
boolean_t       tp_up_control          (MSGPTR msg);

tp_up_ctx*      tp_up_allocate         (tResourceCopy copy);
tp_up_ctx*      tp_up_locate           (tResourceCopy copy);

boolean_t       tp_up_free             (tp_up_ctx* ctx);
boolean_t       tp_up_config           (tp_up_ctx* ctx, MSGPTR msg);
boolean_t       tp_up_connect          (tp_up_ctx* ctx);
boolean_t       tp_up_disconnect       (tp_up_ctx* ctx);
boolean_t       tp_up_status           (tp_up_ctx* ctx);

boolean_t       tp_up_upper_set        (tp_up_ctx* ctx, tResourceInfo* info);
boolean_t       tp_up_lower_set        (tp_up_ctx* ctx, tp_pk_hnd_t output_hnd, tp_actv_hnd_t activate_hnd, void* ref);
boolean_t       tp_up_excpt_set        (tp_up_ctx* ctx, tp_msg_hnd_t hnd, void* ref);

boolean_t       tp_up_lower_activate   (tp_up_ctx* ctx, boolean_t state);

boolean_t       tp_up_lower_output     (tp_up_ctx* ctx, tp_pk_t* pkt);
boolean_t       tp_up_upper_output     (tp_up_ctx* ctx, word typ, tp_pk_t* pkt);
boolean_t       tp_up_excpt_output     (tp_up_ctx* ctx, char* msg);

boolean_t       tp_up_lower_except     (void* ref, char* msg);

boolean_t       tp_up_lower_input      (void* ref, tp_pk_t* pkt);
boolean_t       tp_up_upper_input      (void* ref, MSGPTR msg);
boolean_t       tp_up_timer_input      (void* ref, word tck);

boolean_t       tp_pk_enc_upper        (tp_pk_t* pkt, MSGPTR msg);
boolean_t       tp_pk_dec_upper        (tp_pk_t* pkt, MSGPTR msg);

/*  ---------------------------------------------------------------- */

#   endif       /*_UPPER_H_*/

