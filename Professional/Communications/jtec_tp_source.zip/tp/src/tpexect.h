
#   ifndef      _EXECT_H_
#   define      _EXECT_H_

/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol
 *  Matthew Gream, April 1997
 *  $Id: tpexect.h,v 1.1.1.1 1997/04/28 10:55:47 matthewg Exp $
 *  $Log: tpexect.h,v $
 *  Revision 1.1.1.1  1997/04/28 10:55:47  matthewg
 *  Transport Protocol software. This transport protocol is used to
 *  carry reliable or unreliable data across frame relay through
 *  either an unreliable or reliable (sliding window) transport
 *  protocol.
 *
 *  Initial checkin: Unrelable protocol PC emulation testing complete.
 *
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */

#   include     "tp.h"

/*  ---------------------------------------------------------------- */

boolean_t   tp_exect_create    (void);
boolean_t   tp_exect_execute   (void);
boolean_t   tp_exect_destroy   (void);

/*  ---------------------------------------------------------------- */

#   endif       /*_EXECT_H_*/

