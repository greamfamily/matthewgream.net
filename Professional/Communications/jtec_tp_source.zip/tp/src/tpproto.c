
/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol
 *  Matthew Gream, April 1997
 *  $Id: tpproto.c,v 1.5 1997/07/22 14:46:12 matthewg Exp $
 *  $Log: tpproto.c,v $
 *  Revision 1.5  1997/07/22 14:46:12  matthewg
 *  #defined out the code for performing lower layer loopbacks
 *  and also added in a macro to add an offset in the packets
 *  to fix this problem with the frame relay encapsulation not
 *  having enough space to put a header in.
 *
 *  Revision 1.4  1997/06/14 03:49:14  matthewg
 *  Added Statistics Information; inserted logic to handle DL_ESTABLISH_REQ
 *  and DL_RELEASE_REQ to synchronise end points; generate DL_RELEASE_IND
 *  when error count exceeds 10 to flush queues and clear tx/rx states.
 *
 *  Revision 1.3  1997/06/11 00:05:48  matthewg
 *  Enhanced debugging and reporting.
 *
 *  Revision 1.2  1997/05/08 06:11:59  matthewg
 *  Integrated/build/test of reliable part of software.
 *
 *  Revision 1.1.1.1  1997/04/28 10:55:48  matthewg
 *  Transport Protocol software. This transport protocol is used to
 *  carry reliable or unreliable data across frame relay through
 *  either an unreliable or reliable (sliding window) transport
 *  protocol.
 *
 *  Initial checkin: Unrelable protocol PC emulation testing complete.
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */

#   include     "tpproto.h"
#   include     "tputlty.h"

/*  ---------------------------------------------------------------- */

static tp_pr_ctx    tp_pr_list [TP_PR_LIST_SIZE];
static int          tp_pr_list_size = TP_PR_LIST_SIZE;

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_create (void)
  {
    int index;
    for (index = 0;
         index < tp_pr_list_size;
         index++)
      {
        tp_pr_ctx* ctx = &tp_pr_list [index];
        ctx->active = false;
      }
    if (tp_pr_rtp_create () == false)
        return false;
    if (tp_pr_utp_create () == false)
        return false;
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_destroy (void)
  {
    int index;
    for (index = 0;
         index < tp_pr_list_size;
         index++)
      {
        tp_pr_ctx* ctx = &tp_pr_list [index];
        if (ctx->active == true)
          {
            tp_pr_disconnect (ctx);
            tp_pr_free (ctx);
          }
      }
    if (tp_pr_rtp_destroy () == false)
        ;
    if (tp_pr_utp_destroy () == false)
        ;
    return true;
  }

/*  ---------------------------------------------------------------- */

tp_pr_ctx* tp_pr_allocate (tp_ex_typ typ)
  {
    tp_pr_ctx* ctx = NULL;
    int index = 0;

#	ifdef	DEBUG_PROTO
	tp_print (tp_print_debug, "pr_allocate ():");
#	endif
    while (index < tp_pr_list_size &&
           ctx == NULL)
      {
        ctx = &tp_pr_list [index++];
        if (ctx->active == true)
            ctx = NULL;
      }
    if (ctx == NULL)
        return NULL;

    ctx->tm_tck = TP_PR_TIMER_TICKS;
    ctx->tm_ctx = NULL;
    ctx->ex_typ = typ;

    switch (ctx->ex_typ)
      {
        default:
        case tp_ex_typ_none:
            return NULL;
        case tp_ex_typ_unreliable:
            if (tp_pr_utp_ctor (&ctx->utp_ctx) == false)
                return NULL;
            break;
        case tp_ex_typ_reliable:
            if (tp_pr_rtp_ctor (&ctx->rtp_ctx) == false)
                return NULL;
            break;
      }

    ctx->active = true;

    return ctx;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_free (tp_pr_ctx* ctx)
  {
    if (ctx->active == false)
        return true;
    ctx->active = false;

#	ifdef	DEBUG_PROTO
	tp_print (tp_print_debug, "pr_free ():");
#	endif
    switch (ctx->ex_typ)
      {
        case tp_ex_typ_none:
            break;
        case tp_ex_typ_unreliable:
            tp_pr_utp_dtor (&ctx->utp_ctx);
            break;
        case tp_ex_typ_reliable:
            tp_pr_rtp_dtor (&ctx->rtp_ctx);
            break;
      }

    if (ctx->tm_ctx != NULL)
      {
        tp_tm_free (ctx->tm_ctx);
        ctx->tm_ctx = NULL;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_config (tp_pr_ctx* ctx, MSGPTR msg)
  {
#	ifdef	DEBUG_PROTO
	tp_print (tp_print_debug, "pr_config ():");
#	endif
    switch (ctx->ex_typ)
      {
        case tp_ex_typ_none:
            break;
        case tp_ex_typ_unreliable:
            if (tp_pr_utp_config (&ctx->utp_ctx, msg) == false)
                return false;
            break;
        case tp_ex_typ_reliable:
            if (tp_pr_rtp_config (&ctx->rtp_ctx, msg) == false)
                return false;
            break;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_status (tp_pr_ctx* ctx)
  {
#   ifdef   DEBUG_PROTO
    tp_print (tp_print_debug, "pr_status ():");
#	endif

    switch (ctx->ex_typ)
      {
        case tp_ex_typ_none:
            break;
        case tp_ex_typ_unreliable:
            tp_pr_utp_status (&ctx->utp_ctx);
            break;
        case tp_ex_typ_reliable:
            tp_pr_rtp_status (&ctx->rtp_ctx);
            break;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_connect (tp_pr_ctx* ctx)
  {
#	ifdef	DEBUG_PROTO
	tp_print (tp_print_debug, "pr_connect ():");
#	endif

    if ((ctx->tm_ctx = tp_tm_allocate ()) == NULL)
        return false;
    if (tp_tm_handler_set (ctx->tm_ctx, tp_pr_timer_input, (void *) ctx) == false)
        return false;
    if (tp_tm_ticks_set (ctx->tm_ctx, ctx->tm_tck) == false)
        return false;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_disconnect (tp_pr_ctx* ctx)
  {
#	ifdef	DEBUG_PROTO
	tp_print (tp_print_debug, "pr_disconnect ():");
#	endif

    if (ctx->tm_ctx != NULL)
      {
        tp_tm_free (ctx->tm_ctx);
        ctx->tm_ctx = NULL;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_upper_activate (void* ref, boolean_t state)
  {
    tp_pr_ctx* ctx = ref;
#	ifdef	DEBUG_PROTO
    tp_print (tp_print_debug, "pr_upper_activate ():");
#	endif

    switch (ctx->ex_typ)
      {
        case tp_ex_typ_none:
            break;
        case tp_ex_typ_unreliable:
            if (state == true)
                if (tp_pr_utp_connect (&ctx->utp_ctx) == false)
                    return false;
            else if (state == false)
                if (tp_pr_utp_disconnect (&ctx->utp_ctx) == false)
                    return false;
            break;
        case tp_ex_typ_reliable:
            if (state == true)
                if (tp_pr_rtp_connect (&ctx->rtp_ctx) == false)
                    return false;
            else if (state == false)
                if (tp_pr_rtp_disconnect (&ctx->rtp_ctx) == false)
                    return false;
            break;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_upper_input (void* ref, tp_pk_t* pkt)
  {
    tp_pr_ctx* ctx = ref;
#	ifdef	DEBUG_PROTO
	tp_print (tp_print_debug, "pr_upper_input ():");
#	endif
    switch (ctx->ex_typ)
      {
        case tp_ex_typ_none:
            break;
        case tp_ex_typ_unreliable:
            if (tp_pr_utp_upper_input (&ctx->utp_ctx, pkt) == false)
                return false;
            break;
        case tp_ex_typ_reliable:
            if (tp_pr_rtp_upper_input (&ctx->rtp_ctx, pkt) == false)
                return false;
            break;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_lower_input (void* ref, tp_pk_t* pkt)
  {
    tp_pr_ctx* ctx = ref;
#	ifdef	DEBUG_PROTO
	tp_print (tp_print_debug, "pr_lower_input ():");
#	endif
    switch (ctx->ex_typ)
      {
        case tp_ex_typ_none:
            break;
        case tp_ex_typ_unreliable:
            if (tp_pr_utp_lower_input (&ctx->utp_ctx, pkt) == false)
                return false;
            break;
        case tp_ex_typ_reliable:
            if (tp_pr_rtp_lower_input (&ctx->rtp_ctx, pkt) == false)
                return false;
            break;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_timer_input (void* ref, word tck)
  {
    tp_pr_ctx* ctx = ref;
#	ifdef	DEBUG_PROTO
	tp_print (tp_print_debug, "pr_timer_input ():");
#	endif
    switch (ctx->ex_typ)
      {
        case tp_ex_typ_none:
            break;
        case tp_ex_typ_unreliable:
            if (tp_pr_utp_timer_input (&ctx->utp_ctx, tck) == false)
                return false;
            break;
        case tp_ex_typ_reliable:
            if (tp_pr_rtp_timer_input (&ctx->rtp_ctx, tck) == false)
                return false;
            break;
      }

    if ((ctx->tm_ctx = tp_tm_allocate ()) == NULL)
        return false;
    if (tp_tm_handler_set (ctx->tm_ctx, tp_pr_timer_input, (void *) ctx) == false)
        return false;
    if (tp_tm_ticks_set (ctx->tm_ctx, ctx->tm_tck) == false)
        return false;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_lower_set (tp_pr_ctx* ctx, tp_pk_hnd_t hnd, void* ref)
  {
    switch (ctx->ex_typ)
      {
        case tp_ex_typ_none:
            break;
        case tp_ex_typ_unreliable:
            if (tp_pr_utp_lower_set (&ctx->utp_ctx, hnd, ref) == false)
                return false;
            break;
        case tp_ex_typ_reliable:
            if (tp_pr_rtp_lower_set (&ctx->rtp_ctx, hnd, ref) == false)
                return false;
            break;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_upper_set (tp_pr_ctx* ctx, tp_pk_hnd_t hnd, void* ref)
  {
    switch (ctx->ex_typ)
      {
        case tp_ex_typ_none:
            break;
        case tp_ex_typ_unreliable:
            if (tp_pr_utp_upper_set (&ctx->utp_ctx, hnd, ref) == false)
                return false;
            break;
        case tp_ex_typ_reliable:
            if (tp_pr_rtp_upper_set (&ctx->rtp_ctx, hnd, ref) == false)
                return false;
            break;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pr_excpt_set (tp_pr_ctx* ctx, tp_msg_hnd_t hnd, void* ref)
  {
    switch (ctx->ex_typ)
      {
        case tp_ex_typ_none:
            break;
        case tp_ex_typ_unreliable:
            if (tp_pr_utp_excpt_set (&ctx->utp_ctx, hnd, ref) == false)
                return false;
            break;
        case tp_ex_typ_reliable:
            if (tp_pr_rtp_excpt_set (&ctx->rtp_ctx, hnd, ref) == false)
                return false;
            break;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

