
/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol
 *  Matthew Gream, April 1997
 *  $Id: tprmgmt.c,v 1.7 1997/06/17 06:30:16 matthewg Exp $
 *  $Log: tprmgmt.c,v $
 *  Revision 1.7  1997/06/17 06:30:16  matthewg
 *  Miscellaneous debugging changes.
 *
 *  Revision 1.6  1997/06/14 03:49:15  matthewg
 *  Added Statistics Information; inserted logic to handle DL_ESTABLISH_REQ
 *  and DL_RELEASE_REQ to synchronise end points; generate DL_RELEASE_IND
 *  when error count exceeds 10 to flush queues and clear tx/rx states.
 *
 *  Revision 1.5  1997/06/11 00:05:50  matthewg
 *  Enhanced debugging and reporting.
 *
 *  Revision 1.4  1997/05/16 07:10:15  matthewg
 *  Modifications for integration (resource copy == 0); major
 *  step in testing achieved for reliable transport protocol.
 *
 *  Revision 1.3  1997/05/08 06:12:00  matthewg
 *  Integrated/build/test of reliable part of software.
 *
 *  Revision 1.2  1997/05/05 08:14:22  matthewg
 *  Modifications for in target build.
 *
 *  Revision 1.1.1.1  1997/04/28 10:55:48  matthewg
 *  Transport Protocol software. This transport protocol is used to
 *  carry reliable or unreliable data across frame relay through
 *  either an unreliable or reliable (sliding window) transport
 *  protocol.
 *
 *  Initial checkin: Unrelable protocol PC emulation testing complete.
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */

#   include     "tprmgmt.h"
#   include     "tptask.h"
#   include     "tputlty.h"
#   include     <rm_res_l.h>

/*  ---------------------------------------------------------------- */

tResourceCopy       g_tp_copy = RM_RESOURCE_COPY_NULL;

static tp_rm_ctx    tp_rm_list [TP_RM_LIST_SZ];
static int          tp_rm_list_size = TP_RM_LIST_SZ;

/*  ---------------------------------------------------------------- */

boolean_t tp_rm_create (void)
  {
    int index;

    for (index = 0;
         index < tp_rm_list_size;
         index++)
      {
        tp_rm_ctx* ctx = &tp_rm_list [index];
        ctx->active = false;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_rm_destroy (void)
  {
    int index;

    for (index = 0;
         index < tp_rm_list_size;
         index++)
      {
        tp_rm_ctx* ctx = &tp_rm_list [index];
        if (ctx->active == true)
          {
            tp_rm_issue_disconnect (ctx->copy);
            tp_rm_disconnect (ctx);
            tp_rm_free (ctx);
          }
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_rm_message (MSGPTR msg)
  {
#   ifdef   DEBUG_RMGMT
    tp_print (tp_print_debug, "rm_message ():");
#   endif

#   if  0
    if (msg->source_id != JEXEC_TASKID_RESOURCE_MANAGER)
        return false;
#   endif

    g_tp_copy = msg->parameter [0];

    switch (msg->type)
      {
        case M_CONNECT_REQ:
            if (tp_rm_accpt_connect (msg) == false)
                tp_rm_issue_disconnect (msg->parameter [0]);
            break;

        case M_DISCONNECT_REQ:
            if (tp_rm_accpt_disconnect (msg) == false)
                ;
            break;

        case M_CONTROL_REQ:
            if (tp_rm_accpt_control (msg) == false)
                tp_rm_issue_disconnect (msg->parameter [0]);
            break;

        default:
#   ifdef   DEBUG_RMGMT
            tp_print (tp_print_debug, "rm_message (): [???: %04X]", msg->type);
#   endif
            tp_rm_issue_disconnect (msg->parameter [0]);
            return false;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_rm_accpt_connect (MSGPTR msg)
  {
    tResourceCopy copy;
    u_byte_t type;
    tp_rm_ctx* ctx;

    copy = msg->parameter [0];

    ctx = tp_rm_locate (copy);
    if (ctx != NULL)
        tp_rm_free (ctx);

    if (IsolatePID (msg,
                    PID_TP_TYPE,
                    (u_byte_t *)&type,
                    1) == 0)
        return false;

    ctx = tp_rm_allocate (copy, type);
    if (ctx == NULL)
        return false;

#   ifdef   DEBUG_RMGMT
    tp_print (tp_print_debug, "rm_accpt_connect (%08X): copy (%02X)", ctx, copy);
#   endif

    if (tp_rm_config (ctx, msg) == false)
      {
        tp_rm_free (ctx);
        return false;
      }

    if (tp_rm_connect (ctx) == false)
      {
        tp_rm_free (ctx);
        return false;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_rm_accpt_disconnect (MSGPTR msg)
  {
    tResourceCopy copy;
    tp_rm_ctx* ctx;

    copy = msg->parameter [0];

    ctx = tp_rm_locate (copy);
    if (ctx == NULL)
        return false;

#   ifdef   DEBUG_RMGMT
    tp_print (tp_print_debug, "rm_accpt_disconnect (%08X): copy (%02X)", ctx, copy);
#   endif

    if (tp_rm_disconnect (ctx) == false)
      {
        tp_rm_free (ctx);
        return false;
      }

    tp_rm_free (ctx);

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_rm_accpt_control (MSGPTR msg)
  {
    tResourceCopy copy;
    tp_rm_ctx* ctx;

    copy = msg->parameter [0];

    switch (copy)
      {
        case RM_RESOURCE_COPY_NULL:
            if (tp_up_control (msg) == false)
                ;
            if (tp_lw_control (msg) == false)
                ;
            break;

        default:
            ctx = tp_rm_locate (copy);
            if (ctx == NULL)
                return false;
#   ifdef   DEBUG_RMGMT
            tp_print (tp_print_debug, "rm_accpt_control (%08X): copy (%02X)", ctx, copy);
#   endif
            break;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_rm_issue_disconnect (tResourceCopy copy)
  {
    tResourceInfo resource;
    MSGPTR msg;

    msg = JexecNewMessage (_TASK_ID);
    if (msg == NULL)
        return false;

    resource.Id = _TASK_ID;
    resource.Copy = copy;
    resource.Module = MM_MODULE_ID_NULL;

    msg->type = M_DISCONNECT_IND;
    msg->length = 0;
    msg->parameter [0] = copy;
    msg->parameter [1] = RM_RESOURCE_COPY_NULL;
    AddPID (msg, PID_SUBTYPE,
                 SUBTYPE_RM_RESOURCE_CONTROL,
                 1);
    if (rm_EncodeResourcePID (msg, &resource) == false)
      {
        JexecReturnMessage (_TASK_ID, msg);
        return false;
      }

#   ifdef   DEBUG_RMGMT
    tp_print (tp_print_debug, "rm_issu_disconnect (): id (%04X), copy (%02X), modu (%02X)", resource.Id, resource.Copy, resource.Module);
#   endif

    if (JexecSendMessage (JEXEC_TASKID_RESOURCE_MANAGER, msg) == FALSE)
      {
        JexecReturnMessage (_TASK_ID, msg);
        return false;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

tp_rm_ctx* tp_rm_locate (tResourceCopy copy)
  {
    tp_rm_ctx* ctx;

    ctx = &tp_rm_list [copy];
    if (ctx->active == false)
        return NULL;

    return ctx;
  }

/*  ---------------------------------------------------------------- */

tp_rm_ctx* tp_rm_allocate (tResourceCopy copy, tp_ex_typ type)
  {
    tp_rm_ctx* ctx;

#   ifdef   DEBUG_RMGMT
    tp_print (tp_print_debug, "rm_allocate ():");
#   endif

    ctx = &tp_rm_list [copy];
    if (ctx->active == true)
        return NULL;

    if ((ctx->lower_ctx = tp_lw_allocate (copy)) == NULL)
        return NULL;
    if ((ctx->proto_ctx = tp_pr_allocate (type)) == NULL)
        return NULL;
    if ((ctx->upper_ctx = tp_up_allocate (copy)) == NULL)
        return NULL;
    ctx->copy = copy;
    ctx->active = true;

    return ctx;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_rm_free (tp_rm_ctx* ctx)
  {
    if (ctx->active == false)
        return true;

#   ifdef   DEBUG_RMGMT
    tp_print (tp_print_debug, "rm_free ():");
#   endif
    tp_lw_free (ctx->lower_ctx);
    tp_pr_free (ctx->proto_ctx);
    tp_up_free (ctx->upper_ctx);
    ctx->copy = 0;
    ctx->active = false;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_rm_status (tResourceCopy copy)
  {
    tp_rm_ctx* ctx;

    ctx = tp_rm_locate (copy);
    if (ctx == NULL)
        return false;

    tp_print (tp_print_none, "TP Status: (Copy %d) (Active %d)",
            ctx->copy, ctx->active);
    tp_lw_status (ctx->lower_ctx);
    tp_pr_status (ctx->proto_ctx);
    tp_up_status (ctx->upper_ctx);

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_rm_config (tp_rm_ctx* ctx, MSGPTR msg)
  {
#   ifdef   RM_RESMGMT_DEBUG
    jprintf ("Transport Protocol (): Resource Configure(%d)", ctx->copy);
#   endif

#   ifdef   DEBUG_RMGMT
    tp_print (tp_print_debug, "rm_config ():");
#   endif

    if (rm_DecodeLowerLayer (msg, &ctx->lower_resource) == false)
        return false;
#   ifdef   DEBUG_RMGMT
    tp_print (tp_print_debug, "rm_config (%08X): lower_res - id (%04X), copy (%02X), modu (%02X)", ctx, ctx->lower_resource.Id, ctx->lower_resource.Copy, ctx->lower_resource.Module);
#   endif

    if (rm_DecodeUpperLayer (msg, &ctx->upper_resource) == false)
        return false;
#   ifdef   DEBUG_RMGMT
    tp_print (tp_print_debug, "rm_config (%08X): upper_res - id (%04X), copy (%02X), modu (%02X)", ctx, ctx->upper_resource.Id, ctx->upper_resource.Copy, ctx->upper_resource.Module);
#   endif

    if (tp_lw_config (ctx->lower_ctx, msg) == false)
        return false;
    if (tp_pr_config (ctx->proto_ctx, msg) == false)
        return false;
    if (tp_up_config (ctx->upper_ctx, msg) == false)
        return false;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_rm_connect (tp_rm_ctx* ctx)
  {
#   ifdef   RM_RESMGMT_DEBUG
    jprintf ("Transport Protocol (): Resource Connect(%d)", ctx->copy);
#   endif

#   ifdef   DEBUG_RMGMT
    tp_print (tp_print_debug, "rm_connect ():");
#   endif

    if (tp_lw_lower_set (ctx->lower_ctx, &ctx->lower_resource) == false)
        return false;
    if (tp_lw_upper_set (ctx->lower_ctx, tp_pr_lower_input, ctx->proto_ctx) == false)
        return false;
    if (tp_lw_excpt_set (ctx->lower_ctx, tp_rm_except,      ctx) == false)
        return false;

    if (tp_pr_lower_set (ctx->proto_ctx, tp_lw_upper_input, ctx->lower_ctx) == false)
        return false;
    if (tp_pr_upper_set (ctx->proto_ctx, tp_up_lower_input, ctx->upper_ctx) == false)
        return false;
    if (tp_pr_excpt_set (ctx->proto_ctx, tp_up_lower_except, ctx->upper_ctx) == false)
        return false;

    if (tp_up_lower_set (ctx->upper_ctx, tp_pr_upper_input, tp_pr_upper_activate, ctx->proto_ctx) == false)
        return false;
    if (tp_up_upper_set (ctx->upper_ctx, &ctx->upper_resource) == false)
        return false;
    if (tp_up_excpt_set (ctx->upper_ctx, tp_rm_except,      ctx) == false)
        return false;

    if (tp_lw_connect (ctx->lower_ctx) == false)
        return false;
    if (tp_pr_connect (ctx->proto_ctx) == false)
        return false;
    if (tp_up_connect (ctx->upper_ctx) == false)
        return false;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_rm_disconnect (tp_rm_ctx* ctx)
  {
#   ifdef   RM_RESMGMT_DEBUG
    jprintf ("Transport Protocol (): Resource Disconnect(%d)", ctx->copy);
#   endif

#   ifdef   DEBUG_RMGMT
    tp_print (tp_print_debug, "rm_disconnect ():");
#   endif

    if (tp_lw_disconnect (ctx->lower_ctx) == false)
        return false;
    if (tp_pr_disconnect (ctx->proto_ctx) == false)
        return false;
    if (tp_up_disconnect (ctx->upper_ctx) == false)
        return false;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_rm_except (void* ref, char* msg)
  {
    tp_rm_ctx* ctx = ref;
    tp_print (tp_print_error, "rm_except (%08X): msg (%s)", ctx, msg);

    tp_rm_issue_disconnect (ctx->copy);
    tp_rm_disconnect (ctx);
    tp_rm_free (ctx);

    return true;
  }

/*  ---------------------------------------------------------------- */

