
/*  ---------------------------------------------------------------- */
/*
 *  Data Terminal
 *  Matthew Gream, April 1997
 *  $Id: tputlty.c,v 1.6 1997/06/18 00:20:50 matthewg Exp $
 *  $Log: tputlty.c,v $
 *  Revision 1.6  1997/06/18 00:20:50  matthewg
 *  Change default reporting level from "info" to "warn".
 *
 *  Revision 1.5  1997/06/14 03:49:20  matthewg
 *  Added Statistics Information; inserted logic to handle DL_ESTABLISH_REQ
 *  and DL_RELEASE_REQ to synchronise end points; generate DL_RELEASE_IND
 *  when error count exceeds 10 to flush queues and clear tx/rx states.
 *
 *  Revision 1.4  1997/06/11 00:05:54  matthewg
 *  Enhanced debugging and reporting.
 *
 *  Revision 1.3  1997/05/13 22:34:53  matthewg
 *  Minor changes while testing.
 *
 *  Revision 1.2  1997/05/08 06:12:06  matthewg
 *  Integrated/build/test of reliable part of software.
 *
 *  Revision 1.1.1.1  1997/05/06 04:39:15  matthewg
 *  Data Terminal source code for testing (loopback/generator/terminator
 *  stuff for a data stream).
 *
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */
/*  Utility: Headers */

#   include     "tputlty.h"
#   include     <stdio.h>
#   include     <ctype.h>
#   include     <stdarg.h>
#   include     <monpub.h>
#   include     <cm2.h>
#   include     <rtc.h>

/*  ---------------------------------------------------------------- */

#   define      _HEX_LO(b)          ((b) & 0x0F)
#   define      _HEX_CHK(c)         (isxdigit(c))
#   define      _HEX_CHR(b)         (_HEX_LO (b) < 0x0A ? (_HEX_LO (b) + '0') : (_HEX_LO (b) - 0x0A + 'A'))
#   define      _HEX_CHR_LO(b)      _HEX_CHR ((b))
#   define      _HEX_CHR_HI(b)      _HEX_CHR ((b) >> 4)

/*  ---------------------------------------------------------------- */
/*  Utility: Data */

static tp_print_t tp_print_level = tp_print_none;

/*  ---------------------------------------------------------------- */
/*  Utility: Create */

boolean_t tp_ut_create (void)
  {
    tp_print_level = tp_print_warn;
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Utility: Destroy */

boolean_t tp_ut_destroy (void)
  {
    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Utility: Message */

boolean_t tp_ut_message (MSGPTR msg)
  {
    switch (msg->type)
      {
        case JEXEC_START_UP:
		case JEXEC_COMMAND:
            tp_print_set (msg->parameter [0]);
            break;

        default:
            return false;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Utility: Time */

const char* tp_time (void)
  {
    static char time_str [9];
    TIME time_val;
    GetTime (&time_val);
    time_str [0] = ((time_val.hour / 10) % 10) + '0';
    time_str [1] = (time_val.hour % 10) + '0';
    time_str [2] = ':';
    time_str [3] = ((time_val.minute / 10) % 10) + '0';
    time_str [4] = (time_val.minute % 10) + '0';
    time_str [5] = ':';
    time_str [6] = ((time_val.second / 10) % 10) + '0';
    time_str [7] = (time_val.second % 10) + '0';
    time_str [8] = '\0';
    return time_str;
  }

/*  ---------------------------------------------------------------- */
/*  Print: Message */

boolean_t tp_print (tp_print_t lev, const char* fmt, ...)
  {
    if (lev > tp_print_level)
        return false;

      {
        va_list va;
        static char buffer [128];

        va_start (va, fmt);
        vsprintf (buffer, fmt, va);
        va_end (va);
        jprintf ("[%s] fr_txp: %s", tp_time (), buffer);
      }

    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Print: Dump */

boolean_t tp_dump (tp_print_t lev, MSGPTR msg)
  {
    if (lev > tp_print_level)
        return false;

      {
        jprintf ("[%s] fr_txp: dump message:", tp_time ());
        DumpCopy (msg);
      }

    return true;
  }

/*  ---------------------------------------------------------------- */
/*  Print: Hex */

boolean_t tp_prhex (tp_print_t lev, const char* pre, u_short_t len, const u_byte_t* dat)
  {
    if (lev > tp_print_level)
        return false;

      {
        u_short_t idx;
        u_short_t max;
        char* ptr_hex;
        char* ptr_chr;
        char buffer [45];

        max = len;
        while ((max & 0x07) != 0x00)
            max++;

        ptr_hex = &buffer [0];
        ptr_chr = &buffer [26];
        memset (buffer, ' ', sizeof (buffer));

        tp_print (lev, "%s: %d (0x%02X) bytes", pre, len, len);
        for (idx = 0; idx < max; idx++)
          {
            if (idx < len)
              {
                *ptr_hex++ = _HEX_CHR_HI (dat [idx]);
                *ptr_hex++ = _HEX_CHR_LO (dat [idx]);
                *ptr_hex++ = ' ';
                *ptr_chr++ = isprint (dat [idx]) ? dat [idx] : '.';
              }
            else
              {
                *ptr_hex++ = ' ';
                *ptr_hex++ = ' ';
                *ptr_hex++ = ' ';
                *ptr_chr++ = ' ';
              }
            if ((idx & 0x07) == 0x07)
              {
                *ptr_chr++ = '\0';
                tp_print (lev, "%s%04X: %s", pre, (idx - 0x07), buffer);
                ptr_hex = &buffer [0];
                ptr_chr = &buffer [26];
              }
          }
      }

    return true;
  }


/*  ---------------------------------------------------------------- */
/*  Print: Get Level */

tp_print_t tp_print_get (void)
  {
    return tp_print_level;
  }

/*  ---------------------------------------------------------------- */
/*  Print: Set Level */

boolean_t tp_print_set (tp_print_t lev)
  {
    const char* descr;
    switch (lev)
      {
        case 0x09:
        case tp_print_debug:
            descr = "debug";
            break;
        case tp_print_info:
            descr = "info";
            break;
        case tp_print_warn:
            descr = "warn";
            break;
        case tp_print_error:
            descr = "error";
            break;
        case tp_print_none:
            descr = "none";
            break;
        default:
            return false;
      }
    tp_print_level = lev;
    jprintf ("[%s] fr_txp: print level = %s (%d)", tp_time (), descr, lev);
    return true;
  }

/*  ---------------------------------------------------------------- */

