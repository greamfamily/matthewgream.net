
#   ifndef      _PROTO_H_
#   define      _PROTO_H_

/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol
 *  Matthew Gream, April 1997
 *  $Id: tpproto.h,v 1.5 1997/06/14 03:49:14 matthewg Exp $
 *  $Log: tpproto.h,v $
 *  Revision 1.5  1997/06/14 03:49:14  matthewg
 *  Added Statistics Information; inserted logic to handle DL_ESTABLISH_REQ
 *  and DL_RELEASE_REQ to synchronise end points; generate DL_RELEASE_IND
 *  when error count exceeds 10 to flush queues and clear tx/rx states.
 *
 *  Revision 1.4  1997/06/11 00:05:50  matthewg
 *  Enhanced debugging and reporting.
 *
 *  Revision 1.3  1997/06/02 08:24:27  matthewg
 *  Updated copy count and other sizes to refine .bss/.data usage.
 *
 *  Revision 1.2  1997/04/29 00:37:08  matthewg
 *  First pass after greenhills build.
 *
 *  Revision 1.1.1.1  1997/04/28 10:55:48  matthewg
 *  Transport Protocol software. This transport protocol is used to
 *  carry reliable or unreliable data across frame relay through
 *  either an unreliable or reliable (sliding window) transport
 *  protocol.
 *
 *  Initial checkin: Unrelable protocol PC emulation testing complete.
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */

#   include     "tp.h"
#   include     "tptimer.h"

#   include     "rtpproto.h"
#   include     "utpproto.h"

/*  ---------------------------------------------------------------- */

#   define      TP_PR_LIST_SIZE            (TP_INSTANCE_MAX)
#   define      TP_PR_TIMER_TICKS          (250 MILLISECONDS)

/*  ---------------------------------------------------------------- */

typedef enum {
    tp_ex_typ_none = 0,                             /* none */
    tp_ex_typ_unreliable = 1,                       /* unreliable */
    tp_ex_typ_reliable = 2                          /* reliable */
  } tp_ex_typ;

/*  ---------------------------------------------------------------- */

typedef struct _tp_pr_ctx_                          /* ctx: defn     */
  {
    boolean_t       active;                         /* ctx: active   */
    tp_tm_ctx*      tm_ctx;                         /* timer: ctx    */
    word            tm_tck;                         /* timer: tck    */
    union {
     tp_pr_rtp_ctx  ex_rtp_ctx;                     /* rtp: ctx      */
     tp_pr_utp_ctx  ex_utp_ctx;                     /* utp: ctx      */
    } ex_ctx;                                       /*  ex: ctx      */
#   define          rtp_ctx ex_ctx.ex_rtp_ctx
#   define          utp_ctx ex_ctx.ex_utp_ctx
    tp_ex_typ       ex_typ;                         /*  ex: typ      */
  }
tp_pr_ctx;                                          /* ctx: defn     */

/*  ---------------------------------------------------------------- */

boolean_t   tp_pr_create           (void);
boolean_t   tp_pr_destroy          (void);

tp_pr_ctx*  tp_pr_allocate         (tp_ex_typ typ);

boolean_t   tp_pr_free             (tp_pr_ctx* ctx);
boolean_t   tp_pr_config           (tp_pr_ctx* ctx, MSGPTR msg);
boolean_t   tp_pr_connect          (tp_pr_ctx* ctx);
boolean_t   tp_pr_disconnect       (tp_pr_ctx* ctx);
boolean_t   tp_pr_status           (tp_pr_ctx* ctx);

boolean_t   tp_pr_lower_set        (tp_pr_ctx* ctx, tp_pk_hnd_t hnd, void* ref);
boolean_t   tp_pr_upper_set        (tp_pr_ctx* ctx, tp_pk_hnd_t hnd, void* ref);
boolean_t   tp_pr_excpt_set        (tp_pr_ctx* ctx, tp_msg_hnd_t hnd, void* ref);

boolean_t   tp_pr_upper_activate   (void* ref, boolean_t state);
boolean_t   tp_pr_upper_input      (void* ref, tp_pk_t* pkt);
boolean_t   tp_pr_lower_input      (void* ref, tp_pk_t* pkt);
boolean_t   tp_pr_timer_input      (void* ref, word tck);

/*  ---------------------------------------------------------------- */

#   endif       /*_PROTO_H_*/

