
#   ifndef      _TP_H_
#   define      _TP_H_

/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol
 *  Matthew Gream, April 1997
 *  $Id: tp.h,v 1.11 1997/11/26 03:21:37 matthewg Exp $
 *  $Log: tp.h,v $
 *  Revision 1.11  1997/11/26 03:21:37  matthewg
 *  Change number of instances to be 32.
 *
 *  Revision 1.10  1997/06/25 02:24:51  matthewg
 *  Minor changes.
 *
 *  Revision 1.9  1997/06/17 06:30:15  matthewg
 *  Miscellaneous debugging changes.
 *
 *  Revision 1.8  1997/06/14 03:49:10  matthewg
 *  Added Statistics Information; inserted logic to handle DL_ESTABLISH_REQ
 *  and DL_RELEASE_REQ to synchronise end points; generate DL_RELEASE_IND
 *  when error count exceeds 10 to flush queues and clear tx/rx states.
 *
 *  Revision 1.7  1997/06/02 08:24:21  matthewg
 *  Updated copy count and other sizes to refine .bss/.data usage.
 *
 *  Revision 1.6  1997/05/20 02:03:08  matthewg
 *  Integration Update.
 *
 *  Revision 1.5  1997/05/18 22:41:33  matthewg
 *  Minor bug fixes.
 *
 *  Revision 1.4  1997/05/13 22:34:48  matthewg
 *  Minor changes while testing.
 *
 *  Revision 1.3  1997/05/08 06:11:53  matthewg
 *  Integrated/build/test of reliable part of software.
 *
 *  Revision 1.2  1997/05/05 08:15:59  matthewg
 *  Temporary specification of  define.
 *
 *  Revision 1.1.1.1  1997/04/28 10:55:48  matthewg
 *  Transport Protocol software. This transport protocol is used to
 *  carry reliable or unreliable data across frame relay through
 *  either an unreliable or reliable (sliding window) transport
 *  protocol.
 *
 *  Initial checkin: Unrelable protocol PC emulation testing complete.
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */

#   include     <jexec.h>
#   include     <jtecstd.h>

#   include     <j5000.h>
#   include     <j5pids.h>
#   include     <j5subtyp.h>
#   include     <j5msgs.h>
#   include     <jexeclib.h>
#   include     <rm_res.h>

/*  ---------------------------------------------------------------- */

typedef boolean_t (*tp_msg_hnd_t) (void* ref, char* msg);
typedef boolean_t (*tp_actv_hnd_t) (void* ref, boolean_t state);

/*  ---------------------------------------------------------------- */

typedef u_short_t   tp_ser_t;
typedef u_byte_t    tp_flg_t;
typedef u_short_t   tp_seq_t;

/*  ---------------------------------------------------------------- */

#   define  SEQ_MAX             (65536)
#   define  SEQ_RNG(a,b,s)      (((a) <= (b)) ? \
                                    ((s) >= (a) && (s) < (b)) : \
                                    (!((s) >= (b) && (s) < (a))))
#   define  SEQ_ADD(a,b)        (((a) + (b)) % SEQ_MAX)
#   define  SEQ_SUB(a,b)        ((((a) + SEQ_MAX) - (b)) % SEQ_MAX)
#   define  SEQ_INC(a)          ((a) = SEQ_ADD (a, 1))
#   define  SEQ_DEC(a)          ((a) = SEQ_SUB (a, 1))

/*  ---------------------------------------------------------------- */

extern tResourceCopy g_tp_copy;

/*  ---------------------------------------------------------------- */

#   define  TP_INSTANCE_MAX                 (32)

/*  ---------------------------------------------------------------- */

#   define  PID_TP_BASE                     (PID_TASK_BASE)
#   define  PID_TP_TYPE                     (PID_TP_BASE + 0x00)
#   define  PID_TP_PACKET_INFO              (PID_TP_BASE + 0x01)
#	define	PID_TP_REPORT_TIME				(PID_TP_BASE + 0x02)

/*  ---------------------------------------------------------------- */

#   endif       /*_TP_H_*/

