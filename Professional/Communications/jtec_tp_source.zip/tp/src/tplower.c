
/*  ---------------------------------------------------------------- */
/*
 *  Transport Protocol
 *  Matthew Gream, April 1997
 *  $Id: tplower.c,v 1.17 1997/09/08 01:19:06 matthewg Exp $
 *  $Log: tplower.c,v $
 *  Revision 1.17  1997/09/08 01:19:06  matthewg
 *  Added dump for input/output of messages.
 *
 *  Revision 1.16  1997/07/22 14:46:10  matthewg
 *  #defined out the code for performing lower layer loopbacks
 *  and also added in a macro to add an offset in the packets
 *  to fix this problem with the frame relay encapsulation not
 *  having enough space to put a header in.
 *
 *  Revision 1.15  1997/06/25 02:23:55  matthewg
 *  Stopped Header Encode/Decode because now the protocol module does it.
 *
 *  Revision 1.14  1997/06/17 06:30:16  matthewg
 *  Miscellaneous debugging changes.
 *
 *  Revision 1.13  1997/06/17 00:34:49  matthewg
 *  Changed where the copy must be placed.
 *
 *  Revision 1.12  1997/06/17 00:32:46  matthewg
 *  Added loopback facility to short circuit lower layer transmits so
 *  that we can determine where a data problem is occurring.
 *
 *  Revision 1.11  1997/06/16 05:56:39  matthewg
 *  Corrected frame_type.
 *
 *  Revision 1.10  1997/06/16 02:18:32  matthewg
 *  Removed static from tp_lw_message so that it does link.
 *
 *  Revision 1.9  1997/06/16 02:01:57  matthewg
 *  Fast Packet Interface changes.
 *
 *  Revision 1.8  1997/06/14 03:49:11  matthewg
 *  Added Statistics Information; inserted logic to handle DL_ESTABLISH_REQ
 *  and DL_RELEASE_REQ to synchronise end points; generate DL_RELEASE_IND
 *  when error count exceeds 10 to flush queues and clear tx/rx states.
 *
 *  Revision 1.7  1997/06/11 00:05:46  matthewg
 *  Enhanced debugging and reporting.
 *
 *  Revision 1.6  1997/06/02 08:24:22  matthewg
 *  Updated copy count and other sizes to refine .bss/.data usage.
 *
 *  Revision 1.5  1997/05/16 07:10:13  matthewg
 *  Modifications for integration (resource copy == 0); major
 *  step in testing achieved for reliable transport protocol.
 *
 *  Revision 1.4  1997/05/13 22:34:49  matthewg
 *  Minor changes while testing.
 *
 *  Revision 1.3  1997/05/08 06:11:56  matthewg
 *  Integrated/build/test of reliable part of software.
 *
 *  Revision 1.2  1997/05/05 08:14:19  matthewg
 *  Modifications for in target build.
 *
 *  Revision 1.1.1.1  1997/04/28 10:55:48  matthewg
 *  Transport Protocol software. This transport protocol is used to
 *  carry reliable or unreliable data across frame relay through
 *  either an unreliable or reliable (sliding window) transport
 *  protocol.
 *
 *  Initial checkin: Unrelable protocol PC emulation testing complete.
 *
 */
/*  ---------------------------------------------------------------- */

/*  ---------------------------------------------------------------- */

#   include     "tplower.h"
#   include     "tptask.h"
#   include     "tputlty.h"
#   include     <dl_msgs.h>
#   include     <pdatadef.h>
#   include     <frencap.h>
#   include     <bufintf.h>

/*  ---------------------------------------------------------------- */

static tp_lw_ctx    tp_lw_list [TP_LW_LIST_SIZE];
static int          tp_lw_list_size = TP_LW_LIST_SIZE;
static dword        tp_lw_frame_relay_id = 2;

/*  ---------------------------------------------------------------- */

boolean_t tp_lw_create (void)
  {
    int index;
#	ifdef	DEBUG_LOWER
	tp_print (tp_print_debug, "lw_create ():");
#	endif

    for (index = 0;
         index < tp_lw_list_size;
         index++)
      {
        tp_lw_ctx* ctx = &tp_lw_list [index];
        ctx->active = false;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_lw_destroy (void)
  {
    int index;
#	ifdef	DEBUG_LOWER
	tp_print (tp_print_debug, "lw_destroy ():");
#	endif

    for (index = 0;
         index < tp_lw_list_size;
         index++)
      {
        tp_lw_ctx* ctx = &tp_lw_list [index];
        if (ctx->active == true)
          {
            tp_lw_disconnect (ctx);
            tp_lw_free (ctx);
          }
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

static boolean_t tp_lw_message_noFR (MSGPTR msg)
  {
    tp_lw_ctx* ctx;
#   ifdef   DEBUG_LOWER
    tp_print (tp_print_debug, "lw_message ():");
    tp_dump (tp_print_debug, msg);
#   endif

    if ((ctx = tp_lw_locate_noFR (msg->parameter [0])) == NULL)
      {
        tp_print (tp_print_warn, "lw_message (): invalid copy (%d)", msg->parameter [0]);
        return false;
      }

    g_tp_copy = ctx->lower_copy;

    if (tp_lw_lower_input (ctx, msg) == false)
      {
        tp_print (tp_print_warn, "lw_message (): lower input failed");
        return false;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

static boolean_t tp_lw_message_FR (MSGPTR msg)
  {
    tp_lw_ctx* ctx;
    VirtualCircuitID virtual_circuit_id;
#   ifdef   DEBUG_LOWER
    tp_print (tp_print_debug, "lw_message ():");
    tp_dump (tp_print_debug, msg);
#   endif

    if (!IsolateVirtualCircuitIdPID (msg, &virtual_circuit_id))
      {
        tp_print (tp_print_warn, "lw_message (): can't find VcId in msg");
        return false;
      }

    if ((ctx = tp_lw_locate_FR (virtual_circuit_id.address)) == NULL)
      {
        tp_print (tp_print_warn, "lw_message (): invalid VcId address (%d)", virtual_circuit_id.address);
        return false;
      }

    g_tp_copy = ctx->lower_copy;

    if (tp_lw_lower_input (ctx, msg) == false)
      {
        tp_print (tp_print_warn, "lw_message (): lower input failed");
        return false;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_lw_message (MSGPTR msg)
  {
    if (msg->source_id == JEXEC_TASKID_PACKET_SWITCH_TASK)
        return tp_lw_message_FR (msg);
    else
        return tp_lw_message_noFR (msg);
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_lw_control (MSGPTR msg)
  {
    tp_lw_ctx* ctx;
#	ifdef	DEBUG_LOWER
    tp_print (tp_print_debug, "lw_control ():");
#	endif

#   ifdef   TP_LOOPBACK_ENABLED
    /* Hack: Provide a Loopback Facility */
    if (msg->parameter [1] != 0xF0)
        return false;

    if ((ctx = tp_lw_locate_noFR (msg->parameter [2])) == NULL)
        return false;
    ctx->loopback_enabled = true;
    ctx->loopback_copy = msg->parameter [3];

    if ((ctx = tp_lw_locate_noFR (msg->parameter [3])) == NULL)
        return false;
    ctx->loopback_enabled = true;
    ctx->loopback_copy = msg->parameter [2];

    tp_print (tp_print_none, "tp_lw_control (): LOOPBACK ENABLED (%02X -> %02X)",
        msg->parameter [2], msg->parameter [3]);
#   endif

    return true;
  }

/*  ---------------------------------------------------------------- */

tp_lw_ctx* tp_lw_allocate (tResourceCopy copy)
  {
    tp_lw_ctx* ctx;
#	ifdef	DEBUG_LOWER
	tp_print (tp_print_debug, "lw_allocate ():");
#	endif
    ctx = &tp_lw_list [copy];
    if (ctx->active == true)
        return NULL;

    ctx->upper_handler = NULL;
    ctx->upper_ctx = NULL;
    ctx->excpt_handler = NULL;
    ctx->excpt_ctx = NULL;
    ctx->lower_copy = copy;
    ctx->lower_resource.Id = RM_RESOURCE_ID_NULL;
    ctx->lower_resource.Copy = RM_RESOURCE_COPY_NULL;
    ctx->lower_resource.Module = MM_MODULE_ID_NULL;
    ctx->virtual_circuit_id.id = 0;
    ctx->virtual_circuit_id.address = 0;
    ctx->frame_type = 0;
#   ifdef   TP_LOOPBACK_ENABLED
    ctx->loopback_enabled = false;
    ctx->loopback_copy = 0;
#   endif
    ctx->active = true;

    return ctx;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_lw_free (tp_lw_ctx* ctx)
  {
#	ifdef	DEBUG_LOWER
	tp_print (tp_print_debug, "lw_free ():");
#	endif
    ctx->active = false;
    return true;
  }

/*  ---------------------------------------------------------------- */

tp_lw_ctx* tp_lw_locate_noFR (tResourceCopy copy)
  {
    tp_lw_ctx* ctx;

#	ifdef	DEBUG_LOWER
	tp_print (tp_print_debug, "lw_locate ():");
#	endif
    ctx = &tp_lw_list [copy];
    if (ctx->active == false)
        return NULL;

    return ctx;
  }

/*  ---------------------------------------------------------------- */

tp_lw_ctx* tp_lw_locate_FR (dword address)
  {
    tp_lw_ctx* ctx;
    int index;

#	ifdef	DEBUG_LOWER
	tp_print (tp_print_debug, "lw_locate ():");
#	endif
    for (index = 0;
         index < tp_lw_list_size;
         index++)
      {
        ctx = &tp_lw_list [index];
        if (ctx->active == true &&
            ctx->virtual_circuit_id.address == address)
            return ctx;
      }

    return NULL;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_lw_config (tp_lw_ctx* ctx, MSGPTR msg)
  {
    VirtualCircuitID virtual_circuit_id;

#	ifdef	DEBUG_LOWER
	tp_print (tp_print_debug, "lw_config ():");
#	endif

    if (!IsolateVirtualCircuitIdPID (msg, &virtual_circuit_id))
      {
        tp_print (tp_print_warn, "lw_config (): can't find virtual circuit id");
        return false;
      }

    ctx->virtual_circuit_id.id = tp_lw_frame_relay_id;
    ctx->virtual_circuit_id.address = virtual_circuit_id.id;
    ctx->frame_type = FR_FRAME_E2E_SIGNALLING;
    tp_print (tp_print_debug, "lw_config (): id(%d),addr(%d),type(%d)",
        ctx->virtual_circuit_id.id,
        ctx->virtual_circuit_id.address,
        ctx->frame_type);

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_lw_status (tp_lw_ctx* ctx)
  {
#	ifdef	DEBUG_LOWER
    tp_print (tp_print_debug, "lw_status ():");
#	endif

    tp_print (tp_print_none, "Lower (%08X): Copy %d", ctx, ctx->lower_copy);
    tp_print (tp_print_none, "  Upper Layer: Hnd %08X, Ctx %08X", ctx->upper_handler, ctx->upper_ctx);
    tp_print (tp_print_none, "  Lower Layer: ResId %04X, ResCopy %d", ctx->lower_resource.Id, ctx->lower_resource.Copy);
    tp_print (tp_print_none, "  Frame Param: VcId %04X, Addr %04X, Type %02X", ctx->virtual_circuit_id.id, ctx->virtual_circuit_id.address, ctx->frame_type);

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_lw_connect (tp_lw_ctx* ctx)
  {
#	ifdef	DEBUG_LOWER
	tp_print (tp_print_debug, "lw_connect ():");
#	endif

    if (tp_lw_lower_output (ctx, DL_ESTABLISH_REQ, NULL) == false)
        ;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_lw_disconnect (tp_lw_ctx* ctx)
  {
#	ifdef	DEBUG_LOWER
	tp_print (tp_print_debug, "lw_disconnect ():");
#	endif

    if (tp_lw_lower_output (ctx, DL_RELEASE_REQ, NULL) == false)
        ;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_lw_upper_input (void* ref, tp_pk_t* pkt)
  {
    tp_lw_ctx* ctx = ref;
#	ifdef	DEBUG_LOWER
	tp_print (tp_print_debug, "lw_upper_input ():");
#	endif

    if (tp_lw_lower_output (ctx, DL_DATA_REQ, pkt) == false)
        return false;
    if (tp_pk_free (pkt) == false)
        return false;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_lw_lower_input (void* ref, MSGPTR msg)
  {
    tp_lw_ctx* ctx = ref;

/*#   ifdef   DEBUG_LOWER*/
    tp_print (tp_print_debug, "Lower Input ():");
     tp_dump (tp_print_debug, msg);
/*#   endif*/

    switch (msg->type)
      {
        case DL_ESTABLISH_IND:
#   ifdef   DEBUG_LOWER
            tp_print (tp_print_debug, " > DL_ESTABLISH_IND");
#   endif
            break;

        case DL_RELEASE_IND:
#   ifdef   DEBUG_LOWER
            tp_print (tp_print_debug, " > DL_RELEASE_IND");
#   endif
            break;

        case DL_ESTABLISH_CON:
#   ifdef   DEBUG_LOWER
            tp_print (tp_print_debug, " > DL_ESTABLISH_CON");
#   endif
            break;

        case DL_RELEASE_CON:
#   ifdef   DEBUG_LOWER
            tp_print (tp_print_debug, " > DL_RELEASE_CON");
#   endif
            break;

        case DL_DATA_IND:
#   ifdef   DEBUG_LOWER
            tp_print (tp_print_debug, " > DL_DATA_IND");
#   endif
              {
                tp_pk_t* pkt;
                dword adr;
                FRFrameDataType typ;

                if ((pkt = tp_pk_allocate (NULL)) == NULL)
                  {
                    tp_print (tp_print_warn, "tp_lower_input (): packet allocation failed");
                    return false;
                  }

                if (
                    (ctx->lower_resource.Id == JEXEC_TASKID_PACKET_SWITCH_TASK && tp_pk_dec_lower_FR (pkt, msg, &adr, &typ) == false)
                  ||
                    (ctx->lower_resource.Id != JEXEC_TASKID_PACKET_SWITCH_TASK && tp_pk_dec_lower (pkt, msg) == false)
                   )
                  {
                    tp_print (tp_print_warn, "tp_lower_input (): packet decode failed");
                    tp_pk_free (pkt);
                    return false;
                  }

                if (tp_lw_upper_output (ctx, pkt) == false)
                  {
                    tp_pk_free (pkt);
                    return true;
                  }
              }

            break;

        default:

            return false;
      }

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_lw_timer_input (void* ref, word ticks)
  {
    tp_lw_ctx* ctx = ref;
#	ifdef	DEBUG_LOWER
	tp_print (tp_print_debug, "lw_timer_input ():");
#	endif

    return false;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_lw_lower_set (tp_lw_ctx* ctx, tResourceInfo* info)
  {
    memcpy (&ctx->lower_resource,
           info,
           sizeof (ctx->lower_resource));
    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_lw_upper_set (tp_lw_ctx* ctx, tp_pk_hnd_t hnd, void* ref)
  {
    ctx->upper_handler = hnd;
    ctx->upper_ctx = ref;

    return true;
  }

/*  ---------------------------------------------------------------- */
boolean_t tp_lw_excpt_set (tp_lw_ctx* ctx, tp_msg_hnd_t hnd, void* ref)
  {
    ctx->excpt_handler = hnd;
    ctx->excpt_ctx = ref;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_lw_upper_output (tp_lw_ctx* ctx, tp_pk_t* pkt)
  {
#	ifdef	DEBUG_LOWER
	tp_print (tp_print_debug, "lw_upper_output ():");
#	endif

    if (ctx->upper_handler == NULL)
        return false;
    if (ctx->upper_handler (ctx->upper_ctx, pkt) == false)
        return false;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_lw_lower_output (tp_lw_ctx* ctx, word type, tp_pk_t* pkt)
  {
    MSGPTR msg;

    if (ctx->lower_resource.Id == RM_RESOURCE_ID_NULL)
        return false;

    if ((msg = JexecNewMessage (_TASK_ID)) == NULL)
        return false;

    msg->length = 0;

    if (ctx->lower_resource.Id == JEXEC_TASKID_PACKET_SWITCH_TASK &&
        AddVirtualCircuitIdPID (msg, &ctx->virtual_circuit_id) == FALSE)
      {
        JexecReturnMessage (_TASK_ID, msg);
        return false;
      }

    if (pkt != NULL &&
      (
        (ctx->lower_resource.Id == JEXEC_TASKID_PACKET_SWITCH_TASK &&
         tp_pk_enc_lower_FR (pkt, msg, ctx->virtual_circuit_id.address, ctx->frame_type) == false)
      ||
        (ctx->lower_resource.Id != JEXEC_TASKID_PACKET_SWITCH_TASK &&
         tp_pk_enc_lower (pkt, msg) == false)
      ))
      {
        JexecReturnMessage (_TASK_ID, msg);
        return false;
      }

/*#   ifdef   DEBUG_LOWER*/
    tp_print (tp_print_debug, "Lower Output ():");
     tp_dump (tp_print_debug, msg);
/*#   endif*/

#   ifdef   TP_LOOPBACK_ENABLED
    if (ctx->loopback_enabled == false)
#   endif
      {
        msg->type = type;
        msg->parameter [0] = ctx->lower_resource.Copy;
        msg->parameter [1] = ctx->lower_copy;
        if (JexecSendMessage (ctx->lower_resource.Id, msg) == FALSE)
          {
            tp_pk_dec_lower (pkt, msg);
            JexecReturnMessage (_TASK_ID, msg);
            return false;
          }
      }
#   ifdef   TP_LOOPBACK_ENABLED
    else
      {
        if (type == DL_DATA_REQ)
            msg->type = DL_DATA_IND;
        else
            msg->type = (type & TYPE_MASK) | IND_PRIMS;
        msg->parameter [0] = ctx->loopback_copy;
        msg->parameter [1] = ctx->lower_resource.Copy;
        if (JexecSendMessage (_TASK_ID, msg) == FALSE)
          {
            tp_pk_dec_lower (pkt, msg);
            JexecReturnMessage (_TASK_ID, msg);
            return false;
          }
      }
#   endif

#   ifdef   DEBUG_LOWER
    switch (type)
      {
        case DL_DATA_REQ:
            tp_print (tp_print_debug, " > DL_DATA_REQ");
            break;
        case DL_RELEASE_REQ:
            tp_print (tp_print_debug, " > DL_RELEASE_REQ");
            break;
        case DL_ESTABLISH_REQ:
            tp_print (tp_print_debug, " > DL_ESTABLISH_REQ");
            break;
        default:
            tp_print (tp_print_debug, " > 0x%04X", type);
            break;
      }
#   endif

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_lw_excpt_output (tp_lw_ctx* ctx, char* msg)
  {
#	ifdef	DEBUG_LOWER
	tp_print (tp_print_debug, "lw_excpt_output ():");
#	endif

    if (ctx->excpt_handler == NULL)
        return false;
    if (ctx->excpt_handler (ctx->excpt_ctx, msg) == false)
        return false;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_enc_lower (tp_pk_t* pkt, MSGPTR msg)
  {
#   ifdef   DEBUG_LOWER
	tp_print (tp_print_debug, "pk_enc_lower ():");
#	endif

    if (pkt->data == NULL)
        return false;

#   if  0
    if (tp_pk_hdr_ins (pkt) == false)
        return false;
#   endif

    if (AddBufferStructPID (msg, pkt->data) == FALSE)
        return false;

    pkt->data = NULL;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_dec_lower (tp_pk_t* pkt, MSGPTR msg)
  {
#   ifdef   DEBUG_LOWER
	tp_print (tp_print_debug, "pk_dec_lower ():");
#	endif

    if (pkt->data != NULL)
        return false;

    if (IsolateBufferStructPID (msg, &pkt->data) == FALSE)
        return false;

#   if  0
    if (tp_pk_hdr_rem (pkt) == false)
        return false;
#   endif

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_enc_lower_FR (tp_pk_t* pkt, MSGPTR msg, dword address, FRFrameDataType type)
  {
#   ifdef   DEBUG_LOWER
    tp_print (tp_print_debug, "pk_enc_lower_FR ():");
#	endif

    if (pkt->data == NULL)
        return false;

    if (!build_jtec_frame_relay_header (&pkt->data, address, type))
        return false;

    if (AddBufferStructPID (msg, pkt->data) == FALSE)
        return false;

    pkt->data = NULL;

    return true;
  }

/*  ---------------------------------------------------------------- */

boolean_t tp_pk_dec_lower_FR (tp_pk_t* pkt, MSGPTR msg, dword* address, FRFrameDataType* type)
  {
#   ifdef   DEBUG_LOWER
    tp_print (tp_print_debug, "pk_dec_lower_FR ():");
#	endif

    if (pkt->data != NULL)
        return false;

    if (IsolateBufferStructPID (msg, &pkt->data) == FALSE)
        return false;

    if (!remove_jtec_frame_relay_header (&pkt->data, address, type))
        return false;

    return true;
  }

/*  ---------------------------------------------------------------- */

