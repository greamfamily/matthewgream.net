
* * *

This directory contains all of the mib files for module
management, which includes the following:


1. modumgmt.mib -- the top level mib file for all of
    module management.

2. modu_mgr.mib -- the mib file for the module manager,
    which oversees all individual modules.

3. modu_gen.mib -- the mib file for the generic module
    items. All modules are currently handled in a
    generic way.


* * *

