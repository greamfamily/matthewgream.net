#!/usr/bin/perl

###########################################################################
# $Id: extractlog.pl,v 1.3 2002/10/02 08:02:41 matt Exp $
###########################################################################-

###########################################################################-
#
#    ExtractLog
#    Matthew Gream <matthew.gream@pobox.com>
#    August 2002
#
#    Take web host logs as input and perform various operations on
#    them, writing to output as per-day logs of form www.YYYYMMDD.
#    options:
#
#    --resolve       => try to resolve IP addresses.
#    --clean         => try to clean up junk (e.g. IIS exploit lines).
#    --overwrite     => don't just append to existing files, overwrite.
#    --directory=s   => directory to place daily logs in.
#    --quiet         => don't print out list of files affected.
#
#    Usage is like:
#
#    wget http://my_site/cgi-bin/accesslog.cgi?b=2002/09/11 |
#        extractlog.pl --directory=www_logs --resolve --clean 
#
#    On STDOUT is printed the list of files created/modified
#
###########################################################################-

use strict;
use warnings;
use Socket;

###########################################################################
# get_hostname
#    return canonical hostname from ip address, and retain cache
#     to speed up subsequent conversions.
###########################################################################

my %get_hostname_cache = ();
sub get_hostname 
{
    my ($addr) = @_;
    if (not defined $get_hostname_cache{$addr}) 
    {
        $get_hostname_cache{$addr} = gethostbyaddr($addr, AF_INET) || 
            inet_ntoa($addr);
    } 
    return $get_hostname_cache{$addr};
}

###########################################################################
# get_time_accesslog
#    convert dates to YYYYMMDD.
###########################################################################

my %mon2d = ( 
    jan=>'01',feb=>'02',mar=>'03',apr=>'04',
    may=>'05',jun=>'06',jul=>'07',aug=>'08',
    sep=>'09',oct=>'10',nov=>'11',dec=>'12'
); 

sub get_time_accesslog
{
    my($i, $o) = @_;
    if ($i=~m/(\d+)\/(\w+)\/(\d+).*/i)
    {
        my $d = $1;
        my $x = $mon2d{lc($2)};
        my $y = $3; if ($y < 100) { $y += 2000; }
        $$o = "$y$x$d";
        return 1;
    }
    return 0;
}

###########################################################################
# clean_accesslog
#    perform cleaning operations on access log
###########################################################################

sub clean_accesslog
{
    my($l) = @_;
    # get rid of IIS rubbish
    if ($l=~m/root\.exe|cmd\.exe|default\.ida|Fetch API Request/)
    {
        return "";
    }
    return $l;
}

###########################################################################
# fixup_accesslog
#    perform fixup operations on access log before writing
###########################################################################

sub fixup_accesslog
{
    my($l) = @_;
    if ($l=~m/^(\d+\.\d+\.\d+\.\d+)(.*)$/)
    {
        my ($h) = get_hostname(inet_aton($1));
        my ($r) = $2;
        return "$h$r\n";
    }
    return $l;
}

###########################################################################
# extract_accesslog
#    extract accesslogs to per-day output file
###########################################################################

sub extract_accesslog
{
    my($directory, $overwrite, $fixup, $clean, $quiet) = @_;
    my($cc) = 0;
    my($filehandle);
    my($fileactive) = 0;

    while (<>)
    {
        if (/^[^\[]*\[([^\]]*)\]/)
        {
            my($c);
            if (get_time_accesslog($1, \$c))
            {
                if ($cc ne $c)
                {
                    if ($fileactive)
                    {
                        close $filehandle;
                        $fileactive = 0;
                    }
                    $cc = $c;
                    if ($overwrite) {
                        if (open ($filehandle, ">$directory/www.$cc"))
                        {
                            $fileactive = 1;
                        }
                    } else {
                        if (open ($filehandle, ">>$directory/www.$cc"))
                        {
                            $fileactive = 1;
                        }
                    }
                    print STDOUT "$directory/www.$cc\n"
                        unless($quiet);
                }
                my($l) = $_;
                if ($l && $clean)
                {
                    $l = clean_accesslog($l);
                }
                if ($l && $fileactive)
                {
                    if ($fixup)
                    {
                        print $filehandle fixup_accesslog($l);
                    }
                    else
                    {
                        print $filehandle $l;
                    }
                }
            }
        }
    }
    if ($fileactive)
    {
        close $filehandle;
    }
}

###########################################################################

my ($PROGRAM)  = "ExtractLog";
my ($VERSION)  = "1.0";
my ($AUTHOR)   = "Matthew Gream";
my ($RIGHTS)   = "Copyright 2002 Matthew Gream. All Rights Reserved.";

###########################################################################

my ($DIRECTORY)        = "";
my ($OVERWRITE)        = 0;
my ($CLEAN)            = 0;
my ($RESOLVE)          = 0;
my ($QUIET)            = 0;

###########################################################################

use Getopt::Long;

GetOptions('directory=s',    =>\$DIRECTORY,
           'resolve'         =>\$RESOLVE,
           'clean'           =>\$CLEAN,
           'quiet'           =>\$QUIET,
           'overwrite'       =>\$OVERWRITE);

extract_accesslog($DIRECTORY, $OVERWRITE, $RESOLVE, $CLEAN, $QUIET);

###########################################################################

exit 0;

