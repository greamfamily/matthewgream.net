#!/usr/bin/perl

###########################################################################
# $Id: accesslog.pl,v 1.2 2002/10/01 08:11:38 matt Exp $
###########################################################################

###########################################################################
#
#    AccessLog CLI
#    Matthew Gream <matthew.gream@pobox.com>
#    August 2002
#    
###########################################################################

use strict;
use warnings;

###########################################################################
# definitions
###########################################################################

my ($PROGRAM)        = "AccessLog CLI";
my ($VERSION)        = "1.0";
my ($AUTHOR)         = "Matthew Gream";
my ($RIGHTS)         = "Copyright 2002 Matthew Gream. All Rights Reserved.";
my ($USAGE)          = "
    accesslog.pl [options] host

    options    - 
        --begin=YYYY/MM/DD-[HH:MM:SS] - default 0000/00/00-[00:00:00]
            begin date/time to extract log from
        --end=YYYY/MM/DD-[HH:MM:SS]   - default 9999/99/99-[99:99:99]
            end date/time to extract log until
        --cgi=path_to_cgi             - default cgi-bin/accesslog/accesslog.cgi
            offset path from host to find accesslog
        --login=name:password 
            user name and password for HTTP authentication
        --quiet
            suppress any extraneous output
    host
        hostname to extract logs from
";

###########################################################################
# configuration
###########################################################################

my ($DATE_BEGIN)      = "";
my ($DATE_END)        = "";
my ($ACCESSLOG_CGI)   = "cgi-bin/accesslog/accesslog.cgi";
my ($LOGIN)           = "";
my ($ACCESSLOG_HOST)  = "";
my ($QUIET)           = 0;

use Getopt::Long;
GetOptions(
    "begin=s"       => \$DATE_BEGIN,
    "end=s"         => \$DATE_END,
    "cgi=s"         => \$ACCESSLOG_CGI,
    "quiet"         => \$QUIET,
    "login=s"       => \$LOGIN,
    );

if (!scalar(@ARGV)) { die($USAGE); }
$ACCESSLOG_HOST=$ARGV[0]; shift @ARGV;

###########################################################################
# operation
###########################################################################

print STDERR "$PROGRAM v$VERSION -- $AUTHOR\n    $RIGHTS\n"
    unless($QUIET);

my $url = "http://$ACCESSLOG_HOST/$ACCESSLOG_CGI";

my @params = ();
if ($DATE_BEGIN)   { push @params, "b=$DATE_BEGIN"; }
if ($DATE_END)     { push @params, "e=$DATE_END"; }
if (@params)       { $url .= "?"; $url .= join('&', @params); }

print STDERR "Request to $url\n"
    unless($QUIET);

use LWP::UserAgent;
my $ua = LWP::UserAgent->new;
$ua->agent("Mozilla/5.5 compatible: AccessLog/$VERSION");
my $rq = HTTP::Request->new(GET => $url);
if ($LOGIN) 
{
	my($USERNAME) = $LOGIN; $USERNAME =~ s|:.*$||;
	my($PASSWORD) = $LOGIN; $PASSWORD =~ s|[^:]*:||;

    $rq->authorization_basic($USERNAME, $PASSWORD);
}
my $rp = $ua->request($rq);
$rp->is_success() || die("http get failed");

print STDERR "Response is ", length($rp->content), " bytes\n"
    unless($QUIET);

foreach (split(/\n/, $rp->content))
{
    print $_, "\n";
}

exit 0;

###########################################################################

