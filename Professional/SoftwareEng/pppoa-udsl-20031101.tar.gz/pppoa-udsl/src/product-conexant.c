/*
*  ALCATEL SpeedTouch USB modem block extract utility
*  Copyright (C) 2001 Benoit PAPILLAULT
*  
*  This program is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public License
*  as published by the Free Software Foundation; either version 2
*  of the License, or (at your option) any later version.
*  
*  This program is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*  
*  You should have received a copy of the GNU General Public License
*  along with this program; if not, write to the Free Software
*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*
*  Author   : Benoit PAPILLAULT <benoit.papillault@free.fr>
*  Creation : 25/04/2001
*  Refactor : Matthew Gream (matthew.gream@pobox.com)
*
*  Searching for the block is done using the best match for a start and end 
*  patterns. This has been tested with windows 1.3 drivers, linux 1.3 drivers
*  & linux 1.3.2 drivers (using binary available at the Alcatel website:
*  http://www.alcateldsl.com/ ).
*
* $Id: product-conexant.c,v 1.6 2003/11/23 22:26:15 matt Exp $
*/

#ifndef _PRODUCT_CONEXANT_C_
#define _PRODUCT_CONEXANT_C_


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>

#include "pusb.h"
#include "product.h"
#include "report.h"
#include "extract.h"


/*****************************************************************************
* Prototypes
*****************************************************************************/

/*
  Derived from:

  Author     : Josep Comas <jcomas@gna.es>
  Creation   : 24/1/2003

  Description: This program inits Conexant AccessRunner (USB ADSL Modem).

  Modems:

  User: Josep Comas <jcomas@gna.es>
  Manufacturer: Mac System (http://www.macsysco.com/)
  Model: MA08CU (ADSL 100U modem)
  Distribuited by: Vitelcom
  Model: EPS 5002 USB
  Internet provider: Telefonica
  Country: Spain
  Protocols: RFC1483/2684 routed, PPPoE

  User: Pascal Boucher <bcrp17@tiscali.fr>
  Manufacturer: Olitec (http://www.olitec.com/)
  Model: Modem USB ADSL V3
  Internet provider: Tiscali
  Country: France
  Protocol: PPPoATM

  User: Thomas Mikosch
  Manufacturer: Amigo Technology Co. (http://www.amigo.com.tw)
  Model: AMX-CA86U
  Distribuited by: Trust (http://www.trust.com) 
  Model: 235A Speedlink ADSL Web Modem (item no. 13141)
  Internet provider: HetNet
  Country: The Netherlands
  Protocol: PPPoATM

  User: Pawel Konieczny <konieczp@users.sourceforge.net>
  Manufacturer: Amigo Technology Co. (http://www.amigo.com.tw)
  Model: AMX-CA80U-4
  Distributed by (OEM): E-Tech (http://www.e-tech.nu/zon)
  Model: E-Tech ADSL USB Modem V2
  Internet provider: Zon (http://www.zonnet.nl)
  ADSL provider: Versatel (http://www.versatel.nl)
  Country: The Netherlands
  Protocol: RFC1483/2684 bridged/routed

*/


/******************************************************************************
* Functions
******************************************************************************/

static void dword_encode(unsigned char* buffer, const unsigned long value)
{
	buffer[0] = (value)       & 0xff; 
	buffer[1] = (value >> 8)  & 0xff;
	buffer[2] = (value >> 16) & 0xff; 
	buffer[3] = (value >> 24) & 0xff;
}
static void dword_decode(const unsigned char* buffer, unsigned long* value)
{
	*value = ((buffer[3] & 0xff) << 24) | 
		 	 ((buffer[2] & 0xff) << 16) | 
		 	 ((buffer[1] & 0xff) << 8) | 
		 	 ((buffer[0] & 0xff));
}


/******************************************************************************
* Configuration -- Hardware
******************************************************************************/

/* ARM940T registers */

/* FCLK/BCLK PLL Register */
#define ARM_ADDR_PLL_F    	0x00350068  
#define ARM_ADDR_PLL_B    	0x0035006c
#define ARM_PLL_F_144MHZ_RM 	0x00000005
#define ARM_PLL_F_100MHZ_RM 	0x00000003
#define ARM_PLL_F_144MHZ 		0x02D874DF  /* Divide by 3, F=144Mhz, U=72Mhz */
#define ARM_PLL_F_100MHZ 		0x0196a51a  /* Divide by 4, B=100Mhz, P=50Mhz */

/* External Memory Control Register */
#define ARM_ADDR_EMCR     	0x00350010  
#define ARM_EMCR_SDRAM_ENABLE	0x00000001


/* addresses */
#define ARM_ADDR_SIGNATURE  	0x00180500
#define ARM_ADDR_BOOTWARE      	0x00180600
#define ARM_ADDR_BOOTSTACK 		0x00187f10
#define ARM_ADDR_FIRMWARE       0x00801000


/* modem commands */
#define CMD_USB_CMD_ERR                 0x00
#define CMD_USB_GET_VER                 0x01
#define CMD_USB_READ_MEM                0X02
#define CMD_USB_WRITE_MEM               0x03
#define CMD_USB_RMW_MEM                 0x04
#define CMD_USB_CHECKSUM_MEM            0x05
#define CMD_USB_GOTO_MEM                0x06
#define CMD_CHIP_ADSL_LINE_START        0x84
#define CMD_CHIP_ADSL_LINE_STOP         0x85
#define CMD_CARD_INFO_GET               0x88
#define CMD_CARD_DATA_GET               0x89
#define CMD_CARD_DATA_SET               0x8a
#define CMD_CARD_SERIAL_DATA_PATH_GET   0x8d
#define CMD_CARD_SERIAL_DATA_PATH_SET   0x8e
#define CMD_CARD_VERSION_GET 			0x8f
#define CMD_CARD_STATUS_GET             0x90
#define CMD_CARD_MACADDR_GET        	0x91
#define CMD_CARD_DATA_STATUS_GET        0x92

#define CMD_REPLY_BIT 					1

#define CMD_USB_MEM_ACC_BYTE  		0  /* access type byte */
#define CMD_USB_MEM_ACC_WORD  		1  /* access type word */
#define CMD_USB_MEM_ACC_DWORD 		2  /* access type double word */

/* link status */
#define ADSL_LINK_STATUS_NOT_CONNECTED 		1  /* link not established */
#define ADSL_LINK_STATUS_CONNECTED     		2  /* link connected */
#define ADSL_LINK_STATUS_LOST          		3  /* link lost */

/* line status */
/* a possible secuence: 0 -> 1 -> 7 -> 1 -> 2 -> 1 -> 2 -> 3 -> 5 */
#define ADSL_LINE_STATUS_DOWN                    	0
#define ADSL_LINE_STATUS_ATTEMPTING_TO_ACTIVATE  	1
#define ADSL_LINE_STATUS_TRAINING                	2
#define ADSL_LINE_STATUS_CHANNEL_ANALYSIS        	3
#define ADSL_LINE_STATUS_EXCHANGE                	4
#define ADSL_LINE_STATUS_UP                      	5
#define ADSL_LINE_STATUS_WAITING                 	6
#define ADSL_LINE_STATUS_INITIALIZING            	7

/* adsl open mode */
#define ADSL_OPEN_AUTO1 	0  /* Auto selection with G.Handshake preferred - default  */
#define ADSL_OPEN_AUTO2 	1  /* Auto selection with T1.413 preferred */
#define ADSL_OPEN_HAND  	2  /* G.Handshake only */
#define ADSL_OPEN_ANSI  	3  /* T1.413 only */
#define ADSL_OPEN_GDMT  	4  /* G.hs, G.dmt Only */
#define ADSL_OPEN_GLITE 	5  /* G.hs, G.lite Only */

/* adsl line modes */
#define ADSL_MODE_ANSI  	1
#define ADSL_MODE_GDMT  	2
#define ADSL_MODE_GLITE 	3

/* adsl data size */
#define ADSL_DATA_SIZE		56


/******************************************************************************
* Configuration -- Firmware and Bootware
******************************************************************************/

static const struct extract_block_config extract_config_firmware = 
{
	"CnxEtU.sys - Firmware",
	{ 0x1c, 0x24, 0x9f, 0xe5, 0x00, 0x10, 0xa0, 0xe3, 
	  0x00, 0x10, 0x82, 0xe5, 0x22, 0x00, 0x00, 0xeb }, 16,
	{ 0x00, 0x00, 0x00, 0x00, 0x20, 0x62, 0x65, 0x65, 
	  0x6e, 0x20, 0x73, 0x65, 0x74, 0x2e, 0x0d, 0x0a }, 16,
	0x0007ACF0,
	0x2B39ACD0
};
static const struct extract_block_config extract_config_bootstrap = 
{
	"CnxEtU.sys - Bootstrap",
	{ 0x78, 0x20, 0x9f, 0xe5, 0x01, 0x10, 0xa0, 0xe3, 
	  0x00, 0x10, 0x82, 0xe5, 0x70, 0x20, 0x9f, 0xe5 }, 16,
	{ 0x44, 0x00, 0x35, 0x00, 0x38, 0x00, 0x33, 0x00, 
	  0x40, 0x00, 0x33, 0x00, 0x00, 0x10, 0x80, 0x00 }, 16,
	0x000000B4,
	0x6AE99BDF
};


static const struct extract_block_config extract_config_firmware_b = 
{
	"cxinit.bin - Firmware",
	{ 0x1c, 0x24, 0x9f, 0xe5, 0x00, 0x10, 0xa0, 0xe3, 
	  0x00, 0x10, 0x82, 0xe5, 0x22, 0x00, 0x00, 0xeb }, 16,
	{ 0x00, 0x00, 0x00, 0x00, 0x20, 0x62, 0x65, 0x65, 
	  0x6e, 0x20, 0x73, 0x65, 0x74, 0x2e, 0x0d, 0x0a }, 16,
	0x00068E70,
	0xE4B379E6
};
static const struct extract_block_config extract_config_bootstrap_b = 
{
	"cxinit.bin - Bootstrap",
	{ 0x78, 0x20, 0x9f, 0xe5, 0x01, 0x10, 0xa0, 0xe3, 
	  0x00, 0x10, 0x82, 0xe5, 0x70, 0x20, 0x9f, 0xe5 }, 16,
	{ 0x44, 0x00, 0x35, 0x00, 0x38, 0x00, 0x33, 0x00, 
	  0x40, 0x00, 0x33, 0x00, 0x00, 0x10, 0x80, 0x00 }, 16,
	0x000000B4,
	0x00000000
};

static const struct extract_block_config extract_config_firmware_c = 
{
	"CnxEtU.sys - Firmware",
	{ 0x1c, 0x24, 0x9f, 0xe5, 0x00, 0x10, 0xa0, 0xe3, 
	  0x00, 0x10, 0x82, 0xe5, 0x22, 0x00, 0x00, 0xeb }, 16,
	{ 0x00, 0x00, 0x00, 0x00, 0x20, 0x62, 0x65, 0x65, 
	  0x6e, 0x20, 0x73, 0x65, 0x74, 0x2e, 0x0d, 0x0a }, 16,
	0x00088AD0,
	0x856B1B88
};
static const struct extract_block_config extract_config_bootstrap_c = 
{
	"CnxEtU.sys - Bootstrap",
	{ 0x78, 0x20, 0x9f, 0xe5, 0x01, 0x10, 0xa0, 0xe3, 
	  0x00, 0x10, 0x82, 0xe5, 0x70, 0x20, 0x9f, 0xe5 }, 16,
	{ 0x44, 0x00, 0x35, 0x00, 0x38, 0x00, 0x33, 0x00, 
	  0x40, 0x00, 0x33, 0x00, 0x00, 0x10, 0x80, 0x00 }, 16,
	0x000000B4,
	0x6AE99BDF
};



/******************************************************************************
* Configuration -- Device 
******************************************************************************/

#define FIRMWARE_MAX 5
#define PARAMETER_MAX 0x50

#define OPT_EXEC_PATCH	0
#define OPT_EXEC_JUMP	1

struct pusb_device_parameters 
{
	unsigned char id;
	unsigned long value;
};

struct pusb_device_configuration
{
	const char* name;

	unsigned int id_vendor, id_product;
	unsigned long pll_f, pll_b;
	unsigned int opt_exec;

	const struct extract_block_config* firmware[FIRMWARE_MAX];
	const struct extract_block_config* bootstrap[FIRMWARE_MAX];

	unsigned char param_first, param_last;
	struct pusb_device_parameters param_data[PARAMETER_MAX];

	unsigned char ep_data, ep_ctrl, ep_intr;
};

struct pusb_device_configuration device_configuration_list[] = {
	{
		"Conexant AccessRunner",
		0x0572, 0xCAFE,

  		ARM_PLL_F_144MHZ, ARM_PLL_F_100MHZ,
		OPT_EXEC_PATCH,
		{ &extract_config_firmware, 
		  /*&extract_config_firmware, 
		  &extract_config_firmware_b,*/
		  NULL },
		{ &extract_config_bootstrap, 
		  /*&extract_config_bootstrap,
		  &extract_config_bootstrap_b,*/
		  NULL },

		0x00, 0x40,
		{ 
			{0x00, 0x30}, {0x03, 0x01}, {0x04, 0x01}, {0x07, 0x09}, 
			{0x08, 0x10}, {0x0a, 0x03}, {0x0c, 0x01}, {0x0d, 0x02}, 
			{0x0f, 0xc8}, {0x10, 0x01}, {0x12, 0x39}, {0x14, 0x01}, 
			{0x17, 0x0e}, {0x18, 0x05}, {0x1b, 0x0a}, {0x1c, 0x01}, 
			{0x1d, 0x03}, {0x1e, 0x0a}, {0x2f, 0x14}, {0x30, 0x0c}, 
			{0x31, 0x02}, {0x32, 0x03},
			{0xFF, 0xFF}
		},

		0x02, 0x01, 0x00
	},
	{
		"Amigo Technology Co. (E-Tech) AMX-CA80U-2M",
		0x0572, 0xCB00,

  		ARM_PLL_F_144MHZ_RM, ARM_PLL_F_100MHZ_RM,
		OPT_EXEC_JUMP,
		{ NULL }, /*0x1c 0x24 0x9f 0xe5 0x00*/
		{ NULL },

		0x00, 0x4a,
		{ 	
			{0x03, 0x01}, {0x04, 0x01}, {0x07, 0x09}, {0x08, 0x10}, 
			{0x0c, 0x01}, {0x0d, 0x02}, {0x0f, 0xc8}, {0x10, 0x01}, 
			{0x14, 0x01}, {0x17, 0x0e}, {0x18, 0x05}, {0x19, 0x04}, 
			{0x2d, 0x80}, {0x2f, 0x0a}, {0x30, 0x0c}, {0x31, 0x02}, 
			{0x32, 0x03}, {0x36, 0x0180}, {0x4a, 0x1100},
			{0xFF, 0xFF}
		},

		0x02, 0x01, 0x00
	},
	{
		"Amigo Technology Co. (Trust) AMX-CA86U",
		0x0EB0, 0x3457,

  		ARM_PLL_F_144MHZ, ARM_PLL_F_100MHZ,
		OPT_EXEC_PATCH,
		{ NULL }, /*0x1c 0x24 0x9f 0xe5 0x00*/
		{ NULL },

		0x00, 0x48,
		{ 
			{0x03, 0x01}, {0x04, 0x01}, {0x07, 0x09}, {0x08, 0x10}, 
			{0x0d, 0x02}, {0x0f, 0xc8}, {0x10, 0x01}, {0x12, 0x22}, 
			{0x14, 0x01}, {0x17, 0x0e}, {0x18, 0x05}, {0x2d, 0x80}, 
			{0x2f, 0x0a}, {0x30, 0x0c}, {0x31, 0x02}, {0x32, 0x03}, 
			{0x36, 0x0180},
			{0xFF, 0xFF}
		},

		0x02, 0x01, 0x00
	},
	{
		"Olitec V2",
		0x08E3, 0x0100,

  		ARM_PLL_F_144MHZ, ARM_PLL_F_100MHZ,
		OPT_EXEC_PATCH,
		{ NULL }, /*0x1c 0x24 0x9f 0xe5 0x00*/
		{ NULL },

		0x00, 0x41,
		{
    			{0x00, 0x30}, {0x03, 0x01}, {0x04, 0x01}, {0x07, 0x09},
    			{0x08, 0x10}, {0x0c, 0x01}, {0x0d, 0x02}, {0x0f, 0xc8},
    			{0x10, 0x01}, {0x12, 0x22}, {0x14, 0x01}, {0x17, 0x0e},
    			{0x18, 0x05}, {0x2f, 0x14}, {0x30, 0x0c}, {0x31, 0x02},
    			{0x32, 0x03},
			{0xFF, 0xFF}
		},

		0x02, 0x01, 0x00
	},
	{
		"Olitec V3",
		0x08E3, 0x0102,

  		ARM_PLL_F_144MHZ_RM, ARM_PLL_F_100MHZ_RM,
		OPT_EXEC_JUMP,
		{ NULL }, /*0x1c 0x24 0x9f 0xe5 0x00*/
		{ NULL },

		0x00, 0x48,
		{
    			{0x03, 0x01}, {0x04, 0x01}, {0x07, 0x09}, {0x08, 0x10},
    			{0x0a, 0x04}, {0x0c, 0x01}, {0x0f, 0xc8}, {0x10, 0x01},
    			{0x14, 0x01}, {0x17, 0x0e}, {0x18, 0x05}, {0x2d, 0x80},
    			{0x2f, 0x0a}, {0x30, 0x0c}, {0x31, 0x02}, {0x32, 0x03},
    			{0x36, 0x0180},
			{0xFF, 0xFF}
		},

		0x02, 0x01, 0x00
	}
};

static const struct pusb_device_configuration* device_configuration_match(unsigned int vid, unsigned int pid)
{
	int i;
	for (i = 0; i < sizeof(device_configuration_list) / 
			sizeof (struct pusb_device_configuration); ++i) {
		if (device_configuration_list[i].id_vendor == vid && 
				device_configuration_list[i].id_product == pid)
			return &device_configuration_list[i];
	}
	return(0);
}

static int extract_firmware(const struct pusb_device_configuration* config, 
		const char* filename, long* len, unsigned char** buf)
{
	int i;
	for (i = 0; config->firmware[i] != NULL; ++i) {
		if ((*buf = extract_block(config->firmware[i], 
				filename, len)) != NULL)
			return(0);
	}
	return(-1);
}

static int extract_bootstrap(const struct pusb_device_configuration* config, 
		const char* filename, long* len, unsigned char** buf)
{
	int i;
	for (i = 0; config->bootstrap[i] != NULL; ++i) {
		if ((*buf = extract_block(config->bootstrap[i], 
				filename, len)) != NULL)
			return(0);
	}
	return(-1);
}

static int value_obtain(const struct pusb_device_parameters* param, 
		const unsigned char id, unsigned long* value)
{
	int i;
	for (i = 0; param[i].id != 0xff; ++i) {
		if (param[i].id == id) {
			*value = param[i].value; 
			return(0);
		}
	}
	return(-1);
}

static int value_extract(const unsigned char* buf, 
		const unsigned char id, unsigned long *value)
{
	int i;
	for (i = 0; i < buf[4]; ++i) {
		unsigned long ident;
		dword_decode(&buf[8+(i*8)], &ident);
		if ((ident & 0xff) == id) {
			dword_decode(&buf[12+(i*8)], value);
			return(0);
		}
	}
	return(-1);
}


/******************************************************************************
* Information
******************************************************************************/

struct pusb_device_information {
	char firmware_status;
	char firmware_version[5];
  	char firmware_address[6];
  	unsigned int adsl_rate_down;
  	unsigned int adsl_rate_up;
  	int adsl_link_status;
  	int adsl_line_status;
  	int adsl_mode;
	struct pusb_device_parameters vars[0x80];
};

const char* string_configuration(const struct pusb_device_parameters* param)
{
	static char buffer[(0x80 * (8 + 1 + 2 + 1))];
	int i;
	buffer[0] = '\0';
	for (i = 0; param[i].id != 0xFF; ++i) {
		int s = strlen(buffer);
		snprintf(&buffer[s], sizeof(buffer) - s, "%s%02x=%08lx", 
			(i == 0) ? "" : ",", param[i].id, param[i].value);
	}
	return buffer;
}
const char* string_firmware_status(const struct pusb_device_information* info)
{
	static char buffer[24]; 
	snprintf(buffer, sizeof(buffer), "%02x", info->firmware_status);
	return buffer;
}
const char* string_firmware_version(const struct pusb_device_information* info)
{
	static char buffer[24]; 
	int i;
	buffer[0] = '\0';
	for (i = 0; i < sizeof(info->firmware_version); ++i) {
		int s = strlen(buffer);
		snprintf(&buffer[s], sizeof(buffer) - s, "%c", 
			info->firmware_version[i]);
	}
	return buffer;
}
const char* string_firmware_address(const struct pusb_device_information* info)
{
	static char buffer[24];
	int i;
	buffer[0] = '\0';
	for (i = 0; i < sizeof(info->firmware_address); ++i) {
		int s = strlen(buffer);
		snprintf(&buffer[s], sizeof(buffer) - s, "%s%02x", 
			(i == 0) ? "" : ":", (info->firmware_address[i] & 0xff));
	}
	return buffer;
}
const char* string_adsl_link_status(const struct pusb_device_information* info) 
{
	static char buffer [24];
	switch (info->adsl_link_status) {
		case ADSL_LINK_STATUS_NOT_CONNECTED: 			return "DISCONNECTED";
		case ADSL_LINK_STATUS_CONNECTED: 				return "CONNECTED";
		case ADSL_LINK_STATUS_LOST: 					return "LOST";
		default: snprintf (buffer, sizeof (buffer), "%02x", info->adsl_link_status);
				 return buffer;
	}
}
const char* string_adsl_line_status(const struct pusb_device_information* info)
{
	static char buffer [24];
	switch (info->adsl_line_status) {
		case ADSL_LINE_STATUS_DOWN: 					return "DOWN";
		case ADSL_LINE_STATUS_ATTEMPTING_TO_ACTIVATE: 	return "ACTIVATING";
		case ADSL_LINE_STATUS_TRAINING: 				return "TRAINING";	
		case ADSL_LINE_STATUS_CHANNEL_ANALYSIS: 		return "ANALYSING";
		case ADSL_LINE_STATUS_EXCHANGE: 				return "EXCHANGING";
		case ADSL_LINE_STATUS_UP: 						return "UP";
		case ADSL_LINE_STATUS_WAITING: 					return "WAITING";
		case ADSL_LINE_STATUS_INITIALIZING: 			return "INITIALISING";
		default: snprintf (buffer, sizeof (buffer), "%02x", info->adsl_line_status);
				 return buffer;
	}
}
const char* string_adsl_mode(const struct pusb_device_information* info)
{
	static char buffer [24];
	switch (info->adsl_mode) {
		case ADSL_MODE_ANSI:							return "ANSI";
		case ADSL_MODE_GDMT:							return "G.DMT";
		case ADSL_MODE_GLITE:							return "G.Lite";
		default: snprintf (buffer, sizeof (buffer), "%02x", info->adsl_mode);
				 return buffer;
	}
}


/******************************************************************************
* USB interface read/write
******************************************************************************/

#define USB_DATA_TIMEOUT_DEFAULT 	5000     /* Timeout (ms) for in/out data packets */ 
#define USB_DATA_TIMEOUT_ADJUST  	1000     /* We get timeout then add additional time */
#define USB_DATA_RETRIES 			4	 	/* Max retries when send/recv packets */

/* usb input and ouput address against modem */
#define USB_EP_INFO 0x01    /* OUT endpoint address, ask info, send firmware */
#define USB_EP_DATA 0x02    /* OUT endpoint address, send ATM cells */


pusb_endpoint_t endpoint_set[0xff];

int pusb_bulk_read(pusb_device_t h, int e, unsigned char* b, int l, int t) {
	return pusb_endpoint_read(endpoint_set[e], b, l, t);
}
int pusb_bulk_write(pusb_device_t h, int e, const unsigned char* b, int l, int t) {
	return pusb_endpoint_write(endpoint_set[e], b, l, t);
}




static int usb_recv_data(pusb_device_t device, int ep, unsigned char *buf, int len)
{
	int count = 0;
	int retry;
	int tmout = USB_DATA_TIMEOUT_DEFAULT;
	int retries = USB_DATA_RETRIES;

	memset(buf, 0, len);

	for (retry = 0; retry < retries; ++retry) {

		count = pusb_bulk_read(device, ep, buf, len, tmout);
		if (count >= 0)
			break;

		report(1, REPORT_ERROR|REPORT_PERROR, "pusb_bulk_read (%d of %d)", 
				retry, retries);

		if (count == -EPIPE) {
			/* pusb_clear_halt(device, ep); */
		} else if (count == -ETIMEDOUT) {
			tmout += USB_DATA_TIMEOUT_ADJUST;
		}

	}

	if (count < 0)
		return(-1);

	return(0);
}

static int usb_send_data(pusb_device_t device, int ep, const unsigned char *buf, int len)
{
	int count = 0;
	int retry;
	int tmout = USB_DATA_TIMEOUT_DEFAULT;
	int retries = USB_DATA_RETRIES;

	for (retry = 0; retry < retries; ++retry) {

		count = pusb_bulk_write(device, ep, buf, len, tmout);
		if (count >= 0)
			break;

		report(1, REPORT_ERROR|REPORT_PERROR, "pusb_bulk_write (%d of %d)", 
				retry, retries);

		if (count == -EPIPE) {
			/* pusb_clear_halt(device, ep); */
		} else if (count == -ETIMEDOUT) {
			tmout += USB_DATA_TIMEOUT_ADJUST;
		}

	}

	if (count < 0)
		return(-1);

	return(0);
}


/******************************************************************************
* USB device command read/write/check
******************************************************************************/

/* messages */
#define MAX_MESSAGE_SIZE 64       /* Maximum bytes of a message */
#define MAX_MESSAGE_DATA_SIZE 56  /* Maximum data bytes of a message */
#define MAX_TRANSFER_SIZE 4096    /* Maximum bytes that we can transfer through USB bus */
#define CMD_TIMEOUT_DEFAULT(n) (2 + (2 * n))
#define CMD_RETRIES_DEFAULT (4)

static int make_cmd(const int cmd, const int ldata, const int atype, const unsigned long address, unsigned char *buf)
{
	buf[0] = cmd & 0xff;    /* usb command */
	buf[1] = ldata & 0xff;  /* data length */ 
	buf[2] = atype & 0xff;  /* access type */
	buf[3] = 0x00;          /* ack request (0 = FALSE) */

	dword_encode(&buf[4], address);

	return(0);
}

static int recv_cmd_reply(pusb_device_t device, const int cmd, const int number, const int timeout, 
	void (*const handle_reply)(void*, const unsigned char*, const int), void* magic_reply,
	void (*const handle_error)(void*, const int), void* magic_error)
{
	time_t first, last;
	int retry = 0;
	int count = 0;
	unsigned char buffer[MAX_MESSAGE_SIZE];
	int n;

	if (timeout < 0)
		return(-1);
	else if (timeout == 0)
		return(0);

  	time(&first); last = first;

	while (count < number && difftime(last, first) < timeout) {

		retry++;

		memset(buffer, 0, sizeof(buffer));
		n = pusb_bulk_read(device, USB_EP_INFO, buffer, sizeof(buffer), 
				USB_DATA_TIMEOUT_DEFAULT);
		if (n == sizeof(buffer)) {

			/* received */
        		if((buffer[1] & 0xff) == CMD_REPLY_BIT) {
	
				if((buffer[0] & 0xff) == cmd) {

					count++;

					if (handle_reply != NULL) {

						(*handle_reply)(magic_reply, buffer, sizeof(buffer));

					} else {

						/* nothing */

					}
				}

			}

		} else if (n < 0) {

			if (handle_error != NULL) {

				(*handle_error)(magic_error, retry);

			} else {
			
				report(0, REPORT_ERROR|REPORT_PERROR, "pusb_bulk_read\n");

			}

          		if (n == -EPIPE) {
            			/* pusb_clear_halt(device, USB_EP_INFO); */
			}
		}

		time(&last);
	}

	if (count != number)
		return(-1);

	return(0);
}


static int send_cmd_usb_mem_write_dword(pusb_device_t device, const unsigned long address, const unsigned long value)
{
  	unsigned char buffer[MAX_MESSAGE_SIZE];

  	memset(buffer, 0, sizeof(buffer));
  	make_cmd(CMD_USB_WRITE_MEM, 4, CMD_USB_MEM_ACC_DWORD, address, buffer);
	dword_encode(&buffer[8], value);

  	if (usb_send_data(device, USB_EP_INFO, buffer, sizeof(buffer)))
		return(-1);

	return(0);
}

static int send_cmd_usb_mem_write_data(pusb_device_t device, const unsigned long address, const unsigned char *buf, const long len)
{
	int packet_number = len / MAX_MESSAGE_DATA_SIZE;
	int packet_count;
	int packet_length;
	unsigned char packet_data[MAX_MESSAGE_SIZE];
	unsigned char buffer_data[MAX_TRANSFER_SIZE];
	int buffer_length = 0;
	
	if ((len % MAX_MESSAGE_DATA_SIZE) > 0)
		packet_number++;

	for (packet_count = 0; packet_count < packet_number; ++packet_count)
	{
		if (packet_count == (packet_number - 1) && (len % MAX_MESSAGE_DATA_SIZE) > 0)
			packet_length = len % MAX_MESSAGE_DATA_SIZE;
		else
			packet_length = MAX_MESSAGE_DATA_SIZE;

		memset(packet_data, 0, sizeof(packet_data));
		memcpy(packet_data + 8, buf + (packet_count * MAX_MESSAGE_DATA_SIZE), 
			packet_length);

		if ((packet_length % 4) > 0)
			packet_length = ((packet_length / 4) + 1) * 4;

     		make_cmd(CMD_USB_WRITE_MEM, packet_length, CMD_USB_MEM_ACC_DWORD, 
			address+(packet_count*MAX_MESSAGE_DATA_SIZE), packet_data);
		memcpy(buffer_data + buffer_length, packet_data, sizeof(packet_data));

		buffer_length += sizeof(packet_data);

		if (packet_count == (packet_number - 1) || (buffer_length == MAX_TRANSFER_SIZE)) {
			if (usb_send_data(device, USB_EP_INFO, buffer_data, buffer_length))
				return(-1);
			buffer_length = 0;
		}
	}

	return(0);
}

static int send_cmd_usb_mem_goto(pusb_device_t device, const unsigned long address)
{
	unsigned char buffer[MAX_MESSAGE_SIZE];

	memset(buffer, 0, sizeof(buffer));
	make_cmd(CMD_USB_GOTO_MEM, 0, CMD_USB_MEM_ACC_BYTE, address, buffer);

	if (usb_send_data(device, USB_EP_INFO, buffer, sizeof(buffer)))
		return(-1);

	return(0);
}

static int send_cmd_card(pusb_device_t device, const int cmd, const int answers, 
	void (*const handle_reply)(void*, const unsigned char*, const int), void* magic_reply,
	void (*const handle_error)(void*, const int), void* magic_error)
{
	int retry;
	int retries = CMD_RETRIES_DEFAULT;

	for (retry = 0; retry < retries; ++retry) {

		unsigned char buffer[MAX_MESSAGE_SIZE];

  		memset(buffer, 0, sizeof(buffer));
		make_cmd(cmd, 0, 0, 0, buffer);
		
    		if (usb_send_data(device, USB_EP_INFO, buffer, sizeof(buffer)) < 0)
			continue;
      
		if (recv_cmd_reply(device, cmd, answers, 
				CMD_TIMEOUT_DEFAULT(answers), 
				handle_reply, magic_reply, handle_error, magic_error) == 0)
        		return(0);
  	}

	return(-1);
}

int send_cmd_card_data_set_XXX(pusb_device_t device, const struct pusb_device_parameters* data, const char first, const char last, const int mode,
	void (*const handle_reply)(void*, const unsigned char*, const int), void* magic_reply,
	void (*const handle_error)(void*, const int), void* magic_error)
{
	int retry;
	int retries = CMD_RETRIES_DEFAULT;

	for (retry = 0; retry < retries; ++retry) {

		const int len = (last - first) + 1;	
		int packet_number = len / 7;
		int packet_count;
		int packet_length;
		unsigned char packet_data[MAX_MESSAGE_SIZE];
		unsigned char id = 0;
		unsigned long value;
		int answers = 0;
		int i;
	
		if ((len % 7) > 0)
			packet_number++;

		for (packet_count = 0; packet_count < packet_number; ++packet_count) {

			if (packet_count == (packet_number - 1) && (len % 7) > 0)
				packet_length = len % 7;
			else
				packet_length = 7;

			memset(packet_data, 0, sizeof(packet_data));
			make_cmd(CMD_CARD_DATA_SET, 0, 0, packet_length, packet_data);

			for (i = 0; i < packet_length; ++i) {

				value = 0;
      				if ((id == 0x0a) && (mode != -1))
					value = mode;
				else 
					value_obtain(data, id, &value);

				dword_encode(&packet_data[(8*i)+8 ], id);
				dword_encode(&packet_data[(8*i)+12], value);

				id++;
			}

			if (usb_send_data(device, USB_EP_INFO, packet_data, 
					sizeof(packet_data)) < 0)
				return(-1); /*XXX*/

			answers++;
		}

		if (recv_cmd_reply(device, CMD_CARD_DATA_SET, answers, 
				CMD_TIMEOUT_DEFAULT(answers), 
				handle_reply, magic_reply, handle_error, magic_error) == 0)
			return(0);
	}

	return(-1);
}


/*****************************************************************************
* Commands
*****************************************************************************/

static void send_cmd_card_info_get_reply(void* magic, const unsigned char* buffer, const int length)
{
	struct pusb_device_information* info = (struct pusb_device_information*)magic;
	unsigned char id;
	unsigned long value;
	unsigned int offs = 0;

	for (id = 0x00; id < 0x80; ++id) { 

		if (value_extract(buffer, id, &value) < 0)
			continue;

		switch(id) { 

			case 0x00: info->adsl_rate_down = value; break; 
			case 0x01: info->adsl_rate_up = value; break; 
			case 0x02: info->adsl_link_status = value; break; 
			case 0x03: info->adsl_line_status = value; break; 
			case 0x04: memcpy(&info->firmware_address[4], &value, 2); break; 
			case 0x05: memcpy(&info->firmware_address[0], &value, 4); break; 
			case 0x15: info->adsl_mode = value; break; 
			default: report(2, REPORT_DEBUG, "CMD_CARD_INFO_GET[%02x] = %08lx\n", 
						id, value);
					info->vars[offs].id = id; info->vars[offs].value = value; offs++;
					break;
		}
	}

	info->vars[offs].id = 0xFF; info->vars[offs].value = 0xFF;
}
static int send_cmd_card_info_get(pusb_device_t device, struct pusb_device_information* info)
{
	report(2, REPORT_DEBUG, "send CMD_CARD_INFO_GET\n");
   	if (send_cmd_card(device, CMD_CARD_INFO_GET, 4, 
			&send_cmd_card_info_get_reply, (void*)info, 0, 0))
		return(-1);
	return(0);
}

static void send_cmd_card_version_get_reply(void* magic, const unsigned char* buffer, const int length)
{
	struct pusb_device_information* info = (struct pusb_device_information*)magic; 
	memcpy(info->firmware_version, buffer + 4, sizeof(info->firmware_version));
}
static int send_cmd_card_version_get(pusb_device_t device, struct pusb_device_information* info)
{
	report(2, REPORT_DEBUG, "send CMD_CARD_VERSION_GET\n");
  	if (send_cmd_card(device, CMD_CARD_VERSION_GET, 1,
			&send_cmd_card_version_get_reply, (void*)info, 0, 0))
		return(-1);
	return(0);
}

static void send_cmd_card_address_get_reply(void* magic, const unsigned char* buffer, const int length)
{
	struct pusb_device_information* info = (struct pusb_device_information*)magic; 
	memcpy(info->firmware_address, buffer + 4, sizeof(info->firmware_address));
}
static int send_cmd_card_address_get(pusb_device_t device, struct pusb_device_information* info)
{
	report(2, REPORT_DEBUG, "send CMD_CARD_MACADDR_GET\n");
  	if (send_cmd_card(device, CMD_CARD_MACADDR_GET, 1,
			&send_cmd_card_address_get_reply, (void*)info, 0, 0))
		return(-1);
	return(0);
}

static int send_cmd_card_data_set(pusb_device_t device, const struct pusb_device_configuration* config, const int mode)
{
	report(2, REPORT_DEBUG, "send CMD_CARD_DATA_SET [%s]\n",
			string_configuration(config->param_data));
	if (send_cmd_card_data_set_XXX (device, 
			config->param_data, config->param_first, 
			config->param_last, mode, 0, 0, 0, 0))
		return(-1);
	return(0);
}

static void send_cmd_card_status_get_error(void* magic, const int count)
{
	/* nothing */
}
static void send_cmd_card_status_get_reply(void* magic, const unsigned char* buffer, const int length)
{
	struct pusb_device_information* info = (struct pusb_device_information*)magic; 
	info->firmware_status = 1;
	/* report(0, REPORT_DEBUG|REPORT_DUMP, "card status reply\n", buffer, length); */
}
static int send_cmd_card_status_get(pusb_device_t device, struct pusb_device_information* info,
	int quiet)
{
	report(2, REPORT_DEBUG, "send CMD_CARD_STATUS_GET\n");
  	if (quiet == 0 && send_cmd_card(device, CMD_CARD_STATUS_GET, 1,
			&send_cmd_card_status_get_reply, (void*)info, 0, (void *)0))
		return(-1);
  	else if (quiet == 1 && send_cmd_card(device, CMD_CARD_STATUS_GET, 1,
			&send_cmd_card_status_get_reply, (void*)info, 
			&send_cmd_card_status_get_error, (void *)0))
		return(-1);
	return(0);
}

static int send_cmd_adsl_line_start(pusb_device_t device)
{
	report(2, REPORT_DEBUG, "send CMD_CHIP_ADSL_LINE_START\n");
  	if (send_cmd_card(device, CMD_CHIP_ADSL_LINE_START, 1, 0, (void*)0, 0, (void*)0))
		return(-1);
	return(0);
}
static int send_cmd_adsl_line_stop(pusb_device_t device)
{
	report(2, REPORT_DEBUG, "send CMD_CHIP_ADSL_LINE_STOP\n");
  	if (send_cmd_card(device, CMD_CHIP_ADSL_LINE_STOP, 1, 0, (void*)0, 0, (void*)0))
		return(-1);
	return(0);
}

static void send_cmd_card_data_status_get_reply(void* magic, const unsigned char* buffer, const int length)
{
	report(0, REPORT_DEBUG|REPORT_DUMP, "card data status reply\n", buffer, length);
}
static int send_cmd_card_data_status_get(pusb_device_t device)
{
	report(2, REPORT_DEBUG, "send CMD_CARD_DATA_STATUS_GET\n");
  	if (send_cmd_card(device, CMD_CARD_DATA_STATUS_GET, 1,
			&send_cmd_card_data_status_get_reply, (void *)0, 0, (void *)0))
		return(-1);
	return(0);
}


/*****************************************************************************
* EXTERNAL INTERFACE
*****************************************************************************/

static int cfg_mode = ADSL_OPEN_AUTO1;
static char* cfg_file = NULL;

int product_conexant_usage()
{

	fprintf(stderr, "Conexant options:\n");
	fprintf(stderr, "  -f block     : upload this block file first\n");
	fprintf(stderr, "  -m [0-5]     : open in this ADSL mode\n");

	return(0);
}

int product_conexant_options_parse(int argc, char** argv, int* argi)
{

	if (strcmp(argv[*argi],"-f") == 0 && (*argi)+1 < argc)
		cfg_file = argv[++(*argi)];
	else if (strcmp(argv[*argi],"-m") == 0 && (*argi)+1 < argc)
		cfg_mode = atoi(argv[++(*argi)]);
	else
		return(-1);

	return(0);
}

int product_conexant_options_check()
{

	if (cfg_file == NULL)
		return(-1);

	return(0);
}


/*****************************************************************************
* Identification
*	check - check for support for this type of device
*****************************************************************************/

static struct pusb_device_configuration* device_configuration = &device_configuration_list[0];
pusb_device_t product_conexant_open_probe(void** magic)
{
	int i;
	for (i = 0; i < sizeof(device_configuration_list) /
			sizeof(struct pusb_device_configuration); ++i)
	{
		struct pusb_device_configuration* config = &device_configuration_list[i];
		pusb_device_t device = pusb_search_open(config->id_vendor, 
				config->id_product);
		if (device != NULL) {
			(*magic) = config;
			return device;	
		}
	}
	return(0);
}


/*****************************************************************************
* Acquisition
*****************************************************************************/

int product_conexant_acquire(pusb_device_t device, product_acquire_t q)
{
	if (q & PRODUCT_ACQ_INFO)
		endpoint_set[USB_EP_INFO] = pusb_endpoint_open(device, USB_EP_INFO, O_RDWR);
	if (q & PRODUCT_ACQ_DATA)
		endpoint_set[USB_EP_DATA] = pusb_endpoint_open(device, USB_EP_DATA, O_RDWR);
	return(0);
}

int product_conexant_release(pusb_device_t device, product_acquire_t q) 
{
	if (q & PRODUCT_ACQ_INFO)
		pusb_endpoint_close(endpoint_set[USB_EP_INFO]);
	if (q & PRODUCT_ACQ_DATA)
		pusb_endpoint_close(endpoint_set[USB_EP_DATA]);
	return(0);
}

/*****************************************************************************
* Configuration
*	check - check for the presence of device firmware
*	load - load and execute the device firmware
*	wait - wait for device firmware to begin executing
*	config - configure the device firmware parameters
*	report - report on the device firmware
*****************************************************************************/

int product_conexant_configure_check(pusb_device_t device)
{
	struct pusb_device_information info;
	
	/* Check */
	report(2, REPORT_DEBUG, "Configure: Check\n");

	if (send_cmd_card_status_get(device, &info, 1) < 0)
		return(0);

	return(1);

}

int product_conexant_configure_load(pusb_device_t device)
{
	/* Configuration state: device firmware load */

	unsigned char* buffer;
	long length;

	/* Initialise */
	report(2, REPORT_DEBUG, "Configure: Initialise\n");

  	if (send_cmd_usb_mem_write_dword(device, ARM_ADDR_PLL_F, 
			device_configuration->pll_f))
		return(-1);

  	if (send_cmd_usb_mem_write_dword(device, ARM_ADDR_PLL_B, 
			device_configuration->pll_b))
		return(-1);

  	if (send_cmd_usb_mem_write_dword(device, ARM_ADDR_EMCR, 
			ARM_EMCR_SDRAM_ENABLE))
		return(-1);


	/* Transfer Firmware */
	report(2, REPORT_DEBUG, "Configure: Firmware transfer\n");

  	if (extract_firmware(device_configuration, cfg_file, &length, &buffer)) 
	{
		report(0, REPORT_ERROR, "Firmware: could not extract from %s\n", 
				cfg_file);
		return(-1);
	}
  	if (send_cmd_usb_mem_write_data(device, ARM_ADDR_FIRMWARE, buffer, length)) 
	{
		report(0, REPORT_ERROR, "Firmware: could not download\n");
    		free(buffer);
		return(-1);
	}
	free(buffer);


	/* Transfer Bootstrap */
	if (device_configuration->opt_exec == OPT_EXEC_PATCH) {
	
		report(2, REPORT_DEBUG, "Configure: Bootstrap transfer\n");
  	
		if (extract_bootstrap(device_configuration, cfg_file, &length, &buffer)) {
			report(0, REPORT_ERROR, "Bootstrap: could not extract from %s\n", 
				cfg_file);
    			return(-1);
  		}
  		if (send_cmd_usb_mem_write_data(device, ARM_ADDR_BOOTWARE, buffer, length)) {
			report(0, REPORT_ERROR, "Bootstrap: could not download\n");
    			free(buffer);
    			return(-1);
  		}
  		free(buffer);
	}


	/* Write Signature */
	report(2, REPORT_DEBUG, "Configure: Signature\n");

  	if (send_cmd_usb_mem_write_dword(device, ARM_ADDR_SIGNATURE, 
			(device_configuration->id_product<<16) | 
			device_configuration->id_vendor))
		return(-1);


	/* Execute Firwmare */
	if (device_configuration->opt_exec == OPT_EXEC_JUMP) {

		report(2, REPORT_DEBUG, "Configure: Execute (Firmware)\n");

  		if (send_cmd_usb_mem_goto(device, ARM_ADDR_FIRMWARE))
			return(-1);

	} else if (device_configuration->opt_exec == OPT_EXEC_PATCH) {

		report(2, REPORT_DEBUG, "Configure: Execute (Bootstrap)\n");

  		if (send_cmd_usb_mem_write_dword(device, 
				ARM_ADDR_BOOTSTACK, ARM_ADDR_BOOTWARE))
			return(-1);

	}


 	return(0);
}

int product_conexant_configure_wait(pusb_device_t device)
{
	/* Configuration state: device firmware wait */

	report(2, REPORT_DEBUG, "Configure: Firmware activating\n");
  	sleep(2);

	return(0);
}

int product_conexant_configure_config(pusb_device_t device)
{
	/* Configuration state: device configure */

	if (send_cmd_card_data_set(device, device_configuration, 
			cfg_mode) < 0)
		return(-1);

	return(0);
}

int product_conexant_configure_report(pusb_device_t device)
{
	/* Configuration state: device information */

	struct pusb_device_information info;

	if (send_cmd_card_status_get(device, &info, 0) < 0)
		return(-1);
	if (send_cmd_card_version_get(device, &info) < 0)
		return(-1);
	if (send_cmd_card_address_get(device, &info) < 0)
		return(-1);

	report(0, REPORT_INFO, "Firmware status: %s\n", 
			string_firmware_status(&info));
	report(0, REPORT_INFO, "Firmware version: %s\n", 
			string_firmware_version(&info));
	report(0, REPORT_INFO, "Firmware address: %s\n",
			string_firmware_address(&info));

	return(0);
}


/*****************************************************************************
* Connection
*	start - start the ADSL line (using a LINE_START)
*	stop - stop the ADSL line (using a LINE_STOP)
*	check_wait - wait in between connect check
*	check_line - check the line (using an INFO_GET)
*	check_data - check the data (look for ATM cells)
*	check - alias for check_line
*	report - provide report about the line (using an INFO_GET)
*****************************************************************************/

int product_conexant_connect_setup(pusb_device_t device)
{
	return(0);
}

int product_conexant_connect_verify(pusb_device_t device)
{
	return(0);
}

int product_conexant_connect_start(pusb_device_t device)
{
	/* Connection state: connect request */

	if (send_cmd_adsl_line_start(device) < 0)
		return(-1);

  	return(0);
}

int product_conexant_connect_stop(pusb_device_t device)
{
	/* Connection state: disconnect request */

	if (send_cmd_adsl_line_stop(device) < 0)
		return(-1);

  	return(0);
}

int product_conexant_connect_check_wait(pusb_device_t device)
{
	sleep(1);
	return(0);
}

int product_conexant_connect_check_line(pusb_device_t device)
{
	/* Connection state: line connected ? */

	struct pusb_device_information info;

	if (send_cmd_card_info_get(device, &info) < 0)
		return(-1);

	report(1, REPORT_DEBUG, "recv link %s, line %s\n",
			string_adsl_link_status(&info), 
			string_adsl_line_status(&info));
  
	if (info.adsl_line_status == ADSL_LINE_STATUS_UP)
	{
		return(1);
	}

	return(0);
}

int product_conexant_connect_check_data(pusb_device_t device, int timeout)
{
	/* Connection state: data connected ? */

	unsigned char buffer[ADSL_DATA_SIZE * 2];
	int length;

	if (timeout < 0) 
	{
		timeout = USB_DATA_TIMEOUT_DEFAULT;
	}

	length = pusb_bulk_read(device, USB_EP_DATA, 
		buffer, sizeof(buffer), timeout);

	if (length >= 0);
	{
		report(1, REPORT_INFO, "Connect: received data (%d bytes)\n", 
				length);

		return(1);
	}

	return(0);
}

int product_conexant_connect_check(pusb_device_t device)
{
	/* Connection state: any connected ? */

	return product_conexant_connect_check_line(device);
}

int product_conexant_connect_report(pusb_device_t device)
{
	/* Connection state: information */

	struct pusb_device_information info;

	if (send_cmd_card_info_get(device, &info) < 0)
		return(-1);

	report(0, REPORT_INFO, 
			"Line status: link %s, line %s\n",
				string_adsl_link_status(&info), 
				string_adsl_line_status(&info));

	if (info.adsl_line_status == ADSL_LINE_STATUS_UP) 
	{
		report(0, REPORT_INFO,
				"Line params: mode %s, down %u Kb/s, up %u Kb/s\n",
					string_adsl_mode(&info),
					info.adsl_rate_down, info.adsl_rate_up);
	}

	report(0, REPORT_INFO,
			"Line detail: %s\n",
				string_configuration(info.vars));

	return(0);
}


/*****************************************************************************
* Communication
*	write - write data to the device
*	read - read data from the device
*   report - report on data activity
*****************************************************************************/

int product_conexant_data_write(pusb_device_t device, const unsigned char* buffer_ptr, int buffer_sz, int timeout)
{
	/* Connection state: data write */

	int s = 0;
	for (s = 0; s < buffer_sz; s += ADSL_DATA_SIZE)
		if (pusb_endpoint_write(endpoint_set[USB_EP_DATA], &buffer_ptr[s], ADSL_DATA_SIZE, timeout) < 0)
			return -1;
	return buffer_sz;
}

int product_conexant_data_read(pusb_device_t device, unsigned char* buffer_ptr, int buffer_sz, int timeout)
{
	/* Connection state: data read */

	return pusb_endpoint_read(endpoint_set[USB_EP_DATA], buffer_ptr, buffer_sz, timeout);
}

int product_conexant_data_report(pusb_device_t device)
{
	/* Connection state: data report */

	return(0);
}

/*****************************************************************************
* EOF
*****************************************************************************/

#endif /* #ifndef _PRODUCT_CONEXANT_C_ */
