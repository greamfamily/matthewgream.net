/*
*  ALCATEL SpeedTouch USB modem utility : PPPoA implementation (3nd edition)
*  Copyright (C) 2001 Edouard Gomez
* 
*  This program is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public License
*  as published by the Free Software Foundation; either version 2
*  of the License, or (at your option) any later version.
*  
*  This program is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*  
*  You should have received a copy of the GNU General Public License
*  along with this program; if not, write to the Free Software
*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*
*  Author : Edouard Gomez (ed.gomez@free.fr)
*  Creation : 08/08/2001
*  Refactor : Matthew Gream (matthew.gream@pobox.com)
*
* $Id: report.h,v 1.4 2003/11/23 22:26:15 matt Exp $
*/

#ifndef _REPORT_H_
#define _REPORT_H_


/******************************************************************************
* Constants
******************************************************************************/

	/* action types */
#define REPORT_PERROR       ((unsigned int)0x00000001)
#define REPORT_DUMP         ((unsigned int)0x00000002)

	/* message types */
#define REPORT_ERROR        ((unsigned int)0x00000010)
#define REPORT_INFO         ((unsigned int)0x00000020)
#define REPORT_DEBUG        ((unsigned int)0x00000040)

	/* application types */
#define REPORT_DAEMON	    (1)
#define REPORT_USER	    	(0)


/******************************************************************************
* Defines
******************************************************************************/

#define REPORT(l,m) \
	if (report_level >= l) { report_auto m; }


/******************************************************************************
* Prototypes
******************************************************************************/

extern int  report_level;
extern int	report_level_set(int level);

extern int  report_usage(void);
extern int  report_options_parse(int argc, char** argv, int* argi);
extern int  report_options_check(void);

extern int  report_init(const char* name, const int mode);
extern void report_auto(const unsigned int flags, const char *format, ...);
extern void report(const int minlevel, const unsigned int flags, const char *format, ...);


#endif

