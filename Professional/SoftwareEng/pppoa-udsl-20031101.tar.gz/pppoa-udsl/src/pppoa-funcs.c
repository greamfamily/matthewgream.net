/*
 *  ALCATEL SpeedTouch USB modem utility : PPPoA implementation (3nd edition)
 *  Copyright (C) 2001 Benoit Papillault
 * 
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 *  Author : Edouard Gomez (ed.gomez@free.fr)
 *  Creation : 08/08/2001
 *  Refactor : Matthew Gream (matthew.gream@pobox.com)
 *
 *  This program is designed to work under pppd, with the option "pty". It can
 *  also be used as a daemon to create a tap device that rp-pppoe can use as a
 *  standard ethernet device (this is the ethernet bridging mode rfc 1483).
 *
 *  $Id: pppoa-funcs.c,v 1.1 2003/11/23 22:26:15 matt Exp $
 */

#ifndef _PPPOA_FUNCS_C_
#define _PPPOA_FUNCS C_

#undef USE_THREADS

#ifdef USE_THREADS
#include <pthread.h>
#else
#include <sys/types.h>
#include <sys/wait.h>
#endif


/*****************************************************************************
*	Bridging
*****************************************************************************/

int tap_open()
{
#if 0
    struct ifreq ifr;
    int fd, err;

    if( (fd = open("/dev/net/tun", O_RDWR | O_SYNC)) < 0 )
       return -1;

    memset(&ifr, 0, sizeof(ifr));
    ifr.ifr_flags = IFF_TAP | IFF_NO_PI;

    if( (err = ioctl(fd, TUNSETIFF, (void *) &ifr)) < 0 ){
       close(fd);
       return err;
    }

    return fd;
#else
    return -1;
#endif
}


/*****************************************************************************
*	Lock semaphore
*****************************************************************************/

#if defined(__GNU_LIBRARY__) && !defined(_SEM_SEMUN_UNDEFINED)
/* union semun is defined by including <sys/sem.h> */
#elif defined(__linux__) || defined(__NetBSD__)
/* according to X/OPEN we have to define it ourselves */
union semun {
        int val;                    /* value for SETVAL */
        struct semid_ds *buf;       /* buffer for IPC_STAT, IPC_SET */
        unsigned short int *array;  /* array for GETALL, SETALL */
        struct seminfo *__buf;      /* buffer for IPC_INFO */
};
#endif

#define PPPOA_LOCK_SEM_FMT(id) 	((int)('P'<<24)|('O'<<16)|('A'<<8)|((id)&0x000000ff))
static int pppoa_lock_sem = -1;
static int pppoa_lock_sid = -1;

int pppoa_lock_sem_obtain(int id)
{
	if((pppoa_lock_sem = semget(PPPOA_LOCK_SEM_FMT(id), 1, 0700)) < 0)
		return(-1);
	pppoa_lock_sid = id;
	report(2, REPORT_DEBUG, "Sempaphore obtained %d\n", id);
	return(0);
}
int pppoa_lock_sem_create(int id)
{
	union semun su;
	if((pppoa_lock_sem = semget(PPPOA_LOCK_SEM_FMT(id), 1, IPC_CREAT|IPC_EXCL|0700)) < 0)
		return(-1);
	su.val = 1;
	if(semctl(pppoa_lock_sem, 0, SETVAL, su) == -1)
		return(-1);
	pppoa_lock_sid = id;
	report(2, REPORT_DEBUG, "Sempaphore created %d\n", pppoa_lock_sid);
	return(0);
}
int pppoa_lock_sem_destroy(void)
{
	if(pppoa_lock_sem < 0)
		return(-1);
	semctl(pppoa_lock_sem, 0, IPC_RMID, 0);
	report(2, REPORT_DEBUG, "Sempaphore destroyed %d\n", pppoa_lock_sid);
	pppoa_lock_sid = -1;
	pppoa_lock_sem = -1;
	return(0);
}
void pppoa_lock_sem_acquire(void)
{
	struct sembuf sb;
	assert(pppoa_lock_sem >= 0);
	sb.sem_num = 0;
	sb.sem_op  =-1;
	sb.sem_flg = 0;
	semop(pppoa_lock_sem, &sb, 1);
	report(2, REPORT_DEBUG, "Sempaphore acquired %d\n", pppoa_lock_sid);
}
void pppoa_lock_sem_release(void)
{
	struct sembuf sb;
	assert(pppoa_lock_sem >= 0);
	sb.sem_num = 0;
	sb.sem_op  = 1;
	sb.sem_flg = 0;
	semop(pppoa_lock_sem, &sb, 1);
	report(2, REPORT_DEBUG, "Sempaphore released %d\n", pppoa_lock_sid);
}


/*****************************************************************************
*	Lock file/pid
*****************************************************************************/

#define PPPOA_LOCK_PID_SIZ	128
#define PPPOA_LOCK_PID_FMT 	"/var/run/pppoa%d.pid"
static int pppoa_lock_id = -1;

int pppoa_lock_file_obtain(int id)
{
	char filename[PPPOA_LOCK_PID_SIZ];
	FILE* f;
	int p;
	snprintf(filename, sizeof(filename), PPPOA_LOCK_PID_FMT, id);
	if((f = fopen(filename, "r")) == NULL)
		return(-1);
	fscanf(f, "%d", &p);
	fclose(f);
	pppoa_lock_id = id;
	report(2, REPORT_DEBUG, "Lockfile obtained %d (%s)\n", pppoa_lock_id, filename);
	return(p);
}
int pppoa_lock_file_create(int id)
{
	char filename[PPPOA_LOCK_PID_SIZ];
	FILE* f;
	int p;
	snprintf(filename, sizeof(filename), PPPOA_LOCK_PID_FMT, id);
	if((f = fopen(filename, "w")) == NULL)
		return(-1);
	fprintf(f, "%d", getpid());
	fclose(f);
	if((f = fopen(filename, "r")) == NULL)
		return(-1);
	fscanf(f, "%d", &p);
	fclose(f);
	if (p != getpid())
		return(-1);
	pppoa_lock_id = id;
	report(2, REPORT_DEBUG, "Lockfile created %d (%s)\n", pppoa_lock_id, filename);
	return(0);
}
int pppoa_lock_file_destroy(void)
{
	char filename[PPPOA_LOCK_PID_SIZ];
	if(pppoa_lock_id < 0)
		return(-1);
	snprintf(filename, sizeof(filename), PPPOA_LOCK_PID_FMT, pppoa_lock_id);
	unlink(filename);
	report(2, REPORT_DEBUG, "Lockfile destroyed %d (%s)\n", pppoa_lock_id, filename);
	pppoa_lock_id = -1;
	return(0);
}


/*****************************************************************************
*	Threading
*****************************************************************************/

typedef struct
{
	char*		name;
	int			running;
#ifdef USE_THREADS
	pthread_t	t_id;
	int			t_policy;
#else
	pid_t		t_id;
	int			t_priority;
#endif
	int			(*f_test)(void);
	void*		(*f_enter)(void *);
	void		(*f_exit)(void *);
	void*		f_data;
}thread_entry;

static void thread_exec_init(thread_entry* t);
static void thread_exec_go(thread_entry* t);
static void thread_exec_term(thread_entry* t);

#ifndef USE_THREADS
static int thread_exec_terminate = 0;
static thread_entry* thread_exec_current = 0;
static void thread_handler_child(int signal)
{
	union wait ws;
	pid_t p;
	while((p = wait3((int *)&ws,WNOHANG,NULL)) > 0)
	{
		/* ?? set running */
	}
}
static void thread_handler_intr(int signal)
{
	thread_exec_terminate++;
}
#endif

void thread_test()
{
#ifdef USE_THREADS
	pthread_testcancel();
#else
	if (thread_exec_terminate > 0 && thread_exec_current)
		thread_exec_term(thread_exec_current);
#endif

}

static void* thread_exec(void* p)
{
	thread_entry* t = (thread_entry*)p;
	thread_exec_current = t;
	thread_exec_init(t);
	thread_exec_go(t);
	thread_exec_term(t);
	return(0);
}

static void thread_exec_init(thread_entry* t)
{
	sigset_t s;

#ifdef USE_THREADS
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
	pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL);
#endif

	sigfillset(&s);
#ifdef USE_THREADS
	pthread_sigmask(SIG_SETMASK, &s, NULL);
	if (t->f_exit != 0)
		pthread_cleanup_push(t->f_exit, t->f_data);
#else
	sigprocmask(SIG_SETMASK, &s, NULL); /*XXX intr */
	signal(SIGINT, thread_handler_intr);
	setproctitle("%d: %s", cfg_lock_id, t->name);
#endif
}

static void thread_exec_go(thread_entry* t)
{
	if (t->f_enter != 0)
		(*t->f_enter)((void *)t);
}

static void thread_exec_term(thread_entry* t)
{
#ifdef USE_THREADS
	if (t->f_exit != 0)
		pthread_cleanup_pop(1);
#else
	if (t->f_exit != 0)
		(*t->f_exit)((void *)t);
#endif

	report(0, REPORT_INFO, "Thread Destroyed - %s\n", t->name);

	t->running = 0;

#ifdef USE_THREADS
	pthread_exit(0);
#else
	exit(0);
#endif
}

int thread_start(thread_entry* t)
{

	int r;
#ifdef USE_THREADS
	pthread_attr_t attr;
#endif

	if (t->running)
		return(-1);
	if (t->f_test != 0 && (*t->f_test)() < 0)
		return(0);

#ifdef USE_THREADS
	pthread_attr_init(&attr);
#ifdef USE_DETACH_THREADS
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
#endif
	pthread_attr_setschedpolicy(&attr, t->t_policy);
	r = pthread_create(&t->t_id, &attr, thread_exec, (void *)t);
	if(r != EAGAIN) {
		report(0, REPORT_INFO, "Thread Created - %s\n", t->name);
		t->running = 1;
	} else {
		report(0, REPORT_ERROR|REPORT_PERROR, "Thread Failed - %s (pthread_create)\n", t->name);
	}
	pthread_attr_destroy(&attr);
#else
	r = fork();
	switch(r) 
	{
		case -1:
			report(0, REPORT_ERROR|REPORT_PERROR, "Thread Failed - %s (fork)\n", t->name);
			break;
		case 0:
			thread_exec((void *)t);
			exit(0); /* will never reach here */
		default:
			signal(SIGCHLD, thread_handler_child);
			t->t_id = r;
			t->running = 1;
			report(0, REPORT_INFO, "Thread Created - %s\n", t->name);
			break;
	}
#endif
	return(r);

}

int thread_stop(thread_entry* t)
{

	if (!t->running)
		return(-1);

#ifdef USE_THREADS
	pthread_cancel(t->t_id);
	report(0, REPORT_INFO, "Thread Cancelled - %s", t->name);
#ifndef USE_DETACH_THREADS
	pthread_join(t->t_id, NULL);
#endif
	t->t_id = 0;
#else
	kill(t->t_id, SIGINT);
	report(0, REPORT_INFO, "Thread Killed - %s", t->name);
	t->t_id = 0;
#endif

	t->running = 0;

	return(0);

}


/*****************************************************************************
*	I/O
*****************************************************************************/

#define IO_ERROR_HARD(str) \
{ \
	REPORT(0, (REPORT_ERROR|REPORT_PERROR, "%s: failed\n", str)); \
	return(-1); \
}

#define IO_ERROR_SOFT(str, retry_max, retry_tmo, retry_cur) \
{ \
	static int errs = 0; ++errs; \
	if (++retry_cur > retry_max) { \
		REPORT(0, (REPORT_ERROR|REPORT_PERROR, "%s: failed (timeout)\n", str)); \
		return(-1); \
	} \
	if((errs < 10 || errs % 25 == 0)) { \
		REPORT(1, (REPORT_ERROR|REPORT_PERROR, "%s: warning (%d times)\n", str, errs)); \
	} \
	usleep(retry_tmo); \
}

#define PPP_STATE_WAITFOR_PPP_FRAME_ADDR 	0
#define PPP_STATE_DROP_PROTO         		1
#define PPP_STATE_BUILDING_PACKET    		2

#define PPP_FRAME_ESC   			0x7D
#define PPP_FRAME_FLAG  			0x7E
#define PPP_FRAME_ADDR  			0xFF
#define PPP_FRAME_CTRL  			0x03
#define PPP_FRAME_ENC   			0x20

#define PPP_ENCODE_BYTE(ptr,c) \
		*ptr++ = (c); 
#define PPP_ENCODE_BYTE_ESC(ptr,c) \
		if ((c) == PPP_FRAME_FLAG || (c) == PPP_FRAME_ADDR || (c) == PPP_FRAME_ESC || (c) < 0x20) { \
			*ptr++ = PPP_FRAME_ESC; *ptr++ = (c) ^ PPP_FRAME_ENC; \
		} else { \
			*ptr++ = (c); \
		}

#define PPP_FCS_INIT16			0xffff 

#define PPP_FCS_INIT(f) 		f = PPP_FCS_INIT16
#define PPP_FCS_CALC(f,p,l) 	f = pppFCS16 (f,p,l)
#define PPP_FCS_FINI(f) 		f ^= PPP_FCS_INIT16

static const unsigned short fcstab [256] = 
{
	0x0000, 0x1189, 0x2312, 0x329b, 0x4624, 0x57ad, 0x6536, 0x74bf,
	0x8c48, 0x9dc1, 0xaf5a, 0xbed3, 0xca6c, 0xdbe5, 0xe97e, 0xf8f7,
	0x1081, 0x0108, 0x3393, 0x221a, 0x56a5, 0x472c, 0x75b7, 0x643e,
	0x9cc9, 0x8d40, 0xbfdb, 0xae52, 0xdaed, 0xcb64, 0xf9ff, 0xe876,
	0x2102, 0x308b, 0x0210, 0x1399, 0x6726, 0x76af, 0x4434, 0x55bd,
	0xad4a, 0xbcc3, 0x8e58, 0x9fd1, 0xeb6e, 0xfae7, 0xc87c, 0xd9f5,
	0x3183, 0x200a, 0x1291, 0x0318, 0x77a7, 0x662e, 0x54b5, 0x453c,
	0xbdcb, 0xac42, 0x9ed9, 0x8f50, 0xfbef, 0xea66, 0xd8fd, 0xc974,
	0x4204, 0x538d, 0x6116, 0x709f, 0x0420, 0x15a9, 0x2732, 0x36bb,
	0xce4c, 0xdfc5, 0xed5e, 0xfcd7, 0x8868, 0x99e1, 0xab7a, 0xbaf3,
	0x5285, 0x430c, 0x7197, 0x601e, 0x14a1, 0x0528, 0x37b3, 0x263a,
	0xdecd, 0xcf44, 0xfddf, 0xec56, 0x98e9, 0x8960, 0xbbfb, 0xaa72,
	0x6306, 0x728f, 0x4014, 0x519d, 0x2522, 0x34ab, 0x0630, 0x17b9,
	0xef4e, 0xfec7, 0xcc5c, 0xddd5, 0xa96a, 0xb8e3, 0x8a78, 0x9bf1,
	0x7387, 0x620e, 0x5095, 0x411c, 0x35a3, 0x242a, 0x16b1, 0x0738,
	0xffcf, 0xee46, 0xdcdd, 0xcd54, 0xb9eb, 0xa862, 0x9af9, 0x8b70,
	0x8408, 0x9581, 0xa71a, 0xb693, 0xc22c, 0xd3a5, 0xe13e, 0xf0b7,
	0x0840, 0x19c9, 0x2b52, 0x3adb, 0x4e64, 0x5fed, 0x6d76, 0x7cff,
	0x9489, 0x8500, 0xb79b, 0xa612, 0xd2ad, 0xc324, 0xf1bf, 0xe036,
	0x18c1, 0x0948, 0x3bd3, 0x2a5a, 0x5ee5, 0x4f6c, 0x7df7, 0x6c7e,
	0xa50a, 0xb483, 0x8618, 0x9791, 0xe32e, 0xf2a7, 0xc03c, 0xd1b5,
	0x2942, 0x38cb, 0x0a50, 0x1bd9, 0x6f66, 0x7eef, 0x4c74, 0x5dfd,
	0xb58b, 0xa402, 0x9699, 0x8710, 0xf3af, 0xe226, 0xd0bd, 0xc134,
	0x39c3, 0x284a, 0x1ad1, 0x0b58, 0x7fe7, 0x6e6e, 0x5cf5, 0x4d7c,
	0xc60c, 0xd785, 0xe51e, 0xf497, 0x8028, 0x91a1, 0xa33a, 0xb2b3,
	0x4a44, 0x5bcd, 0x6956, 0x78df, 0x0c60, 0x1de9, 0x2f72, 0x3efb,
	0xd68d, 0xc704, 0xf59f, 0xe416, 0x90a9, 0x8120, 0xb3bb, 0xa232,
	0x5ac5, 0x4b4c, 0x79d7, 0x685e, 0x1ce1, 0x0d68, 0x3ff3, 0x2e7a,
	0xe70e, 0xf687, 0xc41c, 0xd595, 0xa12a, 0xb0a3, 0x8238, 0x93b1,
	0x6b46, 0x7acf, 0x4854, 0x59dd, 0x2d62, 0x3ceb, 0x0e70, 0x1ff9,
	0xf78f, 0xe606, 0xd49d, 0xc514, 0xb1ab, 0xa022, 0x92b9, 0x8330,
	0x7bc7, 0x6a4e, 0x58d5, 0x495c, 0x3de3, 0x2c6a, 0x1ef1, 0x0f78
};

static unsigned short pppFCS16 (unsigned short fcs, const unsigned char * cp, int len)
{
	while (len--)
		fcs = (fcs >> 8) ^ fcstab [(fcs ^ *cp++) & 0xff];
	return (fcs);
}





#define HDLC_HEADER_SIZE    	(2)
#define BRIDGING1483_HEADER 	(10)

#define ATM_CELL_EXCESS_SIZE	(3)
#define AAL5_FRAME_BUFFER_SIZE	(AAL5_FRAME_MAX_SIZE + HDLC_HEADER_SIZE + BRIDGING1483_HEADER)
#define ATM_CELL_BUFFER_SIZE 	((AAL5_FRAME_MAX_SIZE / ATM_CELL_DATA_SIZE) * (ATM_CELL_TOTAL_SIZE + ATM_CELL_EXCESS_SIZE))
#define PPP_ASYNC_BUFFER_SIZE	(4096)

/* You may get better performance from increasing this (e.g. to ATM_CELL_BUFFER_SIZE), at the risk
 * of USB jabber errors, and possible IPC buffer overflows - you have been warned!
 */
#define ATM_CELL_RDBUF_SIZE 	(64 * (ATM_CELL_TOTAL_SIZE + ATM_CELL_EXCESS_SIZE))

#if AAL5_FRAME_BUFFER_SIZE > ATM_CELL_BUFFER_SIZE
#error ATM_CELL_BUFFER_SIZE constant must be greater than AAL5_FRAME_BUFFER_SIZE !
#endif

#define DATA_TIMEOUT 1000
#define DATA_RETRIES 3



int ppp_read(int fd, unsigned char *buffer_ptr, int buffer_sz)
{
	while (1) {

		if (cfg_syncHDLC) {

			int r;

			while ((r = read(fd, buffer_ptr, buffer_sz)) < 0) {
				if (errno == ENOBUFS || errno == EINTR || errno == EAGAIN || errno == ETIMEDOUT) {
					;
				} else {
					IO_ERROR_HARD("ppp_read");
				}
			}
			if(r == 0) {
				return(0);
			}
			if(r <= HDLC_HEADER_SIZE && !cfg_bridging) {
				report(0, REPORT_ERROR, "ppp_read: short read (%d bytes) ignored\n", r);
				continue;
			}
			if(r == buffer_sz) {
				report(0, REPORT_ERROR, "ppp_read: long read (%d bytes) ignored\n", r);
				continue;
			}

			REPORT(2, (REPORT_DEBUG|REPORT_DUMP, "ppp_read: PPP read from PTY (%d bytes)\n", buffer_ptr, r, r));

			return(r);

		} else {

			static int r=0;
			static unsigned char buf[PPP_ASYNC_BUFFER_SIZE];
			static unsigned char* ptr = buf;
			static int len = PPP_ASYNC_BUFFER_SIZE;

			static int PPPState=PPP_STATE_WAITFOR_PPP_FRAME_ADDR;
			static int PPPPacketSize=0;
			static int PPPXorValue=0;
		    
			if (r <= 0) {
				ptr = buf;
				while ((r = read(fd, buf, len)) < 0) {
					if (errno == ENOBUFS || errno == EINTR || errno == EAGAIN || errno == ETIMEDOUT) {
						;
					} else {
						IO_ERROR_HARD("ppp_read");
					}
				}
				if(r == 0) {
					return(0);
				}
				REPORT(2, (REPORT_DEBUG|REPORT_DUMP, "ppp_read: PPP read from PTY (%d bytes)\n", buf, r, r));
			}

			if (r && PPPState == PPP_STATE_WAITFOR_PPP_FRAME_ADDR) {
				if (*ptr == PPP_FRAME_ADDR) {
					PPPState = PPP_STATE_DROP_PROTO;
					PPPPacketSize = 0;
					PPPXorValue = 0;
				}
				r--;
				ptr++;
			}
		    
			if (r && PPPState == PPP_STATE_DROP_PROTO) {
				if (*ptr == (PPP_FRAME_CTRL ^ PPP_FRAME_ENC)) {
					PPPState = PPP_STATE_BUILDING_PACKET;
				}
				r--;
				ptr++;
			}

			while (r && PPPState == PPP_STATE_BUILDING_PACKET) {
				switch(*ptr) {
				case PPP_FRAME_ESC:
					PPPXorValue = PPP_FRAME_ENC;
					break;
				case PPP_FRAME_FLAG:
					PPPState = PPP_STATE_WAITFOR_PPP_FRAME_ADDR;
					if ((HDLC_HEADER_SIZE + PPPPacketSize) <= HDLC_HEADER_SIZE) {
						report(0, REPORT_ERROR, "ppp_read: short read (%d bytes) ignored\n", PPPPacketSize);
						break;
					}
					return(HDLC_HEADER_SIZE + PPPPacketSize);
				default:
					if((HDLC_HEADER_SIZE + PPPPacketSize) == buffer_sz) {
						report(0, REPORT_ERROR, "ppp_read: long read (%d bytes) ignored\n", PPPPacketSize);
						PPPState = PPP_STATE_WAITFOR_PPP_FRAME_ADDR;
						break;
					}
					buffer_ptr[HDLC_HEADER_SIZE + PPPPacketSize++] = *ptr ^ PPPXorValue;
					PPPXorValue = 0;
					break;
				}
				r--;
				ptr++;
			}
		}
	}
}

int ppp_write(int fd, unsigned char *buffer_ptr, int buffer_sz, int t, int r)
{
	int buffer_wr, retries = 0;

	if (!cfg_syncHDLC) {

		static unsigned char head[4096] = { PPP_FRAME_ADDR, PPP_FRAME_CTRL };

		unsigned char* ptr = &head[2];
		unsigned short fcs;
		int i;

		PPP_FCS_INIT (fcs);
		PPP_FCS_CALC (fcs, head, 2);
		PPP_FCS_CALC (fcs, buffer_ptr + 2, buffer_sz - 2);
		PPP_FCS_FINI (fcs);

		PPP_ENCODE_BYTE    	(ptr, PPP_FRAME_FLAG);
		PPP_ENCODE_BYTE    	(ptr, PPP_FRAME_ADDR);
		PPP_ENCODE_BYTE_ESC	(ptr, PPP_FRAME_CTRL);
		for (i = 2; i < buffer_sz; i++) {
			PPP_ENCODE_BYTE_ESC(ptr, buffer_ptr[i]);
		}
		PPP_ENCODE_BYTE_ESC	(ptr, fcs        & 0x00ff);
		PPP_ENCODE_BYTE_ESC	(ptr, (fcs >> 8) & 0x00ff);
		PPP_ENCODE_BYTE    	(ptr, PPP_FRAME_FLAG);

		buffer_ptr = head;
		buffer_sz = (ptr - head);
	}

	REPORT(2, (REPORT_DEBUG|REPORT_DUMP, "ppp_write: PPP write to PTY (%d bytes)\n",
		buffer_ptr, buffer_sz, buffer_sz));
	while ((buffer_wr = write(fd, buffer_ptr, buffer_sz)) < 0) {
		if (errno == ENOBUFS || errno == EINTR || errno == EAGAIN) {
			IO_ERROR_SOFT("ppp_write", r, t, retries);
		} else {
			IO_ERROR_HARD("ppp_write");
		}
	}
	return(buffer_wr);
}

int usb_read(product_t* prod, unsigned char *buffer_ptr, int buffer_sz, int t, int r)
{
	int buffer_rd;
	while ((buffer_rd = product_data_read(prod, buffer_ptr, buffer_sz, t)) < 0) {
		if (errno == ENOBUFS || errno == EINTR || errno == EAGAIN || errno == ETIMEDOUT) {
			;
		} else {
			IO_ERROR_HARD("usb_read");
		}
	}
	REPORT(2, (REPORT_DEBUG|REPORT_DUMP, "usb_read: ATM read from USB (%d bytes)\n", 
		buffer_ptr, buffer_rd, buffer_rd));
	return(buffer_rd);
}

int usb_write(product_t* prod, unsigned char *buffer_ptr, int buffer_sz, int t, int r)
{
	int buffer_wr, retries = 0;
	REPORT(2, (REPORT_DEBUG|REPORT_DUMP, "usb_write: ATM write to USB (%d bytes)\n",
		buffer_ptr, buffer_sz, buffer_sz));
	while ((buffer_wr = product_data_write(prod, buffer_ptr, buffer_sz, t)) < 0) {
		if (errno == ENOBUFS || errno == EINTR || errno == EAGAIN) {
			IO_ERROR_SOFT("usb_write", r, t, retries);
		} else {
			IO_ERROR_HARD("usb_write");
		}
	}
	return(buffer_wr);
}

#endif
