/*
*  ALCATEL SpeedTouch USB modem microcode upload & ADSL link UP utility
*  Copyright (C) 2001 Benoit PAPILLAULT
*  
*  This program is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public License
*  as published by the Free Software Foundation; either version 2
*  of the License, or (at your option) any later version.
*  
*  This program is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*  
*  You should have received a copy of the GNU General Public License
*  along with this program; if not, write to the Free Software
*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*
*  Author   : Benoit PAPILLAULT <benoit.papillault@free.fr>
*  Creation : 05/03/2001
*  Refactor : Matthew Gream (matthew.gream@pobox.com)
*  
*  This program uploads the microcode to the ALCATEL SpeedTouch USB modem.
*  It uses libusb (http://libusb.sourceforge.net/).
*  
*  The microcode can be uploaded only once. If the upload is correct,
*  ADSL led should be both green & red.
*  
*  If you try to download the microcode twice, you will get tons of
*  timeout errors.
*
*  $Id: pppoactl.c,v 1.6 2003/11/23 22:26:15 matt Exp $
*/

#ifndef _PPPOACTL_C_
#define _PPPOACTL_C_

#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <pwd.h>

#include "pusb.h"
#include "product.h"
#include "report.h"


/*****************************************************************************
* Variables
*****************************************************************************/

int cfg_connect_wait = 45;
char *cfg_device_name = NULL;
int cfg_signal_kernel = 0;
int cfg_setup_retries = 10;

static int pppoactl_general_usage(void)
{

	fprintf(stderr, "Customisation:\n");
	fprintf(stderr, "  -t [0-n]     : seconds  to wait for device connect (ADSL line)\n");
	fprintf(stderr, "  -r [0-n]     : attempts to retry device configure\n");
	fprintf(stderr, "  -d device    : defines the device to use\n");
	fprintf(stderr, "  -k           : allow use of kernel mode driver\n");

	return(0);

}

static int pppoactl_general_options_parse(int argc, char** argv, int* argi)
{

	if (strcmp(argv[*argi],"-t")==0 && (*argi)+1<argc)
		cfg_connect_wait = atol(argv[++(*argi)]);
	else if (strcmp(argv[*argi],"-r")==0 && (*argi)+1<argc)
		cfg_setup_retries = atol(argv[++(*argi)]);
	else if(strcmp(argv[*argi], "-d") == 0 && (*argi)+1<argc)
		cfg_device_name = argv[++(*argi)];
	else if (strcmp(argv[*argi], "-k")==0)
		cfg_signal_kernel = 1;
	else
		return(-1);

	return(0);

}

static int pppoactl_general_options_check(void)
{

	return(0);

}


/******************************************************************************
* Prototypes
******************************************************************************/

/* pppoactl options */
static int pppoactl_options_parse(int argc, char** argv);
static int pppoactl_options_check(void);
static int pppoactl_usage(void);

/* pppoactl setup */
static int pppoactl_setup_program(void);
static int pppoactl_setup_options(int argc, char** argv);

/* pppoactl general options */
static int pppoactl_general_options_parse(int argc, char** argv, int* argi);
static int pppoactl_general_options_check(void);
static int pppoactl_general_usage(void);

/* pppoactl command options */
static int pppoactl_command_options_parse(int argc, char **argv, int* argi);
static int pppoactl_command_options_check(void);
static int pppoactl_command_execute(product_t* prod);
static int pppoactl_command_usage(void);

/* pppoactl command */
static int pppoactl_command_check(product_t* prod);
static int pppoactl_command_config(product_t* prod);
static int pppoactl_command_connect(product_t* prod);
static int pppoactl_command_disconnect(product_t* prod);
static int pppoactl_command_report(product_t* prod);

/* pppoactl device activities */
static product_t* pppoactl_device_open(const char* device);
static int pppoactl_device_check(product_t* prod);
static int pppoactl_device_setup(product_t* prod, int retries);
static int pppoactl_device_acquire(product_t* prod, product_acquire_t acq);
static int pppoactl_device_release(product_t* prod, product_acquire_t acq);
static int pppoactl_device_config(product_t* prod);
static int pppoactl_device_connect(product_t* prod, time_t delay);
static int pppoactl_device_disconnect(product_t* prod, time_t delay);
static int pppoactl_device_report(product_t* prod);
static int pppoactl_device_close(product_t* prod);


/*****************************************************************************
* Main
*****************************************************************************/

int main(int argc, char *argv[])
{

	int code;
	product_t* prod = NULL;


	/* 
	 * Initialisation
	 */

	if (pppoactl_setup_options(argc, argv) < 0)
		return(-1);

	if (pppoactl_setup_program() < 0)
		return(-1);


	/* 
	 * Operation
	 */
	if ((prod = pppoactl_device_open(cfg_device_name)) == NULL)
		return(-1);

	code = pppoactl_command_execute(prod);

	if (pppoactl_device_close(prod) < 0)
		return(-1);

	return code;

}


/*****************************************************************************
* Commands
*****************************************************************************/

static int pppoactl_command_check(product_t* prod)
{

	if (pppoactl_device_acquire(prod, PRODUCT_ACQ_INFO) < 0)
		return(-1);

	if (pppoactl_device_check(prod) < 0)
		return(-1);

	if (pppoactl_device_release(prod, PRODUCT_ACQ_INFO) < 0)
		return(-1);

	return(0);

}

static int pppoactl_command_config(product_t* prod)
{

	if (pppoactl_device_setup(prod, cfg_setup_retries) < 0)
		return(-1);

	if (pppoactl_device_acquire(prod, PRODUCT_ACQ_INFO|PRODUCT_ACQ_DATA) < 0)
		return(-1);

	if (pppoactl_device_config(prod) < 0)
		return(-1);

	if (pppoactl_device_connect(prod, cfg_connect_wait) < 0)
		return(-1);

	if (pppoactl_device_release(prod, PRODUCT_ACQ_INFO|PRODUCT_ACQ_DATA) < 0)
		return(-1);

	return(0);

}

static int pppoactl_command_connect(product_t* prod)
{

	if (pppoactl_device_acquire(prod, PRODUCT_ACQ_INFO) < 0)
		return(-1);

	if (pppoactl_device_connect(prod, cfg_connect_wait) < 0)
		return(-1);

	if (pppoactl_device_release(prod, PRODUCT_ACQ_INFO) < 0)
		return(-1);

	return(0);

}

static int pppoactl_command_disconnect(product_t* prod)
{

	if (pppoactl_device_acquire(prod, PRODUCT_ACQ_INFO) < 0)
		return(-1);

	if (pppoactl_device_disconnect(prod, cfg_connect_wait) < 0)
		return(-1);

	if (pppoactl_device_release(prod, PRODUCT_ACQ_INFO) < 0)
		return(-1);

	return(0);

}

static int pppoactl_command_report(product_t* prod)
{

	if (pppoactl_device_acquire(prod, PRODUCT_ACQ_INFO) < 0)
		return(-1);

	if (pppoactl_device_report(prod) < 0)
		return(-1);

	if (pppoactl_device_release(prod, PRODUCT_ACQ_INFO) < 0)
		return(-1);

	return(0);

}


struct pppoactl_command_item { 
	const char* name;
	const char* desc;
	int (* execute) (product_t* );
};
static const struct pppoactl_command_item pppoactl_command_list[] = {
	{ "check", "check for presence of USB ADSL device", &pppoactl_command_check },
	{ "config", "config the USB ADSL device (incl. check)", &pppoactl_command_config },
	{ "connect", "connect the ADSL line", &pppoactl_command_connect },
	{ "disconnect", "disconnect the ADSL line", &pppoactl_command_disconnect },
	{ "report", "report on the ADSL line", &pppoactl_command_report }
};
const struct pppoactl_command_item* cfg_command = NULL;

static int pppoactl_command_options_parse(int argc, char **argv, int* argi)
{
	int i;
	for (i = 0; i < sizeof(pppoactl_command_list) / 
			sizeof(struct pppoactl_command_item); ++i) {
		if (strcmp(pppoactl_command_list[i].name, argv[*argi]) == 0) {
			cfg_command = &pppoactl_command_list[i];
			return (0);
		}
	}
	return(-1);
}

static int pppoactl_command_options_check(void)
{
	if (cfg_command == NULL)
		return(-1);
	return(0);
}

static int pppoactl_command_execute(product_t* prod)
{
	if (cfg_command == NULL)
		return(-1);
	return(* cfg_command->execute)(prod);
}

static int pppoactl_command_usage(void)
{
	int i;
	fprintf(stderr, "Commands:\n");
	for (i = 0; i < sizeof(pppoactl_command_list) / 
			sizeof(struct pppoactl_command_item); ++i) {
		const struct pppoactl_command_item* item = &pppoactl_command_list[i];
		fprintf(stderr, "  %-12s : %s\n", item->name, item->desc);
	}
	return(0);
}

/*****************************************************************************
* Configuration
*****************************************************************************/

static int pppoactl_setup_options(int argc, char** argv)
{

	if (pppoactl_options_parse(argc, argv) < 0)
		pppoactl_usage();

	if (pppoactl_options_check() < 0)
		pppoactl_usage();

	return(0);

}

static int pppoactl_setup_program(void)
{

	char *user;
	
	/*
	* Security stuff
	* 1 - be sure to be root
	* 2 - umask to prevent critical data being read from log file
	*/
	if(geteuid() != 0) {
		fprintf(stderr, "pppoactl must be run with root privileges\n");
		return(-1);
	}

	/* Gets user login */
	user = getlogin();

	if(user == NULL) {

		struct passwd *pw;

		pw = getpwuid(getuid());

		if( pw != NULL && pw->pw_name != NULL)
			user = pw->pw_name;
		else
			user = "Unknown";
	}

	if (report_init("pppoactl", REPORT_USER) < 0) {
		fprintf(stderr, "pppoactl could not start reporting\n");
		return(-1);
	}

	report(0, REPORT_INFO, "pppoactl V%s started by %s uid %u\n", 
		VERSION, user, getuid());

	return(0);

}


/*****************************************************************************
* Operation
*****************************************************************************/

static product_t* pppoactl_device_open(const char* device)
{

	product_t* prod = NULL;

	/* 
	 * Open the device explicitly or via probe
	 */

	if (device == NULL) {

		prod = product_open_probe();

		if (prod == NULL) {
			report(0, REPORT_ERROR, "USB DSL modem: Not found (probe)\n");
			return(NULL);
		}

	} else {

		prod = product_open_name(device);

		if (prod == NULL) {
			report(0, REPORT_ERROR, "USB DSL modem: Not found (%s)\n", device);
			return(NULL);
		}

	}

	report(0, REPORT_INFO, "USB DSL modem: Found '%s' (ID:%04X/%04X)\n",
		prod->name, prod->id_vendor, prod->id_product);

	return prod;

}

static int pppoactl_device_close(product_t* prod)
{

	/* 
	 * Close the device
	 */

	return product_close(prod);

}

static int pppoactl_device_setup(product_t* prod, int retries)
{

	int retry;

	/* 
	 * Setup and verify the device (e.g. firmware, parameters, etc)
 	 */

	if (product_acquire(prod, PRODUCT_ACQ_INFO, &cfg_signal_kernel) < 0) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed configure (acquire)\n");

		return(-1);
	}

	switch (product_setup_check (prod)) {

	    case 0:

		for (retry = 0; retry < retries; retry++) {

			if (product_setup_config (prod) < 0) {

				report(1, REPORT_ERROR, 
					"USB DSL modem: Failed configure (%d of %d)\n", retry, retries);

			} else {

				break;
			}
		}

		if (retry == retries) {

			report(0, REPORT_ERROR, "USB DSL modem: Failed configure (config + verify)\n");

			return(-1);
		}

		break;

	    case 1:
		
		report(0, REPORT_INFO, "USB DSL modem: Configured (already)\n");

		break;

	    default:
		
		report(0, REPORT_ERROR, "USB DSL modem: Failed configure (check)\n");

		return(-1);	

	}

	if (product_release(prod, PRODUCT_ACQ_INFO) < 0) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed configure (release)\n");

		return(-1);
	}

	if (product_setup_wait(prod)) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed configure (wait)\n");

		return(-1);
	}

	if (product_acquire(prod, PRODUCT_ACQ_INFO, &cfg_signal_kernel) < 0) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed configure (acquire)\n");

		return(-1);
	}

	if (product_setup_check(prod) < 0) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed configure (check)\n");

		return(-1);
	}

	if (product_setup_report(prod)) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed configure (report)\n");

		return(-1);
	}

	if (product_release(prod, PRODUCT_ACQ_INFO) < 0) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed configure (release)\n");

		return(-1);
	}

	return(0);

}

static int pppoactl_device_check(product_t* prod)
{

	/* 
	 * Check the device (is it configured ?)
 	 */

	switch (product_setup_check(prod)) {

	  case 0:

		report(0, REPORT_INFO, "USB DSL modem: Unconfigured\n");

		break;

	  case 1:

		report(0, REPORT_INFO, "USB DSL modem: Configured\n");

		break;


	  default: 

		report(0, REPORT_ERROR, "USB DSL modem: Failed check (configure)\n");

		return(-1);
	}

	return(0);

}

static int pppoactl_device_acquire(product_t* prod, product_acquire_t acq)
{

	if (product_acquire(prod, acq, &cfg_signal_kernel) < 0) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed acquire\n");

		return(-1);
	}

	return(0);

}

static int pppoactl_device_release(product_t* prod, product_acquire_t acq)
{

	if (product_release(prod, acq) < 0) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed release\n");

		return(-1);

	}

	return(0);

}

static int pppoactl_device_config(product_t* prod)
{

	/*
	 * Configure and verify the device
	 */

	if (product_adsl_config(prod) < 0) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed config (create)\n");

		return(-1);
	}

	if (product_adsl_verify(prod) < 0) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed config (verify)\n");

		return(-1);
	}

	return(0);

}

static int pppoactl_device_connect(product_t* prod, time_t delay)
{

	/*
	 * Connect the device, and wait for connect
	 */

	if (product_adsl_connect(prod) < 0) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed connect (request)\n");

		return(-1);
	}

	if (delay > 0)  {

		time_t final = time(0) + delay;

		while(difftime(final, time(0)) > 0 && !product_adsl_connect_check(prod)) {
			product_adsl_connect_wait(prod);
		}
	}


	/*
	 * Report state about connect 
	 */

	switch (product_adsl_connect_check(prod))
	{
	    case 1:

		if (product_adsl_report(prod)) {

			report(0, REPORT_ERROR, "USB DSL modem: Failed connect (report)\n");

			return(-1);
		}

		report(0, REPORT_INFO, "USB DSL modem: Connected\n");

		break;

	    case 0:

		report(0, REPORT_INFO, "USB DSL modem: Disconnected\n");

		break;

	    default:

		report(0, REPORT_INFO, "USB DSL modem: Failed connect (check)\n");

		return(-1);
	}

	return(0);

}

static int pppoactl_device_disconnect(product_t* prod, time_t delay)
{

	/*
	 * Disconnect the device, and wait for disconnect
	 */

	if (product_adsl_disconnect(prod) < 0) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed disconnect (request)\n");

		return(-1);
	}

	if (delay > 0)  {

		time_t final = time(0) + delay;

		while(difftime(final, time(0)) > 0 && !product_adsl_disconnect_check(prod)) {
			product_adsl_disconnect_wait(prod);
		}
	}


	/*
	 * Report state about device
	 */

	switch (product_adsl_disconnect_check(prod))
	{
	    case 1:

		if (product_adsl_report(prod)) {

			report(0, REPORT_ERROR, "USB DSL modem: Failed disconnect (report)\n");

			return(-1);
		}

		report(0, REPORT_INFO, "USB DSL modem: Disconnected\n");

		break;

	    case 0:

		report(0, REPORT_INFO, "USB DSL modem: Connected\n");

		break;

	    default:

		report(0, REPORT_INFO, "USB DSL modem: Failed disconnect (check)\n");

		return(-1);
	}

	return(0);

}

static int pppoactl_device_report(product_t* prod)
{

	/*
	 * Report state about device
	 */

	if (product_setup_report(prod)) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed report (setup)\n");

		return(-1);
	}

	if (product_adsl_report(prod)) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed report (connect)\n");

		return(-1);
	}

	if (product_data_report(prod)) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed report (data)\n");

		return(-1);
	}

	return(0);

}


/*****************************************************************************
*	Subroutines
*****************************************************************************/

static int pppoactl_usage()
{

	fprintf(stderr, "pppoactl V%s:\n", VERSION);
	fprintf(stderr, "usage: pppoactl [options] command\n");
	fprintf(stderr, "General options:\n");
	fprintf(stderr, "  -h / --help  : command help message\n");
	report_usage();
	pppoactl_general_usage();
	product_usage();
	pppoactl_command_usage();

	exit(-1);

	return(0);
}

static int pppoactl_options_parse(int argc, char** argv)
{

	int i;

	for (i = 1; i < argc; ++i)
	{
		if (strcmp(argv[i], "-h")==0 || strcmp(argv[i], "--help") == 0)
			pppoactl_usage();
		else {
			if (report_options_parse(argc, argv, &i) >= 0)
				continue;
			if (pppoactl_general_options_parse(argc, argv, &i) >= 0)
				continue;
			if (product_options_parse(argc, argv, &i) >= 0)
				continue;
			if (pppoactl_command_options_parse(argc, argv, &i) >= 0)
				continue;
			return(-1);
		}
	}

	return(0);

}

static int pppoactl_options_check()
{

	if (pppoactl_command_options_check() < 0)
		return(-1);

	if (report_options_check() < 0)
		return(-1);

	if (pppoactl_general_options_check() < 0)
		return(-1);

	if (product_options_check() < 0)
		return(-1);

	return(0);

}

#endif /* _PPPOACTL_C_*/
