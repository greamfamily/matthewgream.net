/*
*  ALCATEL SpeedTouch USB : Little atm library
*  Copyright (C) 2001 Benoit Papillault
* 
*  This program is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public License
*  as published by the Free Software Foundation; either version 2
*  of the License, or (at your option) any later version.
*  
*  This program is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*  
*  You should have received a copy of the GNU General Public License
*  along with this program; if not, write to the Free Software
*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*
*  Author : Edouard Gomez (ed.gomez@free.fr)
*  Creation : 14/08/2001
*  Refactor : Matthew Gream (matthew.gream@pobox.com)
*
* $Id: atm.c,v 1.5 2003/11/23 22:26:15 matt Exp $
*/

#ifndef _ATM_C_
#define _ATM_C_

#include <stdio.h>
#include <string.h>

#include "atm.h"
#include "crc.h"
#include "report.h"


/******************************************************************************
* Constants
******************************************************************************/

/* pti bits - see uni3.1 spec?*/
#define ATM_PTI_USER_CELL   0x00
#define ATM_PTI_OAM_CELL    0x04    /* 100 */

/* User cells - we only care about the SDU bit used to signal the end of an AAL5 frame */
#define ATM_USER_SDU        (ATM_PTI_USER_CELL|0x01)  /* 001 (or 011) */

/* OAM cells - see ITU spec I.610 for details, not that we currently handle them */
#define ATM_OAM_SEG         (ATM_PTI_MNGT_CELL|0x00)
#define ATM_OAM_E2E         (ATM_PTI_MNGT_CELL|0x01)
#define ATM_OAM_RESERVED    (ATM_PTI_MNGT_CELL|0x02)


/******************************************************************************
* ATM cell related Functions
******************************************************************************/

	/*
	* ATM UNI cell header
	*
	*  8     7     6     5     4     3     2     1  
	* *************************************************
	* *          GFC        *          VPI            *
	* *************************************************
	* *         (VPI)       *                         *
	* ***********************                         *
	* *                      VCI                      *
	* *                     ***************************
	* *                     *         PTI     *  CLP  *
	* *************************************************
	* *                Header CRC                     *
	* *************************************************
	*
	*/


static void atm_header_create(unsigned char *head, int vpi, int vci, int pti, int clp)
{
	vpi &= 0x000000ff;
	vci &= 0x0000ffff;
	pti &= 0x00000007;
	clp &= 0x00000001;

	head[0] =  (vpi >> 4);
	head[1] =  (vpi << 4) | (vci >> 12);
	head[2] =  (vci & 0x00000ff0) >> 4;
	head[3] = ((vci & 0x0000000f) << 4) | (pti << 1) | clp;
#ifdef DEBUG
	head[4] =  atm_calc_hec(header);
#else
	head[4] = 0xec; /* Arbitrary constant */
#endif
}

#define atm_header_get_vpi(cell) \
	((((int)(cell)[0])<<4) | (((int)(cell)[1])>>4))

#define atm_header_get_vci(cell) \
	((((int)((cell)[1]&0x0f))<<12) | (((int)(cell)[2])<<4) | (((int)((cell)[3]&0xf0))>>4))

#define atm_header_get_pti(cell) \
	(((cell)[3]&0x0e)>>1)

#define atm_header_get_clp(cell) \
	((cell)[3]&0x01)

#define atm_cell_create(cell, data, head) \
	memmove(cell + ATM_CELL_HEADER_SIZE, data, ATM_CELL_DATA_SIZE), \
	memmove(cell, head, ATM_CELL_HEADER_SIZE)

#define atm_cell_read(data, cell) \
	memmove(data, cell + ATM_CELL_HEADER_SIZE, ATM_CELL_DATA_SIZE)


/******************************************************************************
* AAL5 frame related Functions
******************************************************************************/

unsigned int aal5_frame_enc (unsigned char *frame, const unsigned char *data, const unsigned int data_len)
{
	unsigned int frame_len	= ATM_CELL_DATA_SIZE * ((data_len + 8 + ATM_CELL_DATA_SIZE - 1) / ATM_CELL_DATA_SIZE);
	unsigned int frame_crc;

	if (frame != data)
		memcpy (frame, data, data_len);
	if (frame_len != data_len)
		memset (frame + data_len, 0, (frame_len - data_len));

	frame [frame_len - 6] = (data_len & 0x0000ff00) >> 8;
	frame [frame_len - 5] = (data_len & 0x000000ff);

	AAL5_CRC_INIT (frame_crc);
	AAL5_CRC_CALC (frame_crc, frame, (frame_len - 4));
	AAL5_CRC_FINI (frame_crc);

	frame [frame_len - 4] = (frame_crc & 0xff000000) >> 24;
	frame [frame_len - 3] = (frame_crc & 0x00ff0000) >> 16;
	frame [frame_len - 2] = (frame_crc & 0x0000ff00) >> 8;
	frame [frame_len - 1] = (frame_crc & 0x000000ff);

	return (frame_len);
}

unsigned int aal5_frame_dec (unsigned char *data, const unsigned char *frame, const unsigned int frame_len)
{
	unsigned int data_len	= frame [frame_len - 6] << 8 |
							  frame [frame_len - 5];
	unsigned int data_crc	= frame [frame_len - 4] << 24 |
							  frame [frame_len - 3] << 16 |
							  frame [frame_len - 2] << 8 |
							  frame [frame_len - 1];
	unsigned int frame_crc;

	if (data_len > (frame_len - 8))
	{
		REPORT (2, (REPORT_DEBUG|REPORT_DUMP, "AAL5 frame: invalid LENGTH\n", frame, frame_len));
		return (-2);
	}

	AAL5_CRC_INIT (frame_crc);
	AAL5_CRC_CALC (frame_crc, frame, (frame_len - 4));
	AAL5_CRC_FINI (frame_crc);

	if (data_crc != frame_crc)
	{
		REPORT (2, (REPORT_DEBUG|REPORT_DUMP, "AAL5 frame: invalid CRC\n", frame, frame_len));
		return (-1);
	}

	if (data != frame)
	{
		memmove(data, frame, data_len);
	}

	return (data_len);
}


int aal5_frame_to_atm_cells(unsigned char *atm_cells, const unsigned char *aal5_frame, const int length, const int excess, const int vpi, const int vci)
{
	unsigned int cells = (length/ATM_CELL_DATA_SIZE) - 1;
	const unsigned char *src = aal5_frame + (ATM_CELL_DATA_SIZE*cells);
	unsigned char *dst = atm_cells  + ((ATM_CELL_TOTAL_SIZE+excess)*cells);
	unsigned char head[5];

	if(length%ATM_CELL_DATA_SIZE)
		return(-1);
	
	atm_header_create(head, vpi, vci, 1, 0);
	atm_cell_create(dst, src, head);

	atm_header_create(head, vpi, vci, 0, 0);
	while (cells--) 
	{
		src -= ATM_CELL_DATA_SIZE;
		dst -= (ATM_CELL_TOTAL_SIZE+excess);

		atm_cell_create(dst, src, head);
	}

	return((length/ATM_CELL_DATA_SIZE) * (ATM_CELL_TOTAL_SIZE+excess));
}

int aal5_frame_from_atm_cells(unsigned char *aal5_frame, unsigned char *atm_cells, const int length, const int excess, const int vpi, const int vci, int *pos, unsigned char **nptr, int *nlen)
{
	unsigned char *src = atm_cells;
	unsigned char *dst = aal5_frame + *pos;
	int len = length;
	int jnk = length % (excess + ATM_CELL_TOTAL_SIZE);
	int pti = 0;

	if (jnk > 0)
	{
		int i;
		
		for (i = 0; i < ATM_CELL_TOTAL_SIZE - 4; i++) 
		{
			if (atm_header_get_vpi(src + i) == vpi && atm_header_get_vci(src + i) == vci &&
			    atm_calc_hec(src + i) == *(src + i + 4)) 
			{
				src += i;
				len -= i;
				break;
			}
		}

		REPORT(2, (REPORT_DEBUG, "ATM Cell: excess data (%d bytes) [%d]\n", jnk, i));
	}

	while (len > 0) 
	{
		if ((*pos + (ATM_CELL_DATA_SIZE + excess)) > (ATM_CELL_MAX_SIZE - 1)) 
		{
			*pos = 0;
			return(-1);
		}

		if (vpi != atm_header_get_vpi(src) || vci != atm_header_get_vci(src)) 
		{
			REPORT(0, (REPORT_INFO, "ATM Cell: wrong VPI(%d)/VCI(%d) PTI=0x%.2x\n",
				atm_header_get_vpi(src), atm_header_get_vci(src), atm_header_get_pti(src)));
			src += (ATM_CELL_TOTAL_SIZE + excess);
			len -= (ATM_CELL_TOTAL_SIZE + excess);
			pti = 0;
			continue;
		}


		if (atm_header_get_clp(src)) 
		{
			REPORT(0, (REPORT_ERROR, "ATM Cell: CLP ON\n"));
		}

		pti = atm_header_get_pti(src);
		if ((pti & ATM_PTI_OAM_CELL) == ATM_PTI_OAM_CELL) 
		{
		        REPORT(0, (REPORT_INFO, "ATM Cell: OAM PTI\n"));
			src += (ATM_CELL_TOTAL_SIZE + excess);
			len -= (ATM_CELL_TOTAL_SIZE + excess);
			pti = 0;
			continue;
		}

		if (pti == 2) pti = 0;
		else if (pti == 3) pti = 1;
		
		atm_cell_read(dst, src);

		src  += (ATM_CELL_TOTAL_SIZE + excess);
		len  -= (ATM_CELL_TOTAL_SIZE + excess);
		dst  += ATM_CELL_DATA_SIZE;		
		*pos += ATM_CELL_DATA_SIZE;

		if ((pti & ATM_USER_SDU) == ATM_USER_SDU)
		        break;
	}

	if (pti != 0 && len > 0) 
	{
		*nptr = src;
		*nlen = len;
	} 
	else 
	{
		*nptr = NULL;
		*nlen = 0;
	}

	return(pti);
}

#endif
