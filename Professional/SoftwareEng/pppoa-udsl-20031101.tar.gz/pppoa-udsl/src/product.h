/*
*  ALCATEL SpeedTouch USB modem utility : PPPoA implementation (3nd edition)
*  Copyright (C) 2001 Edouard Gomez
* 
*  This program is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public License
*  as published by the Free Software Foundation; either version 2
*  of the License, or (at your option) any later version.
*  
*  This program is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*  
*  You should have received a copy of the GNU General Public License
*  along with this program; if not, write to the Free Software
*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*
*  Author : Edouard Gomez (ed.gomez@free.fr)
*  Creation : 08/08/2001
*  Refactor : Matthew Gream (matthew.gream@pobox.com)
*
* $Id: product.h,v 1.5 2003/11/23 22:26:15 matt Exp $
*/

#ifndef _PRODUCT_H_
#define _PRODUCT_H_


/******************************************************************************
* Constants
******************************************************************************/

typedef struct {
	pusb_device_t device;
	char* name;
	int id_vendor, id_product;
	int ep_data, ep_code, ep_intr;
	int intf_active[4];
	void* data;
} product_t;

typedef int product_acquire_t;
#define PRODUCT_ACQ_DATA	0x01
#define PRODUCT_ACQ_INFO	0x02

/******************************************************************************
* Prototypes
******************************************************************************/

extern int product_usage(void);
extern int product_options_parse(int argc, char** argv, int* argi);
extern int product_options_check(void);

extern product_t* product_open_probe(void);
extern product_t* product_open_name(const char* name);
extern product_t* product_open_id(int vid, int pid);
extern int product_close(product_t* prod);

extern int product_acquire(product_t* prod, product_acquire_t acq, int* kernel);
extern int product_release(product_t* prod, product_acquire_t acq);

extern int product_setup_check(product_t* prod);
extern int product_setup_config(product_t* prod);
extern int product_setup_wait(product_t* prod);
extern int product_setup_report(product_t* prod);

extern int product_adsl_config(product_t* prod);
extern int product_adsl_verify(product_t* prod);
extern int product_adsl_connect(product_t* prod);
extern int product_adsl_connect_check(product_t* prod);
extern int product_adsl_connect_wait(product_t* prod);
extern int product_adsl_disconnect(product_t* prod);
extern int product_adsl_disconnect_check(product_t* prod);
extern int product_adsl_disconnect_wait(product_t* prod);
extern int product_adsl_report(product_t* prod);

extern int product_data_write(product_t* prod, unsigned char* buffer_ptr, int buffer_sz, int timeout);
extern int product_data_read(product_t* prod, unsigned char* buffer_ptr, int buffer_sz, int timeout);
extern int product_data_report(product_t* prod);

#endif

