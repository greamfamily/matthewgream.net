/*
*  ALCATEL SpeedTouch USB modem block extract utility
*  Copyright (C) 2001 Benoit PAPILLAULT
*  
*  This program is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public License
*  as published by the Free Software Foundation; either version 2
*  of the License, or (at your option) any later version.
*  
*  This program is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*  
*  You should have received a copy of the GNU General Public License
*  along with this program; if not, write to the Free Software
*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*
*  Author   : Benoit PAPILLAULT <benoit.papillault@free.fr>
*  Creation : 25/04/2001
*  Refactor : Matthew Gream (matthew.gream@pobox.com)
*
*  Searching for the block is done using the best match for a start and end 
*  patterns. This has been tested with windows 1.3 drivers, linux 1.3 drivers
*  & linux 1.3.2 drivers (using binary available at the Alcatel website:
*  http://www.alcateldsl.com/ ).
*
* $Id: extract.c,v 1.5 2003/11/23 22:26:15 matt Exp $
*/

#ifndef _EXTRACT_C_
#define _EXTRACT_C_


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>

#include "extract.h"
#include "report.h"
#include "crc.h"


/*****************************************************************************
* Prototypes
*****************************************************************************/

static unsigned char *load_file(const char * file, long * size);

static int search_match(const unsigned char *buffer, const long buffer_length,
	const unsigned char *patterns, const int pattern_length, const int nb_patterns);


/******************************************************************************
* Functions
******************************************************************************/

unsigned char *extract_block(const struct extract_block_config* config, const char* file, long* size)
{

	long start, final;
	unsigned char* buffer;
	unsigned int signature;


	if((buffer = load_file(file, &final)) == NULL)
		return(NULL);


	start = search_match(buffer, final, 
			config->start_tokens, config->start_length, 1);

	if(start < 0) {
		free(buffer);
		return(NULL);
	}


	*size  = search_match(buffer + start, final - start, 
			config->final_tokens , config->final_length, 1);

	if (*size < 0) {
		free(buffer);
		return(NULL);
	}


	*size += config->final_length;

	if (*size != config->length) {
		report(1, REPORT_ERROR, 
			"Extract [%s] for [%s] matched patterns, invalid size (got %08X != %08X)\n", 
				config->description, file, *size, config->length);
		free(buffer);
		return(NULL);
	}


	memcpy(buffer, buffer + start, *size);
	memset(buffer + *size, 0, final - *size);


	signature = aal5_calc_crc(buffer, *size, ~0);

	if (signature != config->signature) {
		report(1, REPORT_ERROR, 
			"Extract [%s] for [%s] matched patterns, invalid signature (got %08X != %08X)\n", 
				config->description, file, signature, config->signature);
		free(buffer);
		return(NULL);
	}


	return(buffer);

}


/*****************************************************************************
*	Local sub routines
*****************************************************************************/

static unsigned char * load_file(const char * file, long * size)
{

	struct stat statbuf;
	long len ;
	unsigned char * buf;
	int fd;


	if ((fd = open(file,O_RDONLY)) < 0) {
		report(0, REPORT_ERROR|REPORT_PERROR, "load_file: open %s\n", file);
		return(NULL);
	}


	if (fstat(fd,&statbuf) != 0) {
		report(0, REPORT_ERROR|REPORT_PERROR, "load_file: stat\n");
		return(NULL);
	}

	len = statbuf.st_size;


	if((buf = (unsigned char *)malloc(len)) == NULL) {
		report(0, REPORT_ERROR|REPORT_PERROR, "load_file: malloc\n");
		close(fd);
		return(NULL);
	}

	if (read(fd,buf,len) != len) {
		report(0, REPORT_ERROR|REPORT_PERROR, "load_file: read %s\n", file);
		free(buf);
		close(fd);
		return(NULL);
	}

	close(fd);

	*size = len;

	return(buf);

}

static int search_match(const unsigned char *buffer, const long buffer_length,
	const unsigned char *patterns, const int pattern_length, const int nb_patterns)
{

	long cur_offset;
	int pattern;

	int best_match = 0;
	int best_offset = -1;

	for(pattern=0; pattern<nb_patterns; pattern++) {

		for(cur_offset=0;cur_offset< (buffer_length - pattern_length + 1);cur_offset++) {

			int i;
			int cur_match;

			cur_match = 0;

			for(i=0;i<pattern_length;i++)
				if (buffer[cur_offset+i] == patterns[i])
					cur_match ++;

			if(cur_match > best_match) {

				best_offset = cur_offset;
				best_match  = cur_match;

				if (best_match == pattern_length)
					goto best_offset_found;

			}

		}

		patterns += pattern_length;

	}

best_offset_found:
		
	report(1, REPORT_INFO, "Best offset %08X with probability %3d%%\n",
			best_offset, (100*best_match)/pattern_length);

	return(best_offset);

}

#endif /* #ifndef _EXTRACT_C_ */
