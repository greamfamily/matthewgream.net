/*
*  ALCATEL SpeedTouch USB modem microcode upload & ADSL link UP utility
*  Copyright (C) 2001 Benoit PAPILLAULT
*  
*  This program is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public License
*  as published by the Free Software Foundation; either version 2
*  of the License, or (at your option) any later version.
*  
*  This program is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*  
*  You should have received a copy of the GNU General Public License
*  along with this program; if not, write to the Free Software
*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*
*  Author   : Benoit PAPILLAULT <benoit.papillault@free.fr>
*  Creation : 05/03/2001
*  Refactor : Matthew Gream (matthew.gream@pobox.com)
*  
*  This program uploads the microcode to the ALCATEL SpeedTouch USB modem.
*  It uses libusb (http://libusb.sourceforge.net/).
*  
*  The microcode can be uploaded only once. If the upload is correct,
*  ADSL led should be both green & red.
*  
*  If you try to download the microcode twice, you will get tons of
*  timeout errors.
*
*  $Id: report.c,v 1.5 2003/11/23 22:26:15 matt Exp $
*/

#ifndef _REPORT_C_
#define _REPORT_C_


#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <syslog.h>
#include <errno.h>
#include <stdarg.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>

#include "report.h"


/*****************************************************************************
* Variables
*****************************************************************************/

#define REPORT_MSG_LENGTH 256
#define REPORT_DMP_LENGTH 16

int report_level = 0;

static char* report_cfg_filename = NULL;
static FILE* report_cfg_filest = 0;
static int report_cfg_syslog = 1;
static int report_cfg_stdout = 1;


/******************************************************************************
* Prototypes
******************************************************************************/

static void report_term (void);


/******************************************************************************
* Definitions
******************************************************************************/

#define	PRINTABLECHAR(c) \
	((c >= ' ' && c < 0x7f) ? (c) : '.')
#define HEX2CHAR(x) \
	(((x) < 0x0a) ? ('0' + (x)) : ('a' - 0x0a + (x)))
#define HEX2CHAR_LO(x) \
	HEX2CHAR((x)&0x0f)
#define HEX2CHAR_HI(x) \
	HEX2CHAR(((x)>>4)&0x0f)


/*****************************************************************************
* Configuration
*****************************************************************************/

int report_usage(void)
{
	fprintf(stderr, "  -v [0-2]     : report verbose level\n");
	fprintf(stderr, "  -rf filename : report enable filename (default disabled)\n");
	fprintf(stderr, "  -rs          : report disable syslog (default enabled)\n");
	fprintf(stderr, "  -rq          : report enable quiet (no stdout/stderr) (default disable)\n");

	return(0);
}

int report_options_parse (int argc, char** argv, int* argi)
{
	if (strcmp(argv[*argi],"-v") == 0 && (*argi)+1<argc)
		report_level = atoi(argv[++(*argi)]);
	else if (strcmp(argv[*argi],"-rf")==0 && (*argi)+1<argc)
		report_cfg_filename = strdup(argv[++(*argi)]);
	else if (strcmp(argv[*argi],"-rs")==0)
		report_cfg_syslog = 0;
	else if (strcmp(argv[*argi],"-rq")==0)
		report_cfg_stdout = 0;
	else
		return(-1);

	return (0);
}

int report_options_check (void)
{
	if (report_level < 0) report_level = 0;
	if (report_level > 2) report_level = 2;

	return (0);
}

int report_level_set (int level)
{
	report_level = level;
	return report_options_check ();
}

/*****************************************************************************
* Initialisation
*****************************************************************************/

int report_init (const char* name, const int mode)
{
	if (report_cfg_syslog) 
	{
		if (mode == REPORT_DAEMON) 
		{
			openlog (name, LOG_PID, LOG_DAEMON);
		} 
		else 
		{
			openlog (name, LOG_PID, LOG_USER);
		}
	}

	if  (report_cfg_filename)
	{
		report_cfg_filest = fopen (report_cfg_filename, "a");
		setlinebuf (report_cfg_filest);
	}

	atexit (report_term);

	return (0);
}

void report_term (void)
{
	if (report_cfg_syslog) 
	{
		closelog ();
	}

	if (report_cfg_filename)
	{
		if (report_cfg_filest)
			fclose (report_cfg_filest);
		free (report_cfg_filename);
	}
}


/*****************************************************************************
* Operation
*****************************************************************************/

static char* format_dump (const unsigned char *buf, const int len)
{
	int i, j;
	char *msg = NULL;
	char *ptr = NULL;
	int siz;
	int spc = ((REPORT_DMP_LENGTH + 1) * 3) + (REPORT_DMP_LENGTH) + 1 + 1;

	if (buf == NULL || len == 0)
		return NULL;

	for (i = 0; i < len; i += REPORT_DMP_LENGTH) 
	{
		siz = (msg == NULL) ? 0 : strlen(msg);
		if ((ptr = (char *)realloc ((void *)msg, siz + spc)) == NULL)
			break;
		msg = ptr;
		ptr = &msg[siz];

		for (j = i; j < len && j < (i + REPORT_DMP_LENGTH); j++) 
		{
			*ptr++ = HEX2CHAR_HI(buf[j]);
			*ptr++ = HEX2CHAR_LO(buf[j]);
			*ptr++ = ' ';
		}

		for (; j < i + REPORT_DMP_LENGTH; j++) 
		{
			*ptr++ = ' ';
			*ptr++ = ' ';
			*ptr++ = ' ';
		}

		for (j = i; j < len && j < i + REPORT_DMP_LENGTH; j++) 
		{
			*ptr++ = PRINTABLECHAR(buf[j]);
		}

		*ptr++ = '\n';
		*ptr = '\0';
	}

	return msg;
}

static void report_args (const unsigned int flags, const char* format, va_list ap)
{
	char message [REPORT_MSG_LENGTH];
	char* buffer = NULL;

	if (flags & REPORT_DUMP) 
	{
		const unsigned char* buf = va_arg (ap, unsigned char*);
		const int len = va_arg (ap, int);
		buffer = format_dump (buf, len);
	}

	vsnprintf (message, sizeof (message), format, ap);

	if (flags & REPORT_PERROR) 
	{
		int off = strlen (message); if (off > 0 && message [off - 1] == '\n') off--;
		snprintf (&message [off], sizeof (message) - off, " [errno: %s]\n", strerror (errno));
	}

	if (report_cfg_syslog) 
	{
		if (flags & REPORT_ERROR)
			syslog(LOG_ERR, message);
		else if (flags & REPORT_INFO)
			syslog (LOG_INFO, message);
		else if (flags & REPORT_DEBUG)
			syslog (LOG_DEBUG, message);
		if (flags & REPORT_DUMP && buffer != NULL) 
		{
			char* buffer_ptr_s = buffer;
			while (*buffer_ptr_s != '\0') 
			{
				char* buffer_ptr_e = buffer_ptr_s; char buffer_ptr_c;
				while (!(*buffer_ptr_e == '\0' || *buffer_ptr_e == '\n'))
					buffer_ptr_e++;
				buffer_ptr_c = *buffer_ptr_e;
				*buffer_ptr_e = '\0';
				syslog (LOG_DEBUG, buffer_ptr_s);
				*buffer_ptr_e = buffer_ptr_c;
				if (buffer_ptr_c != '\0')
					buffer_ptr_e++;
				buffer_ptr_s = buffer_ptr_e;
			}
		}
	}

	if (report_cfg_filest) 
	{
		time_t timestamp_raw = time (0);
		char timestamp_str [32];
		ctime_r (&timestamp_raw, timestamp_str);
		timestamp_str [26-2] = '\0';

		fprintf (report_cfg_filest, "[%s]: %s", timestamp_str, message);
		if (flags & REPORT_DUMP && buffer != NULL) 
		{
			char* buffer_ptr_s = buffer;
			while (*buffer_ptr_s != '\0') 
			{
				char* buffer_ptr_e = buffer_ptr_s; char buffer_ptr_c;
				while (!(*buffer_ptr_e == '\0' || *buffer_ptr_e == '\n'))
					buffer_ptr_e++;
				buffer_ptr_c = *buffer_ptr_e;
				*buffer_ptr_e = '\0';
				fprintf (report_cfg_filest, "[%s]: %s\n", timestamp_str, buffer_ptr_s);
				*buffer_ptr_e = buffer_ptr_c;
				if (buffer_ptr_c != '\0')
					buffer_ptr_e++;
				buffer_ptr_s = buffer_ptr_e;
			}
		}
	}

	if (report_cfg_stdout) 
	{
		if (flags & REPORT_ERROR)
			fprintf (stderr, "%s", message);
		else 
			fprintf (stdout, "%s", message);	
#ifdef DEBUG
		if (flags & REPORT_DUMP && buffer != NULL)
			fprintf (stdout, "%s", buffer);
#endif
	}

	if (buffer != NULL)
		free (buffer);
}

void report (const int minlevel, const unsigned int flags, const char *format, ...)
{
	if (report_level >= minlevel) 
	{
		va_list ap;
		va_start (ap, format);
		report_args (flags, format, ap);
		va_end (ap);
	}
}

void report_auto (const unsigned int flags, const char *format, ...)
{
	{
		va_list ap;
		va_start (ap, format);
		report_args (flags, format, ap);
		va_end (ap);
	}
}

#endif /* _REPORT_C_*/
