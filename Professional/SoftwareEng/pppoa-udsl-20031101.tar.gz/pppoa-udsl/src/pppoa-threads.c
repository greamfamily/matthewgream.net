/*
 *  ALCATEL SpeedTouch USB modem utility : PPPoA implementation (3nd edition)
 *  Copyright (C) 2001 Benoit Papillault
 * 
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 *  Author : Edouard Gomez (ed.gomez@free.fr)
 *  Creation : 08/08/2001
 *  Refactor : Matthew Gream (matthew.gream@pobox.com)
 *
 *  This program is designed to work under pppd, with the option "pty". It can
 *  also be used as a daemon to create a tap device that rp-pppoe can use as a
 *  standard ethernet device (this is the ethernet bridging mode rfc 1483).
 *
 *  $Id: pppoa-threads.c,v 1.1 2003/11/23 22:26:15 matt Exp $
 */

#ifndef _PPPOA_THREADS_C_
#define _PPPOA_THREADS C_

extern int cfg_atm_vci, cfg_atm_vpi;
extern int pppoa_process_fdin, pppoa_process_fdout;
extern product_t* pppoa_process_prod;
static int pppoa_process_error(void);
#define PIPE_NAME_FORMAT "/var/run/pppoa%d.pipe"
extern int cfg_command_pipe;




/******************************************************************************
 * Thread - USB write
 ******************************************************************************/

static void *pppoa_thread_usb_write_enter (void* arg)
{
	unsigned char *buffer_data;
	unsigned char *buffer_start_ptr;
	unsigned char *buffer_frame_ptr;
	int buffer_frame_sz;
	int buffer_max;


	if ((buffer_data = malloc (ATM_CELL_BUFFER_SIZE)) == NULL)
		goto local_end;

	if (cfg_bridging) 
	{
		buffer_start_ptr = buffer_data + BRIDGING1483_HEADER;
		buffer_frame_ptr = buffer_data;
		buffer_max = ATM_CELL_BUFFER_SIZE - BRIDGING1483_HEADER;
	} 
	else 
	{
		buffer_start_ptr = buffer_data;
		buffer_frame_ptr = buffer_data + HDLC_HEADER_SIZE;
		buffer_max = ATM_CELL_BUFFER_SIZE - HDLC_HEADER_SIZE;
	}


	while (1) 
	{
		thread_test ();

		buffer_frame_sz = ppp_read (pppoa_process_fdin, buffer_start_ptr, buffer_max);
		if (buffer_frame_sz <= 0)
			continue;

		if (cfg_bridging) 
		{
			buffer_frame_ptr[0]=0xaa;
			buffer_frame_ptr[1]=0xaa;
			buffer_frame_ptr[2]=0x03;
			buffer_frame_ptr[3]=0x00;
			buffer_frame_ptr[4]=0x80;
			buffer_frame_ptr[5]=0xc2;
			buffer_frame_ptr[6]=0x00;
			buffer_frame_ptr[7]=0x07;
			buffer_frame_ptr[8]=0x00;
			buffer_frame_ptr[9]=0x00;
			buffer_frame_sz += BRIDGING1483_HEADER;
		} 
		else 
		{
			buffer_frame_sz -= HDLC_HEADER_SIZE;
		}

		REPORT (1, (REPORT_INFO, "ppp_to_usb: PPP read from PTY (%d bytes)\n",
				buffer_frame_sz));
		REPORT (2, (REPORT_DEBUG|REPORT_DUMP, "ppp_to_usb: PPP frame from PTY (%d bytes)\n", 
				buffer_frame_ptr, buffer_frame_sz, buffer_frame_sz));

		buffer_frame_sz = aal5_frame_enc (buffer_frame_ptr, buffer_frame_ptr, buffer_frame_sz);
		if (buffer_frame_sz <= 0)
			continue;

		buffer_frame_sz = aal5_frame_to_atm_cells (buffer_frame_ptr, buffer_frame_ptr,
				buffer_frame_sz, ATM_CELL_EXCESS_SIZE, cfg_atm_vpi, cfg_atm_vci);
		if (buffer_frame_sz <= 0)
			continue;

		REPORT (1, (REPORT_INFO, "ppp_to_usb: ATM write to USB (%d bytes)\n",
				buffer_frame_sz));
		REPORT (2, (REPORT_DEBUG|REPORT_DUMP, "ppp_to_usb: ATM encode for USB (%d bytes)\n", 
				buffer_frame_ptr, buffer_frame_sz, buffer_frame_sz));

		usb_write (pppoa_process_prod, buffer_frame_ptr, buffer_frame_sz,
				DATA_TIMEOUT, DATA_RETRIES);
	}

	free (buffer_data);

local_end:
	pppoa_process_error ();

	return (0);
}


/******************************************************************************
 * Thread - USB read
 ******************************************************************************/

static void *pppoa_thread_usb_read_enter (void* arg)
{
	unsigned char *buffer_temp;
	unsigned char *buffer_data;
	unsigned char *buffer_frame_ptr;
	int buffer_frame_sz = 0;
	unsigned char *buffer_start_ptr;
	unsigned char* buffer_ptr;
	int buffer_sz;
	int buffer_max;


	if ((buffer_data = malloc (AAL5_FRAME_BUFFER_SIZE)) == NULL)
		goto local_end;
	if ((buffer_temp = malloc (ATM_CELL_RDBUF_SIZE)) == NULL)
		goto local_end;

	if (cfg_bridging) 
	{
		buffer_start_ptr = buffer_data + BRIDGING1483_HEADER;
		buffer_frame_ptr = buffer_data;
	} 
	else 
	{
		buffer_start_ptr = buffer_data;
		buffer_start_ptr[0] = PPP_FRAME_ADDR;
		buffer_start_ptr[1] = PPP_FRAME_CTRL;
		buffer_frame_ptr = buffer_start_ptr + HDLC_HEADER_SIZE;
	}
	buffer_max = ATM_CELL_RDBUF_SIZE;


	while (1) 
	{
		thread_test ();

		buffer_ptr = buffer_temp;
		buffer_sz = usb_read (pppoa_process_prod, buffer_ptr, buffer_max, DATA_TIMEOUT, DATA_RETRIES);
		if (buffer_sz <= 0)
			continue;

		REPORT (1, (REPORT_INFO, "usb_to_ppp: ATM read from USB (%d bytes)\n",
				buffer_sz));
		REPORT (2, (REPORT_DEBUG|REPORT_DUMP, "usb_to_ppp: ATM cell from USB (%d bytes)\n", 
				buffer_ptr, buffer_sz, buffer_sz));

		while (buffer_ptr) 
		{
			int pti = aal5_frame_from_atm_cells (buffer_frame_ptr, buffer_ptr, buffer_sz,
						ATM_CELL_EXCESS_SIZE, cfg_atm_vpi, cfg_atm_vci, &buffer_frame_sz,
						&buffer_ptr, &buffer_sz);
			if (pti < 0) 
			{
				report (0, REPORT_ERROR, "usb_to_ppp: buffer overflow, too many cells for aal5 frame\n");
			}
			if (pti > 0) 
			{
				buffer_frame_sz = aal5_frame_dec (buffer_frame_ptr, buffer_frame_ptr, buffer_frame_sz);
				if (buffer_frame_sz <= 0) 
				{
					report (0, REPORT_ERROR, "usb_to_ppp: ATM decode AAL5 failed (CRC error?)\n");
				} 
				else 
				{
					REPORT (2, (REPORT_DEBUG|REPORT_DUMP, "usb_to_ppp: ATM cell decode AAL5 (%d bytes)\n",
							buffer_frame_ptr, buffer_frame_sz, buffer_frame_sz));
					REPORT (1, (REPORT_INFO, "usb_to_ppp: PPP write to PTY (%d bytes)\n", 
							buffer_frame_sz+((cfg_bridging) ? -BRIDGING1483_HEADER : HDLC_HEADER_SIZE)));

					ppp_write (pppoa_process_fdout, buffer_start_ptr,
							buffer_frame_sz + ((cfg_bridging) ? -BRIDGING1483_HEADER : HDLC_HEADER_SIZE),
							DATA_TIMEOUT, DATA_RETRIES);
				}
				buffer_frame_sz = 0;
			}
			if (pti == 0)
			{
				/* more data required */
			}
		}
	}

	free (buffer_data);
	free (buffer_temp);

local_end:
	pppoa_process_error ();

	return (0);
}


/******************************************************************************
 * Thread - USB info
 ******************************************************************************/

static void *pppoa_thread_usb_info_enter (void* arg)
{
	while (1) 
	{
		thread_test ();

		if (cfg_status_period < 1) 
		{
			usleep (30 * 1000000);
			continue;
		}

		usleep (cfg_status_period * 60 * 1000000);

		/*if (pppoa_device_acquire (pppoa_process_prod, PRODUCT_ACQ_INFO) < 0)
			continue;*/
		product_adsl_report (pppoa_process_prod);
		product_data_report (pppoa_process_prod);
		/*if (pppoa_device_release (pppoa_process_prod, PRODUCT_ACQ_INFO) < 0)
			;*/
	}

/*local_end:*/
	pppoa_process_error ();

	return (0);
}


/******************************************************************************
 * Thread - Control
 ******************************************************************************/

static int pppoa_thread_user_pipe_test (void)
{
	if (!cfg_command_pipe)
		return (-1);

	return (0);
}

static void pppoa_thread_user_pipe_exit (void *arg) 
{
	thread_entry* t = (void *) arg;

	char pipe_name [128];
	int pipe_fd = *((int *) t->f_data);

	if (pipe_fd != -1)
		close (pipe_fd);

	snprintf (pipe_name, sizeof (pipe_name) - 1, PIPE_NAME_FORMAT, cfg_lock_id);
	unlink (pipe_name);
}
		
static void *pppoa_thread_user_pipe_enter (void *arg)
{
	int pipe_fd;
	fd_set pipe_fdset;
	char pipe_name [128];

	snprintf (pipe_name, sizeof (pipe_name) - 1, PIPE_NAME_FORMAT, cfg_lock_id);
	if (mkfifo (pipe_name, 0600) != 0) 
	{
		report (0, REPORT_ERROR|REPORT_PERROR, "user_pipe: create failed, pipe disabled\n");
		goto local_end;
	}
	else 
	{
		report (1, REPORT_INFO, "user_pipoe: create succeeded\n");
		if ((pipe_fd = open (pipe_name, O_RDWR)) < 0) 
		{
			report (0, REPORT_ERROR|REPORT_PERROR, "user_pipe: open failed, pipe disabled\n");
			goto local_end;
		}
	}

	FD_ZERO (&pipe_fdset);
	FD_SET (pipe_fd, &pipe_fdset);

	while (1) 
	{
		char command_data [128];
		int command_len = 0;
		char* command_arg;

		thread_test ();

		select (pipe_fd + 1, NULL, &pipe_fdset, NULL, NULL);
		while ((command_len = read (pipe_fd, command_data, sizeof (command_data))) < 0)
		{
			report (0, REPORT_ERROR|REPORT_PERROR, "user_pipe: read error");
		}

		if (command_len == 0 || command_len > sizeof (command_data))
			continue;
		for (command_arg = command_data; command_len > 0 && *command_arg != '='; command_len--, command_arg++)
			;
		*command_arg++ = '\0';

		report (1, REPORT_INFO, "user_pipe: %s '%s'\n", command_data, command_arg);

		if (strncmp (command_data, "help", 4) == 0)
		{
		}
		else if (strncmp (command_data, "report", 7) == 0)
		{
			int level = atoi (command_arg); if (level < 0) level = -level;
			report_level_set (level);
		}
		else if (strncmp (command_data, "stop", 4) == 0)
		{
			if (strncmp (command_arg, "pipe", 4) == 0)
			{
				goto local_end;
			}
			else if (strncmp (command_arg, "info", 4) == 0)
			{
				/* not supported */
			}
			else if (strncmp (command_arg, "pppoa", 5) == 0)
			{
				pppoa_process_error();
				goto local_end;
			}
			else
			{
				report (0, REPORT_ERROR, "user_pipe: stop '%s' -- unknown request\n", command_arg);
			}
		}
		else
		{
			report (0, REPORT_ERROR, "user_pipe: %s '%s' -- unknown request\n", command_data, command_arg);
		}
	}

local_end:

	return (0);
}


/******************************************************************************
 * Thread - definition
 ******************************************************************************/

static thread_entry pppoa_thread_list [] =
{
	{
		"usb to ppp", 
		0,
		0, 0,
		0, pppoa_thread_usb_read_enter, 0,
		0
	},
	{
		"ppp to usb",
		0,
		0, 0,
		0, pppoa_thread_usb_write_enter, 0,
		0
	},
	{
		"usb info",
		0,
		0, 0,
		0, pppoa_thread_usb_info_enter, 0,
		0
	},
	{
		"user pipe",
		0,
		0, 0,
		pppoa_thread_user_pipe_test, pppoa_thread_user_pipe_enter, pppoa_thread_user_pipe_exit,
		0
	}
};
static const int pppoa_thread_size = sizeof (pppoa_thread_list) / sizeof (thread_entry);

int pppoa_thread_start (void)
{
	int i;
	for (i = 0; i < pppoa_thread_size; ++i) {
		if (thread_start (&pppoa_thread_list[i]) < 0)
			return (-1);
	}
	return (0);
}

int pppoa_thread_stop (void)
{
	int i;
	for (i = 0; i < pppoa_thread_size; ++i) {
		if (thread_stop (&pppoa_thread_list[i]) < 0)
			;
	}
	return (0);
}

#endif
