/*
*  ALCATEL SpeedTouch USB : Little atm library
*  Copyright (C) 2001 Benoit Papillault
* 
*  This program is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public License
*  as published by the Free Software Foundation; either version 2
*  of the License, or (at your option) any later version.
*  
*  This program is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*  
*  You should have received a copy of the GNU General Public License
*  along with this program; if not, write to the Free Software
*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*
*  Author : Edouard Gomez (ed.gomez@free.fr)
*  Creation : 14/08/2001
*  Refactor : Matthew Gream (matthew.gream@pobox.com)
*
* $Id: atm.h,v 1.5 2003/11/23 22:26:15 matt Exp $
*/

#ifndef _ATM_H_
#define _ATM_H_


/******************************************************************************
* Constants
******************************************************************************/

#define ATM_CELL_HEADER_SIZE 	(5)
#define ATM_CELL_DATA_SIZE   	(48)
#define ATM_CELL_TOTAL_SIZE  	(ATM_CELL_HEADER_SIZE + ATM_CELL_DATA_SIZE)
#define ATM_CELL_MAX_SIZE    	(64*1024)

#define AAL5_FRAME_HEADER_SIZE	(8)
#define AAL5_FRAME_DATA_SIZE	(64*1024)
#define AAL5_FRAME_MAX_SIZE 	(AAL5_FRAME_HEADER_SIZE + AAL5_FRAME_DATA_SIZE)


/******************************************************************************
* Prototypes
******************************************************************************/

extern unsigned int aal5_frame_enc (unsigned char *frame,
		const unsigned char *data, const unsigned int length);
extern unsigned int aal5_frame_dec (unsigned char *data,
		const unsigned char *frame, const unsigned int length);

extern int aal5_frame_to_atm_cells (unsigned char *atm_cells, 
		const unsigned char *aal5_frame, const int length, const int excess,
		const int vpi, const int vci);
extern int aal5_frame_from_atm_cells (unsigned char *aal5_frame, 
		unsigned char *atm_cells, const int length, const int excess,
		const int vpi, const int vci, 
		int *pos, unsigned char **nptr, int *nlen);


#endif
