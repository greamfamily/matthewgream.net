/*
 *  ALCATEL SpeedTouch USB modem utility : PPPoA implementation (3nd edition)
 *  Copyright (C) 2001 Benoit Papillault
 * 
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 *  Author : Edouard Gomez (ed.gomez@free.fr)
 *  Creation : 08/08/2001
 *  Refactor : Matthew Gream (matthew.gream@pobox.com)
 *
 *  This program is designed to work under pppd, with the option "pty". It can
 *  also be used as a daemon to create a tap device that rp-pppoe can use as a
 *  standard ethernet device (this is the ethernet bridging mode rfc 1483).
 *
 *  $Id: pppoa.c,v 1.4 2003/11/23 22:26:15 matt Exp $
 */

#ifndef _PPPOA_C_
#define _PPPOA_C_

#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <pwd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <semaphore.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <signal.h>
#include <sys/stat.h>
#include <assert.h>
#include <errno.h>

#if defined(__linux__)
#include <linux/if_tun.h>
#include <linux/if.h>
#endif


#include "pusb.h"
#include "product.h"
#include "report.h"
#include "atm.h"
#include "crc.h"


/******************************************************************************
* Prototypes
******************************************************************************/

static int pppoa_report(void);
static int pppoa_process_setup(product_t* prod, int fdin, int fdout);
static int pppoa_process_start(void);
static int pppoa_process_exec(void);
static int pppoa_process_stop(void);
static product_t* pppoa_device_open(const char* name);
static int pppoa_device_close(product_t* prod);
static int pppoa_device_acquire(product_t* prod, product_acquire_t acq);
static int pppoa_device_release(product_t* prod, product_acquire_t acq);
static int pppoa_setup_options(int argc, char** argv);
static int pppoa_setup_program(void);
static int pppoa_setup_bridging(void);
static int pppoa_lock_eradicate();
static int pppoa_lock_acquire(int id);
static void pppoa_lock_release(void);
static int pppoa_usage(void);
static int pppoa_options_parse(int argc, char** argv);
static int pppoa_options_check(void);
static int pppoa_general_usage(void);
static int pppoa_general_options_parse(int argc, char** argv, int* argi);
static int pppoa_general_options_check(void);


/******************************************************************************
* Variables
******************************************************************************/

static int cfg_command_pipe = 0;
static int cfg_atm_vpi = -1;
static int cfg_atm_vci = -1;
static char* cfg_device_name = NULL;
static int cfg_lock_id = 0;
static int cfg_lock_clean = 0;
static int cfg_syncHDLC = 1;
static int cfg_bridging = 0;
static int cfg_status_period = 15; /* 15 minutes */
int cfg_signal_kernel = 0;

int cfg_prio_buff = 128*1024;
int cfg_prio_proc = -15;

static int pppoa_general_usage(void)
{

	fprintf(stderr, "Customisation:\n");
	fprintf(stderr, "  -vpi n       : set ATM VPI (must be supplied)\n");
	fprintf(stderr, "  -vci n       : set ATM VCI (must be supplied)\n");
	fprintf(stderr, "  -d device    : defines the device to use\n");
	fprintf(stderr, "  -i n         : the device id for the lock\n");
	fprintf(stderr, "  -c           : clean out any existing locks\n");
	fprintf(stderr, "  -a           : enable Synchronous HDLC\n");
	fprintf(stderr, "  -b           : enable PPPOE Bridging\n");
	fprintf(stderr, "  -s mins      : enable status reporting every mins\n");
	fprintf(stderr, "  -p           : enable command pipe\n");

	return(0);

}

static int pppoa_general_options_parse(int argc, char** argv, int* argi)
{

	if (strcmp(argv[*argi],"-vpi")==0 && (*argi)+1<argc)
		cfg_atm_vpi = atol(argv[++(*argi)]);
	else if (strcmp(argv[*argi],"-vci")==0 && (*argi)+1<argc)
		cfg_atm_vci = atol(argv[++(*argi)]);
	else if(strcmp(argv[*argi], "-d") == 0 && (*argi)+1<argc)
		cfg_device_name = argv[++(*argi)];
	else if(strcmp(argv[*argi], "-i") == 0 && (*argi)+1<argc)
		cfg_lock_id = atol(argv[++(*argi)]);
	else if(strcmp(argv[*argi], "-s") == 0 && (*argi)+1<argc)
		cfg_status_period = atol(argv[++(*argi)]);
	else if (strcmp(argv[*argi], "-c")==0)
		cfg_lock_clean = 1;
	else if (strcmp(argv[*argi], "-p")==0)
		cfg_command_pipe = 1;
	else if (strcmp(argv[*argi], "-a")==0)
		cfg_syncHDLC = 1;
	else if (strcmp(argv[*argi], "-b")==0)
		cfg_bridging = 1;
	else
		return(-1);

	return(0);

}

static int pppoa_general_options_check(void)
{
	if (cfg_atm_vpi == -1 || cfg_atm_vci == -1) 
		return (-1);

	if (cfg_bridging)
		cfg_syncHDLC = 1;

	return(0);

}


#include "pppoa-funcs.c"
#include "pppoa-threads.c"


/******************************************************************************
* Main
******************************************************************************/

int main(int argc, char **argv)
{
	product_t* prod = NULL;


	/*
	 * Initialisation
	 */

	if (pppoa_setup_options(argc, argv) < 0)
		return(-1);
	if (pppoa_setup_program() < 0)
		return(-1);
	if (pppoa_setup_bridging() < 0)
		return(-1);


	/*
	 * Information
	 */

	if (pppoa_report() < 0)
		return(-1);


	/*
	 * Operation
	 */

	if (pppoa_lock_acquire(cfg_lock_id) < 0)
		return(-1);

	if ((prod = pppoa_device_open(cfg_device_name)) == NULL)
		return(-1);
	if (pppoa_device_acquire(prod, PRODUCT_ACQ_DATA|PRODUCT_ACQ_INFO) < 0)
		return(-1);


	if (pppoa_process_setup(prod, STDIN_FILENO, STDOUT_FILENO) < 0)
		return(-1);
	if (pppoa_process_start() < 0)
		return(-1);
	if (pppoa_process_exec() < 0)
		return(-1);
	if (pppoa_process_stop() < 0)
		return(-1);


	if (pppoa_device_release(prod, PRODUCT_ACQ_DATA|PRODUCT_ACQ_INFO) < 0)
		return(-1);
	if (pppoa_device_close(prod) < 0)
		return(-1);


	return(0);
}


/*****************************************************************************
*	Information
*****************************************************************************/

static int pppoa_report(void)
{
	report(2, REPORT_INFO, "ATM: VPI %d, VCI %d\n", cfg_atm_vpi, cfg_atm_vci);
	report(2, REPORT_INFO, "Device: ID %d, %s clean\n", cfg_lock_id, (cfg_lock_clean ? "will" : "wont"));
	report(2, REPORT_INFO, "Mode: %s HDLC, \n", (cfg_syncHDLC)?"Sync":"ASync",(cfg_bridging)?"Bridged PPPoE":"PPPoA");
	report(2, REPORT_INFO, "Command: %sabled\n", (cfg_command_pipe)?"en":"dis");

	return(0);
}


/*****************************************************************************
*	Process
*****************************************************************************/

static sem_t pppoa_process_sem;
static int pppoa_process_fdin = -1;
static int pppoa_process_fdout = -1;
static product_t* pppoa_process_prod = NULL;


static int pppoa_process_setup(product_t* prod, int fdin, int fdout)
{

	/* 
	 * Configure
	 */
	pppoa_process_fdin = fdin;
	pppoa_process_fdout = fdout;
	pppoa_process_prod = prod;


	/*
	 * Increase send and recv buffer sizes
	 */
#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
	{
		int sbuf;
		socklen_t slen = sizeof(sbuf);

		if (getsockopt(pppoa_process_fdin, SOL_SOCKET, SO_SNDBUF, &sbuf, &slen) == 0) {
			report(2, REPORT_DEBUG, "setsockopt(SO_SNDBUF): from %d to %d\n", sbuf, cfg_prio_buff);
			sbuf = cfg_prio_buff;
			if (setsockopt(pppoa_process_fdin, SOL_SOCKET, SO_SNDBUF, &sbuf, slen) < 0)
				report(0, REPORT_ERROR, "setsockopt(SO_SNDBUF) failed (may have performance impact)\n");
		}

		if (getsockopt(pppoa_process_fdin, SOL_SOCKET, SO_RCVBUF, &sbuf, &slen) == 0) {
			report(2, REPORT_DEBUG, "setsockopt(SO_RCVBUF): from %d to %d\n", sbuf, cfg_prio_buff);
			sbuf = cfg_prio_buff;
			if(setsockopt(pppoa_process_fdin, SOL_SOCKET, SO_RCVBUF, &sbuf, slen) < 0)
				report(0, REPORT_ERROR, "setsockopt(SO_RCVBUF) failed (may have performance impact)\n");
		}
	}
#endif

	/*
	 * Install HDLC line discipline if required
	 */
	if(isatty(pppoa_process_fdin) && cfg_syncHDLC) {
#ifdef N_HDLC
		int disc = N_HDLC;

		if(ioctl(pppoa_process_fdin, TIOCSETD, &disc) < 0) {
			report(0, REPORT_ERROR, "ioctl(TIOCSETD) failed for N_HDLC\n");
			return(-1);
		}
		report(2, REPORT_DEBUG, "Enabled N_HDLC on STDIN\n");
#elif defined TTYDISC
		int disc = TTYDISC;

		if(ioctl(pppoa_process_fdin, TIOCSETD, &disc) < 0) {
			report(0, REPORT_ERROR, "ioctl(TIOCSETD) failed for TTYDISC\n");
			return(-1);
		}
		report(2, REPORT_DEBUG, "Enabled TTYDISC on STDIN\n");
#endif
	}

	return(0);
}

static void pppoa_process_sighandler_term(int signo)
{
	report(0, REPORT_INFO, "pppoa_process - signal %d -- terminating\n", signo);

	sem_post(&pppoa_process_sem);

#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
	signal(SIGHUP , SIG_DFL);
#elif defined(__linux__)
	signal(SIGTERM, SIG_DFL);
#endif
	signal(SIGUSR2, SIG_DFL);
}

static void pppoa_process_sighandler_usr2(int signo)
{
	int cfg_command_pipe_OLD = cfg_command_pipe;

	report(0, REPORT_INFO, "pppoa_process - signal %d -- enabling pipe\n", signo);

	cfg_command_pipe = 1;
	pppoa_thread_start();
	cfg_command_pipe = cfg_command_pipe_OLD;
}

static int pppoa_process_start(void)
{

	report(0, REPORT_ERROR, "pppoa_process - starting\n");

    sem_init(&pppoa_process_sem, 0, 0);

	if(setpriority(PRIO_PROCESS, getpid(), cfg_prio_proc) < 0)
		report(1, REPORT_INFO, "setpriority(%d) failed (may have performance impact)\n", cfg_prio_proc);
	setproctitle("%d: %s", cfg_lock_id, "monitor");

	if (pppoa_thread_start() < 0)
		return(-1);

#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
	signal(SIGHUP , pppoa_process_sighandler_term);
#elif defined(__linux__)
	signal(SIGTERM, pppoa_process_sighandler_term);
#endif
	signal(SIGUSR2, pppoa_process_sighandler_usr2);

	return(0);
}

static int pppoa_process_exec(void)
{
	report(0, REPORT_ERROR, "pppoa_process - waiting\n");

	sem_wait(&pppoa_process_sem);

	return(0);
}

static int pppoa_process_error(void)
{
	sem_post(&pppoa_process_sem);

#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
	signal(SIGHUP , SIG_DFL);
#elif defined(__linux__)
	signal(SIGTERM, SIG_DFL);
#endif
	signal(SIGUSR2, SIG_DFL);

	return(0);
}

static int pppoa_process_stop(void)
{
	report(0, REPORT_ERROR, "pppoa_process - stopping\n");

	pppoa_thread_stop();

	sem_destroy(&pppoa_process_sem);

	return(0);
}


/*****************************************************************************
*	Device
*****************************************************************************/

static product_t* pppoa_device_open(const char* device)
{

	product_t* prod = NULL;

	/* 
	 * Open the device explicitly or via probe
	 */

	if (device == NULL) {

		prod = product_open_probe();

		if (prod == NULL) {
			report(0, REPORT_ERROR, "USB DSL modem: Not found (probe)\n");
			return(NULL);
		}

	} else {

		prod = product_open_name(device);

		if (prod == NULL) {
			report(0, REPORT_ERROR, "USB DSL modem: Not found (%s)\n", device);
			return(NULL);
		}

	}

	report(0, REPORT_INFO, "USB DSL modem: Found '%s' (ID:%04X/%04X)\n",
		prod->name, prod->id_vendor, prod->id_product);

	return prod;

}

static int pppoa_device_close(product_t* prod)
{

	/* 
	 * Close the device
	 */

	return product_close(prod);

}

static int pppoa_device_acquire(product_t* prod, product_acquire_t acq)
{
	int signal_kernel = 0; /* we're the driver, there can't be a kernel one ... */

	if (product_acquire(prod, acq, &signal_kernel) < 0) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed acquire\n");

		return(-1);
	}

	return(0);

}

static int pppoa_device_release(product_t* prod, product_acquire_t acq)
{

	if (product_release(prod, acq) < 0) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed release\n");

		return(-1);

	}

	return(0);

}


/*****************************************************************************
*	Setup
*****************************************************************************/

static int pppoa_setup_options(int argc, char** argv)
{

	if (pppoa_options_parse(argc, argv) < 0)
		pppoa_usage();

	if (pppoa_options_check() < 0)
		pppoa_usage();

	return(0);

}

static int pppoa_setup_program(void)
{

	char *user;
	
	if(geteuid() != 0) {
		fprintf(stderr, "pppoa must be run with root privileges\n");
		return(-1);
	}

	umask(0177);

	if((user = getlogin())== NULL) {

		struct passwd *pw = getpwuid(getuid());

		if(pw != NULL && pw->pw_name != NULL)
			user = pw->pw_name;
		else
			user = "Unknown";
	}

	if (report_init("pppoa", REPORT_DAEMON) < 0) {
		fprintf(stderr, "pppoa could not start reporting\n");
		return(-1);
	}

	report(0, REPORT_INFO, "pppoa V%s started by %s uid %u\n", 
		VERSION, user, getuid());

	return(0);

}

static int pppoa_setup_bridging(void)
{
	if(cfg_bridging) 
	{
		if((pppoa_process_fdin = pppoa_process_fdout = tap_open()) == -1) {
			report(0, REPORT_ERROR, "Error opening tun/tap device. Quitting\n");
			return(-1);
		}
			
		close(STDIN_FILENO);
		close(STDOUT_FILENO);
		close(STDERR_FILENO);

		switch(fork()) {
		case -1:
			report(0, REPORT_ERROR, "fork() failed. Quitting\n");
			return(-1);
		case 0:
			break;
		default:
			exit(0);
		}
	}

	return(0);
}


/*****************************************************************************
*	Locking
*****************************************************************************/

static int pppoa_lock_eradicate(int id)
{
	int pid;

	report(1, REPORT_DEBUG, "Lock: eradicate\n");

	if ((pid = pppoa_lock_file_obtain(id)) > 0)
	{
		if (pid != getpid() && kill(pid, 0) == 0) 
		{
			report(0, REPORT_INFO, "Lock: previous instance is active, terminating (pid: %d)\n", pid);
#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
			kill(pid, SIGHUP);
#elif defined(__linux__)
			kill(pid, SIGTERM);
#endif
			while (kill(pid, 0) == 0) {
				report(2, REPORT_INFO, "Lock: previous instance is active, waiting\n");
				sleep(1);
			}
			report(2, REPORT_INFO, "Lock: previous instance is not active\n");
		}

		pppoa_lock_file_destroy();
	}

	pppoa_lock_sem_release();
	pppoa_lock_sem_destroy();

	return(0);

}

static int pppoa_lock_acquire(int id)
{

	report(1, REPORT_DEBUG, "Lock: acquire\n");

	if (pppoa_lock_sem_obtain(id) >= 0) {

		report(0, REPORT_INFO, "Lock: previous instance is running (id: %d)\n", id);

		if (cfg_lock_clean) {

			if (pppoa_lock_eradicate(id) < 0) {

				report(0, REPORT_ERROR, "Lock: still active, could not be released\n");

				return(-1);

			}

		} else {

			report(0, REPORT_ERROR, "Lock: still active, use -c option to override\n");

			return(-1);

		}

	}

	if (pppoa_lock_sem_create(id) < 0) {

		report(0, REPORT_ERROR, "Lock: semaphore could not be created\n");

		return(-1);

	}
	pppoa_lock_sem_acquire();

	if (pppoa_lock_file_create(id) < 0) {

		report(0, REPORT_INFO, "Lock: lock file could not be created\n");

	}

	atexit(pppoa_lock_release);

	return(0);

}

static void pppoa_lock_release(void)
{

	report(1, REPORT_DEBUG, "Lock: release\n");

	pppoa_lock_file_destroy();

	pppoa_lock_sem_release();
	pppoa_lock_sem_destroy();

}


/*****************************************************************************
*	Options
*****************************************************************************/

static int pppoa_usage(void)
{

	fprintf(stderr, "pppoa V%s:\n", VERSION);
	fprintf(stderr, "usage: pppoa [options]\n");
	fprintf(stderr, "General options:\n");
	fprintf(stderr, "  -h / --help  : command help message\n");
	report_usage();
	pppoa_general_usage();
	/*product_usage();*/

	exit(-1);

	return(0);
}

static int pppoa_options_parse(int argc, char** argv)
{

	int i;

	for (i = 1; i < argc; ++i)
	{
		if (strcmp(argv[i], "-h")==0 || strcmp(argv[i], "--help") == 0)
			pppoa_usage();
		else {
			if (report_options_parse(argc, argv, &i) >= 0)
				continue;
			if (pppoa_general_options_parse(argc, argv, &i) >= 0)
				continue;
			/*if (product_options_parse(argc, argv, &i) >= 0)
				continue;*/
			return(-1);
		}
	}

	return(0);

}

static int pppoa_options_check(void)
{

	if (report_options_check() < 0)
		return(-1);

	if (pppoa_general_options_check() < 0)
		return(-1);

	/*if (product_options_check() < 0)
		return(-1);*/

	return(0);

}

#endif

