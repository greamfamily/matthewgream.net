/*
*  ALCATEL SpeedTouch USB modem utility : PPPoA implementation (3nd edition)
*  Copyright (C) 2001 Edouard Gomez
* 
*  This program is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public License
*  as published by the Free Software Foundation; either version 2
*  of the License, or (at your option) any later version.
*  
*  This program is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*  
*  You should have received a copy of the GNU General Public License
*  along with this program; if not, write to the Free Software
*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*
*  Author : Edouard Gomez (ed.gomez@free.fr)
*  Creation : 08/08/2001
*  Refactor : Matthew Gream (matthew.gream@pobox.com)
*
* $Id: product-thomson.h,v 1.1 2003/11/23 22:26:15 matt Exp $
*/

#ifndef _PRODUCT_THOMSON_H_
#define _PRODUCT_THOMSON_H_


/******************************************************************************
* Interface
******************************************************************************/

#if 0

/*****************************************************************************
* Local Prototypes
*****************************************************************************/

#if 0
extern int  upload_microcode(pusb_device_t fdusb,const char * filename);
extern void swbuff(pusb_device_t fdusb, int state);
extern int  get_reference(pusb_device_t fdusb);
extern int  modem_start_synchro(pusb_device_t fdusb);
extern int  get_state(pusb_device_t fdusb, unsigned char *buf);
extern int  print_state(unsigned char *buf);
extern void test_sequence(pusb_device_t fdusb);
extern void handle_endpoint_int(pusb_device_t fdusb);
extern int link_up;
extern void signal_usr2(int signal);
extern int dl_512_first; /* Try to download 512 bytes before first op */
extern int sb;           /* Software buffering */
const char* file = NULL;
#endif

/******************************************************************************
*	Main Lib Function
******************************************************************************/

#if 0
static product_t product_thomson = {
	0,
	"Alcatel SpeedTouch USB",
	0x06b9, 0x4061, /* usb dev vid/pid */
	0x07, 0x05, 0x01 /* usb ep data/code/intr */
};
#endif

static product_t product_conexant = {
	0,
	"Conexant AccessRunner USB",
	0x0572, 0xcafe, /* usb dev vid/pid */
	0x02, 0x01, 0x03 /* usb ep data/code/intr */
};

void* magic = NULL;

void product_usage()
{
#if 0
	fprintf(stderr, "SpeedTouch options:\n");
	fprintf(stderr, "  -s           : skip the first 512 bytes read\n");
	fprintf(stderr, "  -b           : enable software buffering\n");
	fprintf(stderr, "  -f microcode : upload this microcode file first\n");
#endif
	product_conexant_usage();
}
int product_options_parse(int argc, char**argv, int* argi)
{
#if 0
	if (strcmp(argv[*argi],"-b")==0)
		sb = 1;
	else if (strcmp(argv[*argi],"-s")==0)
		dl_512_first = 0;
	else if (strcmp(argv[*argi],"-f")==0 && (*argi)+1<argc)
		file = argv[++(*argi)];
	else
		return(-1);
	return(0);
#endif
	return product_conexant_options_parse(argc, argv, argi);

}
int product_options_check()
{
#if 0
	if (file == NULL)
		return(-1);

	return(0);
#endif
	return product_conexant_options_check();
}

product_t* product_open_probe()
{
	product_t* p = NULL;
#if 0
	if ((p = product_open_id(ST_VENDOR,ST_PRODUCT)) != NULL)
		return (p);
#endif
	if ((p = product_open_id(0x0572, 0xcafe)) != NULL)
		return (p);
	return (NULL);
}
product_t* product_open_id(int vid, int pid)
{
	product_t* p = NULL;
#if 0
	if (vid == ST_VENDOR && pid == ST_PRODUCT) {
		pusb_device_t d;
		p = &product_thomson;
 		d = pusb_search_open(vid, pid);
		if (d != NULL) {
			p->device = d;
			p->intf_active[0] = 0;
			p->intf_active[1] = 0;
			p->intf_active[2] = 0;
			p->intf_active[3] = 0;
			return p;
		}
	}
#endif
	if (vid == 0x0572 && pid == 0xcafe) {
		pusb_device_t d;
		p = &product_conexant;
 		d = pusb_search_open(vid, pid);
		if (d != NULL) {
			p->device = d;
			p->intf_active[0] = 0;
			p->intf_active[1] = 0;
			p->intf_active[2] = 0;
			p->intf_active[3] = 0;
			return p;
		}
	}
	return (NULL);
}
product_t* product_open_name(const char* name)
{
	/*!!!*/
	return (NULL);
}
int product_close(product_t* t)
{
	int i;

	for (i = 0; i < 4; ++i) {

		if (t->intf_active[i] > 0) {

			if (pusb_release_interface(t->device, i) < 0)
				report(0, REPORT_ERROR|REPORT_PERROR, "Fail");

			t->intf_active[i] = 0;
		}
	}

	pusb_close(t->device);
	return (0);
}
int product_acquire_intf(product_t* t, int i)
{
	/*
	 * we check that no one else is already using the modem,
	 * by claiming (ie requesting exclusive use) interface 0, 1 & 2,
	 * which are all the interfaces of the USB modem.
	 */
	
	if (pusb_claim_interface(t->device, i) < 0) {
		report(0, REPORT_ERROR|REPORT_PERROR, 
			"USB DSL modem: cannot acquire interface %d (another program/driver may be using it)\n", i);
		return(-1);
	}

	t->intf_active[i] = 1;

	if (pusb_set_configuration(t->device, 1) < 0) {
		report(0, REPORT_ERROR|REPORT_PERROR, 
			"pusb_set_configuration 1 (interface %d)\n", i);
		return(-1);
	}

	return(0);
}
int product_acquire(product_t* t, int* kernel)
{
	if (product_acquire_intf(t, 0) < 0) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed acquire (interface 0 - other progam/driver active ?)\n");

		return(-1);
	}	

	if (product_acquire_intf(t, 1) < 0) {

		if (!*kernel) {

			report(0, REPORT_ERROR, "USB DSL modem: Failed acquire (interface 1 - other progam/driver active ?)\n");

			return(-1);
		}

		report(0, REPORT_INFO, "USB DSL modem: Acquire found kernel driver\n");

	} else { 

		if (*kernel) {

			report(0, REPORT_ERROR, "USB DSL modem: Acquire found no kernel driver\n"); 

			*kernel = 0;
		}

	}

	return product_conexant_acquire(t->device);
}
int product_release(product_t* t)
{
	return product_conexant_release(t->device);
}
int product_setup_check(product_t* t)
{
	return product_conexant_configure_check(t->device);
}
int product_setup_config(product_t* t)
{
	int r;
	r = product_conexant_configure_load(t->device);
	if (r == 0)
		r = product_conexant_configure_wait(t->device);
	if (r == 0)
		r = product_conexant_configure_config(t->device);
	return r;

	/*return upload_microcode(t->device, file);*/
}

int product_setup_wait(product_t* t)
{
	return product_conexant_configure_wait(t->device);
}

int product_setup_report(product_t* t)
{
	return product_conexant_configure_report(t->device);
}

int product_adsl_config(product_t* t)
{
	return product_conexant_connect_setup(t->device);

	/*if (sb) swbuff(t->device, 1);*/
	return (0);
}
int product_adsl_verify(product_t* t)
{
	return product_conexant_connect_verify(t->device);

	/*get_reference(t->device);*/
	/*test_sequence(t->device);*/
	return (0);
}
int product_adsl_connect(product_t* t)
{
	return product_conexant_connect_start(t->device);

	/*link_up = 0;*/
	/*signal(SIGUSR2 , signal_usr2);*/
	/*handle_endpoint_int(t->device);*/
	/*modem_start_synchro(t->device);*/
	/*return (0);*/
}
int product_adsl_connect_check(product_t* t)
{
	return product_conexant_connect_check_line(t->device);

	/*return (link_up);*/
}
int product_adsl_connect_wait(product_t* t)
{
	return product_conexant_connect_check_wait(t->device);
}
int product_adsl_disconnect(product_t* t)
{
	return product_conexant_connect_stop(t->device);

	/*link_up = 0;*/
	/*signal(SIGUSR2 , signal_usr2);*/
	/*handle_endpoint_int(t->device);*/
	/*modem_start_synchro(t->device);*/
	/*return (0);*/
}
int product_adsl_disconnect_check(product_t* t)
{
	int r = product_conexant_connect_check_line(t->device);
	return (r == -1) ? r : !r;

	/*return (link_up);*/
}
int product_adsl_disconnect_wait(product_t* t)
{
	return product_conexant_connect_check_wait(t->device);
}
int product_adsl_report(product_t* t)
{
	return product_conexant_connect_report(t->device);

	/*unsigned char buf[2048];*/
	/*set_state(t->device, buf);*/
	/*print_state(buf);*/
}

#endif 

#endif

