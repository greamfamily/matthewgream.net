/*
*  ALCATEL SpeedTouch USB modem microcode extract utility
*  Copyright (C) 2001 Benoit PAPILLAULT
*  
*  This program is free software; you can redistribute it and/or
*  modify it under the terms of the GNU General Public License
*  as published by the Free Software Foundation; either version 2
*  of the License, or (at your option) any later version.
*  
*  This program is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*  
*  You should have received a copy of the GNU General Public License
*  along with this program; if not, write to the Free Software
*  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*
*  Author   : Benoit PAPILLAULT <benoit.papillault@free.fr>
*  Creation : 25/04/2001
*  Refactor : Matthew Gream (matthew.gream@pobox.com)
*
*  Searching for the microcode is done using the best match for a start and end 
*  patterns. This has been tested with windows 1.3 drivers, linux 1.3 drivers
*  & linux 1.3.2 drivers (using binary available at the Alcatel website:
*  http://www.alcateldsl.com/ ).
*
* $Id: product.c,v 1.6 2003/11/23 22:26:15 matt Exp $
*/

#ifndef _PRODUCT_C_
#define _PRODUCT_C_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <signal.h>

#include "pusb.h"
#include "product.h"
#include "report.h"

#include "product-conexant.h"
#include "product-thomson.h"

/******************************************************************************
*	Main Lib Function
******************************************************************************/

#if 0
static product_t product_thomson = {
	0,
	"Alcatel SpeedTouch USB",
	0x06b9, 0x4061, /* usb dev vid/pid */
	0x07, 0x05, 0x01 /* usb ep data/code/intr */
};
#endif

static product_t product_conexant = {
	0,
	"Conexant AccessRunner USB",
	0x0572, 0xcafe, /* usb dev vid/pid */
	0x02, 0x01, 0x03 /* usb ep data/code/intr */
};

void* magic = NULL;

int product_usage()
{
	return product_conexant_usage();
}
int product_options_parse(int argc, char**argv, int* argi)
{
	return product_conexant_options_parse(argc, argv, argi);

}
int product_options_check()
{
	return product_conexant_options_check();
}

product_t* product_open_probe()
{
	product_t* p = NULL;
#if 0
	if ((p = product_open_id(ST_VENDOR,ST_PRODUCT)) != NULL)
		return (p);
#endif
	if ((p = product_open_id(0x0572, 0xcafe)) != NULL)
		return (p);
	return (NULL);
}
product_t* product_open_id(int vid, int pid)
{
	product_t* p = NULL;
#if 0
	if (vid == ST_VENDOR && pid == ST_PRODUCT) {
		pusb_device_t d;
		p = &product_thomson;
 		d = pusb_search_open(vid, pid);
		if (d != NULL) {
			p->device = d;
			p->intf_active[0] = 0;
			p->intf_active[1] = 0;
			p->intf_active[2] = 0;
			p->intf_active[3] = 0;
			return p;
		}
	}
#endif
	if (vid == 0x0572 && pid == 0xcafe) {
		pusb_device_t d;
		p = &product_conexant;
 		d = pusb_search_open(vid, pid);
		if (d != NULL) {
			p->device = d;
			p->intf_active[0] = 0;
			p->intf_active[1] = 0;
			p->intf_active[2] = 0;
			p->intf_active[3] = 0;
			return p;
		}
	}
	return (NULL);
}
product_t* product_open_name(const char* name)
{
	/*!!!*/
	return (NULL);
}
int product_close(product_t* t)
{
	int i;

	for (i = 0; i < 4; ++i) {

		if (t->intf_active[i] > 0) {

			if (pusb_release_interface(t->device, i) < 0)
				report(0, REPORT_ERROR|REPORT_PERROR, "Fail");

			t->intf_active[i] = 0;
		}
	}

	pusb_close(t->device);
	return (0);
}
int product_acquire_intf(product_t* t, int i)
{
	/*
	 * we check that no one else is already using the modem,
	 * by claiming (ie requesting exclusive use) interface 0, 1 & 2,
	 * which are all the interfaces of the USB modem.
	 */
	
	if (pusb_claim_interface(t->device, i) < 0) {
		report(0, REPORT_ERROR|REPORT_PERROR, 
			"USB DSL modem: cannot acquire interface %d (another program/driver may be using it)\n", i);
		return(-1);
	}

	t->intf_active[i] = 1;

	if (pusb_set_configuration(t->device, 1) < 0) {
		report(0, REPORT_ERROR|REPORT_PERROR, 
			"pusb_set_configuration 1 (interface %d)\n", i);
		return(-1);
	}

	return(0);
}
int product_acquire(product_t* t, product_acquire_t acq, int* kernel)
{
	if (product_acquire_intf(t, 0) < 0) {

		report(0, REPORT_ERROR, "USB DSL modem: Failed acquire (interface 0 - other progam/driver active ?)\n");

		return(-1);
	}	

	if (product_acquire_intf(t, 1) < 0) {

		if (!*kernel) {

			report(0, REPORT_ERROR, "USB DSL modem: Failed acquire (interface 1 - other progam/driver active ?)\n");

			return(-1);
		}

		report(0, REPORT_INFO, "USB DSL modem: Acquire found kernel driver\n");

	} else { 

		if (*kernel) {

			report(0, REPORT_ERROR, "USB DSL modem: Acquire found no kernel driver\n"); 

			*kernel = 0;
		}

	}

	return product_conexant_acquire(t->device, acq);
}
int product_release(product_t* t, product_acquire_t acq)
{
	return product_conexant_release(t->device, acq);
}
int product_setup_check(product_t* t)
{
	return product_conexant_configure_check(t->device);
}
int product_setup_config(product_t* t)
{
	int r;
	r = product_conexant_configure_load(t->device);
	if (r == 0)
		r = product_conexant_configure_wait(t->device);
	if (r == 0)
		r = product_conexant_configure_config(t->device);
	return r;
}
int product_setup_wait(product_t* t)
{
	return product_conexant_configure_wait(t->device);
}
int product_setup_report(product_t* t)
{
	return product_conexant_configure_report(t->device);
}
int product_adsl_config(product_t* t)
{
	return product_conexant_connect_setup(t->device);
}
int product_adsl_verify(product_t* t)
{
	return product_conexant_connect_verify(t->device);
}
int product_adsl_connect(product_t* t)
{
	return product_conexant_connect_start(t->device);
}
int product_adsl_connect_check(product_t* t)
{
	return product_conexant_connect_check_line(t->device);
}
int product_adsl_connect_wait(product_t* t)
{
	return product_conexant_connect_check_wait(t->device);
}
int product_adsl_disconnect(product_t* t)
{
	return product_conexant_connect_stop(t->device);
}
int product_adsl_disconnect_check(product_t* t)
{
	int r = product_conexant_connect_check_line(t->device);
	return (r == -1) ? r : !r;
}
int product_adsl_disconnect_wait(product_t* t)
{
	return product_conexant_connect_check_wait(t->device);
}
int product_adsl_report(product_t* t)
{
	return product_conexant_connect_report(t->device);
}

int product_data_write(product_t* t, unsigned char* buffer_ptr, int buffer_sz, int timeout)
{
	return product_conexant_data_write(t->device, buffer_ptr, buffer_sz, timeout);
}
int product_data_read(product_t* t, unsigned char* buffer_ptr, int buffer_sz, int timeout)
{
	return product_conexant_data_read(t->device, buffer_ptr, buffer_sz, timeout);
}
int product_data_report(product_t* t)
{
	return product_conexant_data_report(t->device);
}

#endif /* #ifndef _PRODUCT_C_ */
