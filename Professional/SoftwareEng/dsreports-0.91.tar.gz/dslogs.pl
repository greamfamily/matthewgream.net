#!/usr/bin/perl

####################################################################
# $Id: dslogs.pl,v 1.1 2002/09/30 19:11:32 matt Exp $
####################################################################

####################################################################
#
# DailyStats - dslogs.pl
#
# (C)1998-1999 Perlfect Solutions (www.perlfect.com)
#              N.Moraitakis
#
# Author  : Nick Moraitakis
#           nick@perlfect.com
#
# Release
# History : v1.0 Oct 20 1998
#           v1.4 Apr 14 1999
#           v2.0 Jul  5 1999
#           v2.1 Jul  6 1999
#           v3.0 Dec  5 1999
#
####################################################################


####################################################################
# program info
my $PROGRAM     = "Perlfect DailyStats Log Analyzer";
my $VERSION     = "3.0";
my $USAGE = "
dslogs.pl [options] log1, log2, ..

where:
--domain      the domain name of the site (as in mydomain.com)
--history     the file to store the date cursors for logs
--ignore      a |-separated list of extensions to ignore (i.e gif|jpg)
--index       the default index filename      
--intref      if present internal referrers will not be ignored
--modified    the file to store the list of modified summaries
--reports     the root of the directory tree for the reports
--overwrite   overwrite old summaries (do not update incrementally)
--quiet       operate in quiet mode
--zip         the program to use for compression
--unzip       the program to use for decompression
";


####################################################################
# constants
my %month2num = ( jan=>'01',feb=>'02',mar=>'03',apr=>'04',may=>'05',jun=>'06',jul=>'07',aug=>'08',sep=>'09',oct=>'10',nov=>'11',dec=>'12' ); 
my @mdays     = (0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);


####################################################################
# options
my $DOMAIN            = 'dummy.com';
my $REPORTS           = 'reports';
my $INTERNAL_REF      = 0;
my $DEFAULT_INDEX     = 'index.htm';
my $IGNORE_EXTENSIONS = 'gif|jpg|jpeg|pl|cgi|png|xml|css';
my $HISTORY           = 'history';
my $MODIFIED          = 'modified';
my $QUIET              = 0;

my $ZIP               = 'gzip';
my $UNZIP             = 'gunzip';


####################################################################
# includes
use Getopt::Long;


####################################################################
# get options
GetOptions('domain=s'  =>\$DOMAIN,
           'history=s' =>\$HISTORY,
           'modified=s'=>\$MODIFIED,
           'reports=s' =>\$REPORTS,
           'ignore=s'  =>\$IGNORE_EXTENSIONS,
           'index=s'   =>\$DEFAULT_INDEX,
           'intref'    =>\$INTERNAL_REF,
           'quiet'     =>\$QUIET,
           'zip=s'     =>\$ZIP,
           'unzip=s'   =>\$UNZIP,
          );


####################################################################
# say hello
($QUIET == 0) && print "$PROGRAM v$VERSION -- (C)Perlfect Solutions - www.perlfect.com\n";


####################################################################
my @LOGS = @ARGV;
die $USAGE unless(@LOGS);
my $wd = `pwd`;
chomp $wd;
foreach (@LOGS)
  {
    $_ = "$wd/$_" unless($_=~m/^\//);
  }
$wd = $REPORTS;
chdir($wd) or die "** cannot chdir to $wd: $!\n";


####################################################################
# get current date
my @today = ((localtime(time()))[3,4,5]); $today[1]++;
($QUIET == 0) && print "Starting: $today[0]/$today[1]/$today[2]\n";


####################################################################
# set date cursors from history file
($QUIET == 0) && print "Loading history ...\n";
my %date_cursors;
system("touch $HISTORY") unless(-f $HISTORY);
open(HIST, "$HISTORY")
  or die "** cannot read history file: $HISTORY: $!\n";
while(<HIST>)
  {
    m/(\S+) (\d+) (\d+) (\d+) (\d+) (\d+) (\d+)/;
    $date_cursors{$1} = [$2, $3, $4, $5, $6, $7];
  }
close HIST;


####################################################################
# initialize the list of modified dates
($QUIET == 0) && print "Loading modified ...\n";
my @modified;
system("touch $MODIFIED") unless(-f $MODIFIED);
open(MOD, "$MODIFIED")
  or die "** cannot read modified file: $MODIFIED: $!\n";
while(<MOD>)
  {
    chomp;
    push(@modified, $_);
  }
close MOD;


####################################################################
# parse the logs one at a time
($QUIET == 0) && print "Loading logs ...\n";
my %logs = ();
foreach (@LOGS)
{
  $date_cursors{$_} = [0,0,0,0,0,0] 
        unless(defined($date_cursors{$_}));
  parse_log($_, $date_cursors{$_});
}


####################################################################
# write new modified dates list
($QUIET == 0) && print "Storing modified ...\n";
open(MOD, ">$MODIFIED")
  or die "** can't write modified file: $MODIFIED: $!\n";
foreach (@modified)
  {
    print MOD "$_\n";
  }


####################################################################
# write new date cursors to history file
($QUIET == 0) && print "Storing history ...\n";
open(HIST, ">$HISTORY")
  or die "** can't write history file: $HISTORY: $!\n";
foreach (keys %date_cursors)
  {
    print HIST "$_ ".join(" ", @{$date_cursors{$_}})."\n";
  }


####################################################################
($QUIET == 0) && print "Complete: run the report generator\n\n";


####################################################################
sub parse_log
  {
    my ($log, $date_cursor) = @_;
    ($QUIET == 0) && print "Reading: $log\n";

    # open log
    unless(open(LOG, $log))
      {
        ($QUIET == 0) && print "open failed: $!\n";
        return;
      }

    # process log
    my (@lines, %accesses, $bytes, %hosts, %docs, %gateways, 
        %referers, %agents);
    my ($line, $host, $year, $month, $day, $hour, $min, $sec, $doc, 
        $status, $bytes, $referer, $agent);
    while(<LOG>)
      {
        $log_size++;
        chomp;
        next unless($_);
        # parse the current line
        $line = $_;
        if($_=~m/(\S+) [^ ]* [^ ]* \[(.*?):(.*?)\] \"\S+ (\S+) .*?\" (\d+) (\S+)(?: \"(.*?)\" \"(.*?)\")?/)
          {
            $host = $1;
            my $date = $2;
            my $time = $3;
            $doc = $4;
            $status = $5;
            $bout = $6;
            $referer = $7;
            $agent = $8;
            $bytes = 0 unless($bytes=~m/(\d+)/);
            if($date=~m/(\d+)\/(\w+)\/(\d+)/i)
              {
                $day = $1;
                $month = $month2num{lc($2)};
                $year = $3;
              }
            if($time=~m/(\d+):(\d+):(\d+).*/)
              {
                $hour = $1;
                $min = $2;
                $sec = $3;
              }
          }

        # skip the line if we've already processed it on a previous run
        next if(compare_dates([$year, $month, $day, $hour, $min, $sec], 
                $date_cursor)<0);

        # have we just crossed to a new day?
        if(compare_dates([$year, $month, $day, 0, 0, 0], $date_cursor)>0)
          {
            # store the summary
            store_summary($date_cursor, \@lines, \%accesses, \$bytes, 
                         \%hosts, \%docs, \%gateways, \%referers, \%agents)
              if(@lines);
            # reset all data structures
            @lines = ();
            %accesses = ();
            $bytes = 0;
            %hosts = ();
            %docs = ();
            %gateways = ();
            %referers = ();
            %agents = ();
          }

        # update the date cursor
        @$date_cursor = ($year, $month, $day, $hour, $min, $sec);
        # increment the per-minute access counter
        $accesses{"$hour:$min"}++;
        # increment the bytes counter
        $bytes += $bout;
        # ignore the rest unless it is a 200 OK
        next unless($status==200);
        # strip cgi parameters
        $doc=~s/\?.*//g;
        # strip default index from path
        $doc=~s/(.)\/($DEFAULT_INDEX)?$/$1/o;
        # skip if file matches an ignore rule
        next if($doc=~m/($IGNORE_EXTENSIONS)$/oi);
        # store the line
        push @lines, $line;
        # increment the document counter
        $docs{$doc}++;
        # increment the host visits counter
        $hosts{$host}++;
        # increment the referer counter
        $referers{$referer}++ 
                unless(!$INTERNAL_REF and 
                        $referer=~m/http:\/\/(.*\.)?$DOMAIN(:\d+)?/i);
        # increment tha gateway counter
        $gateways{$doc}++ unless($referer=~m/http:\/\/.*\.$DOMAIN(:\d+)?/i);
        # keep only the agent class/name and version
        if($agent=~m/^\S+\/[\d\.]+/)
          {
            $agent = $&;
          }
        # ingrement the agent counter
        $agents{$agent}++ unless($hosts{$host}>1);
      }

    store_summary($date_cursor, \@lines, \%accesses, \$bytes, 
                 \%hosts, \%docs, \%gateways, \%referers, \%agents)    
      if(@lines);

    # close log
    close LOG;
  }

####################################################################
sub store_summary
  {
    my ($date, $lines, $accesses, $bytes, $hosts, $docs, $gateways, 
        $referers, $agents) = @_;

    ($QUIET == 0) && print "Updating: $$date[0]-$$date[1]/$$date[2]\n";

    # create daily directory
    unless(-d "$$date[0]-$$date[1]")
      {
        unlink("$$date[0]-$$date[1]");
        mkdir("$$date[0]-$$date[1]", 0755);
      }

    # uncompress daily summary
    if(-f "$$date[0]-$$date[1]/$$date[2].dss.gz")
      {
        if(system("$UNZIP $$date[0]-$$date[1]/$$date[2].dss.gz"))
          {
            die "** $UNZIP failed: $!\n";
          }
      }

    # read daily summary
    load_summary($date, $lines, $accesses, $bytes, $hosts, $docs, 
                 $gateways, $referers, $agents);

    # save daily summary [updated]
    save_summary($date, $lines, $accesses, $bytes, $hosts, $docs, 
                 $gateways, $referers, $agents);

    # compress daily summary
    system("$ZIP $$date[0]-$$date[1]/$$date[2].dss");

    # update global variables
    push(@modified, "$$date[0] $$date[1] $$date[2]") 
        unless (member(\@modified, "$$date[0] $$date[1] $$date[2]"));

    # read global summary
    my %summary = ();
    if(open(MS, "summary"))
      {
        while(<MS>)
          {
            chomp;
            if(m/^(\S+) (\d+) (\d+) (\d+) (\d+) (\d+)/)
              {
                $summary{$1} = [$2, $3, $4, $5, $6];
              }
          }
      }
    close MS;

    # update global summary
    my $total_accesses = 0;
        foreach(keys %$accesses) { $total_accesses += $$accesses{$_}; }
    my $total_pageviews = 0;
        foreach(keys %$docs)     { $total_pageviews += $$docs{$_}; }
    my $unique_visitors = scalar(keys %$hosts);
        $unique_visitors = 1 unless($unique_visitors);
    my $pages_per_visitor = $total_pageviews/$unique_visitors;
        $pages_per_visitor =~ s/(\.\d{2}).*/$1/;
    $summary{"$$date[0]-$$date[1]-$$date[2]"} = 
        [$$bytes, $total_accesses, $total_pageviews, 
         $unique_visitors, $pages_per_visitor];

    # write global summary
    open(MS, ">summary")
      or die "** failed to update summary file: $!\n";
    foreach(sort keys %summary)
      {
        print MS "$_ ".join(" ", @{$summary{$_}})."\n";
      }
    close MS;
  }

####################################################################
sub load_summary
  {
    my ($date, $lines, $accesses, $bytes, $hosts, $docs, $gateways, 
        $referers, $agents) = @_;
    open(DS, "$$date[0]-$$date[1]/$$date[2].dss")
      or return undef;
    my (@lines_temp) = ();
    while(<DS>)
      {
        if(m/\%b (\d+)/) { $$bytes += $1; }
        if(m/\%a (\S+) (\S+)/) { $$accesses{$1} += $2; }
        if(m/\%d (\S+) (\S+)/) { $$docs{$1} += $2; }
        if(m/\%g (\S+) (\S+)/) { $$gateways{$1} += $2; }
        if(m/\%r (\S+) (\S+)/) { $$referers{$1} += $2; }
        if(m/\%c (\S+) (\S+)/) { $$agents{$1} += $2; }
        if(m/\%h (\S+) (\d+)/) { $$hosts{$1} += $2; }
        if(m/\%l (.+)/) { push @lines_temp, $1; }
      }
    close(DS);
    foreach(@$lines) { push @lines_temp, $_; }; @$lines = @lines_temp;
    return 1;
  }

####################################################################
sub save_summary
  {
    my ($date, $lines, $accesses, $bytes, $hosts, $docs, $gateways, 
        $referers, $agents) = @_;
    open(DS, ">$$date[0]-$$date[1]/$$date[2].dss")
      or return undef;
    print DS "%b $$bytes\n";
    foreach(keys %$accesses) { print DS "%a $_ $$accesses{$_}\n"; }
    foreach(keys %$docs)     { print DS "%d $_ $$docs{$_}\n"; }
    foreach(keys %$gateways) { print DS "%g $_ $$gateways{$_}\n"; }
    foreach(keys %$referers) { print DS "%r $_ $$referers{$_}\n"; }
    foreach(keys %$agents)   { print DS "%c \"$_\" $$agents{$_}\n"; }
    foreach(keys %$hosts)    { print DS "%h $_ $$hosts{$_}\n"; }
    foreach(@$lines)         { print DS "%l $_\n"; }
    close(DS);
    return 1;
  }

####################################################################
sub shift_date
  {
    my ($inc, $date) = @_;
    my ($day, $month, $year) = @$date;
    $day += $inc;
    until($day>0 && $day<=$mdays[$month])
      {
        if($day<=0)
          {
            if($month==1) {
              $month = 12;
              $year--;
            } else {
              $month--;
            }
            $day = $mdays[$month]+$day;
          }
        else
          {
            if($month==12) {
              $month = 1;
              $year++;
            } else {
              $month++;
            }
            $day = $mdays[$month]+($day-$mdays[$month-1]);
          }
      }
    return ($day, $month, $year);
  }

####################################################################
sub compare_dates
  {
    my($a, $b) = @_;
    my @c;
    foreach (0..5)
      {
        if    ($$a[$_]>$$b[$_]) { return  1; }
        elsif ($$a[$_]<$$b[$_]) { return -1; }
      }
    return 0;
  }

####################################################################
sub member
  {
    my ($ar, $el) = @_;
    foreach (@$ar)
      {
        return 1 if($_ eq $el);
      }
    return 0;
  }

####################################################################

