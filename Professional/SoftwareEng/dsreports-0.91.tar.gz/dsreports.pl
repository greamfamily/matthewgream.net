#!/usr/bin/perl

#####################################################################
# $Id: dsreports.pl,v 1.1 2002/09/30 19:11:32 matt Exp $
#####################################################################

#####################################################################
# 
# DailyStats - dsreports.pl
#
# (C)1998-1999 Perlfect Solutions (www.perlfect.com)
#              N.Moraitakis
#
# Author  : Nick Moraitakis
#           nick@perlfect.com
#
# Release
# History : v1.0 Oct 20 1998
#           v1.4 Apr 14 1999
#           v2.0 Jul  5 1999
#           v2.1 Jul  6 1999
#           v3.0 Dec  5 1999
#           
#####################################################################


#####################################################################
# program info
my $PROGRAM     = "Perlfect DailyStats Report Generator";
my $VERSION     = "3.0";
my $USAGE = "
dsreports.pl [options]
--domain      the domain name of the site (as in mydomain.com)
--reports     the root of the directory tree for the reports
--bargif      the url to bar.gif
--maxdpviews   the maximum number of daily pageviews to calibrate graphs
--modified    the file containing the modified dates list
--zip         the program to use for compression
--unzip       the program to use for decompression
--quiet       operate in quiet mode
--output_daily  output names of daily reports creawted
--append_lines  append the raw log to the report 
--generate_txt  generate a text file with the original logs
";


#####################################################################
# options
my $DOMAIN            = 'dummy.com';
my $REPORTS           = 'reports';
my $BARGIF            = 'dsbar.gif';
my $MAXDPVIEWS        = '1000';
my $MODIFIED          = 'modified';
my $ZIP               = 'gzip';
my $UNZIP             = 'gunzip';
my $QUIET             = 0;
my $OUTPUT_DAILY      = 0;
my $APPEND_LINES      = 0;
my $GENERATE_TXT      = 0;
my $HOSTINFO          = 'http://centralops.net/co/DomainDossier.vbs.asp?dom_whois=1&dom_dns=1&traceroute=1&net_whois=1&svc_scan=1&addr=';


#####################################################################
# constants
my @monthdays = qw(31 28 31 30 31 30 31 31 30 31 30 31);
my @HOURS;
foreach (0..23) 
  { 
    $_ = "0$_" if(length($_)==1); push(@HOURS, $_); 
  }
my @MINS;
foreach (0..59) 
  { 
    $_ = "0$_" if(length($_)); push(@MINS, $_); 
  } 
my @HHMM;
my ($h, $m);
foreach $h (@HOURS) 
  { 
    foreach $m (@MINS) 
      { 
        push(@HHMM, "$h:$m"); 
      } 
  }


#####################################################################
# includes
use Getopt::Long;


#####################################################################
# get options
GetOptions(
   'domain=s'     =>\$DOMAIN,
   'reports=s'    =>\$REPORTS,
   'zip=s'        =>\$ZIP,
   'unzip=s'      =>\$UNZIP,
   'bargif=s'     =>\$BARGIF,
   'maxdpviews=s' =>\$MAXDPVIEWS,
   'quiet'        =>\$QUIET,
   'output_daily' =>\$OUTPUT_DAILY,
   'append_lines' =>\$APPEND_LINES,
   'generate_txt' =>\$GENERATE_TXT
  );

# say hello
($QUIET == 0) && print "$PROGRAM v$VERSION -- (C)Perlfect Solutions - www.perlfect.com\n";

# get the current date string
my $now = localtime(time());


#####################################################################
# get to directory
chdir($REPORTS)
  or die "cannot chdir to $REPORTS: $!\n";


#####################################################################
# process daily (from modified)
open(MOD, "$MODIFIED")
  or die "cannot read modified file: $MODIFIED: $!\n";
while(<MOD>)
  {
    m/(\d+) (\d+) (\d+)/;
    dailyreport($1, $2, $3);
    push(@mod_months, "$1-$2") 
      unless (member(\@mod_months, "$1-$2"));
  }
close MOD;
open(MOD, ">$MODIFIED")
  or die "cannot clear modified file: $MODIFIED: $!\n";
close MOD;


#####################################################################
# read summary
my %summary = ();
my %totals = ();
my %pviews = ();
my ($date_begin, $date_end);
open(SUM, "summary")
  or die "** cannot open global summary file: $!\n";
while(<SUM>)
{
    if(m/(\d+-\d+)-(\d+) (\d+) (\d+) (\d+) (\d+) (\d+)/)
    {
        my ($m, $d) = ($1, $2);
        $date_begin = "$m-$d" unless($date_begin);
        $date_end = "$m-$d";
        $summary{"$m-$d"} = [$3, $4, $5, $6, $7];
        $$totals{"$m"}->[0] += int($3/1024);
        $$totals{"$m"}->[1] += $4;
        $$totals{"$m"}->[2] += $5;
        $$totals{"$m"}->[3] += $6;
        $$totals{"$m"}->[4] = $$totals{"$m"}->[2]/$$totals{"$m"}->[3];
        $$totals{"$m"}->[4] =~ s/(\.\d{2}).*/$1/;
        foreach (0..3)
        {
                $$totals{"total"}->[$_]+=$summary{"$m-$d"}->[$_];
        }
    }
}
close SUM;


#####################################################################
# update month
my $month;
foreach $month (@mod_months)
{
        ($QUIET == 0) && print "Generating Monthly Report for $month..\n";
        open(MR, ">$month/index.htm")
                or die "** cannot write to $month/index.htm\n";
        print MR "
<HTML>
<HEAD>
<TITLE>Monthly Web Server Report for $DOMAIN ($month)</TITLE>
<META NAME=\"GENERATOR\" CONTENT=\"$PROGRAM v$VERSION\">
</HEAD>
<BODY BGCOLOR=\"#ffffff\">
<CENTER>
<H2>Monthly Web Server Report for <A HREF=\"http://$DOMAIN/\">$DOMAIN</A> ($month)</H2>
<P>
<TABLE WIDTH=\"600\" BORDER=\"0\" CELLSPACING=\"0\" CELLPADDING=\"5\">
<TR><TH COLSPAN=\"2\" BGCOLOR=\"#003366\"><FONT COLOR=\"#ffffff\">Summary</FONT></TH></TR>
<TR><TD BGCOLOR=\"#dddddd\">Total Transfer (Kb)</TD><TD BGCOLOR=\"#dddddd\" ALIGN=\"right\"><B>$$totals{$month}->[0]</B></TD></TR>
<TR><TD BGCOLOR=\"#eeeeee\">Total Accesses</TD><TD BGCOLOR=\"#eeeeee\" ALIGN=\"right\"><B>$$totals{$month}->[1]</B></TD></TR>
<TR><TD BGCOLOR=\"#dddddd\">Total Page Views</TD><TD BGCOLOR=\"#dddddd\" ALIGN=\"right\"><B>$$totals{$month}->[2]</B></TD></TR>
<TR><TD BGCOLOR=\"#eeeeee\">Total Unique Visitors</TD><TD BGCOLOR=\"#eeeeee\" ALIGN=\"right\"><B>$$totals{$month}->[3]</B></TD></TR>
<TR><TD BGCOLOR=\"#dddddd\">Pages Per Visitor</TD><TD BGCOLOR=\"#dddddd\" ALIGN=\"right\"><B>$$totals{$month}->[4]</B></TD></TR>
</TABLE>
</P>
";
        
   print MR "
<P>
<TABLE WIDTH=\"600\" BORDER=\"0\" CELLSPACING=\"0\" CELLPADDING=\"5\">
<TR><TH COLSPAN=\"3\" BGCOLOR=\"#003366\"><FONT COLOR=\"#ffffff\">Page Views</FONT></TH></TR>
";
        my $bg="#eeeeee";
        my $mnum = $month; $mnum=~s/.*-//;
        foreach (1..$monthdays[$mnum-1])
        {
                $_="0".$_ if(length($_)<2);
                if($bg=='#eeeeee') { $bg='#dddddd'; } else { $bg='#eeeeee'; }
                my $pv = $summary{"$month-$_"}->[2];
                my $barlen = int($pv*400/$MAXDPVIEWS)+1;
                print MR "
<TR><TD BGCOLOR=\"$bg\" ALIGN=\"right\" VALIGN=\"center\"><FONT SIZE=\"-1\"><a href=\"$_.htm\">$month-$_</a></FONT></TD>
<TD BGCOLOR=\"$bg\" ALIGN=\"left\" VALIGN=\"center\"><FONT SIZE=\"-1\">$pv&nbsp;</FONT></TD>
<TD WIDTH=\"400\" BGCOLOR=\"$bg\" ALIGN=\"left\" VALIGN=\"center\"><FONT SIZE=\"-1\"><A HREF=\"$_.htm\"><IMG SRC=\"$BARGIF\" WIDTH=\"$barlen\" HEIGHT=\"10\" BORDER=\"0\" ALT=\"$pv\"></A></FONT></TD></TR>
";        
        }
        print MR "
</TABLE>
</P>
";

        print MR "
<P>Report generated on <B>$now</B></P>
</CENTER>
</BODY>
</HTML>
";

        close MR;
}

#####################################################################
# update global
open(SR, ">index.htm")
        or die "** cannot create summary report $REPORT_DIR/index.htm\n";

($QUIET == 0) && print "Generating Global Summary Report..\n";
print SR "
<HTML>
<HEAD>
<TITLE>Web Server Report for $DOMAIN</TITLE>
<META NAME=\"GENERATOR\" CONTENT=\"$PROGRAM v$VERSION\">
</HEAD>
<BODY BGCOLOR=\"#ffffff\">
<CENTER>
<H2>Web Server Report for <A HREF=\"http://$DOMAIN/\">$DOMAIN</A></H2>
<P>
<H4>Web server log data from $date_begin to $date_end</H4>
</P>
<P>
<TABLE WIDTH=\"600\" BORDER=\"0\" CELLSPACING=\"0\" CELLPADDING=\"5\">
<TR><TH COLSPAN=\"2\" BGCOLOR=\"#003366\"><FONT COLOR=\"#ffffff\">Summary</FONT></TH></TR>
<TR><TD BGCOLOR=\"#dddddd\">Total Transfer (Kb)</TD><TD BGCOLOR=\"#dddddd\" ALIGN=\"right\"><B>$$totals{total}->[0]</B></TD></TR>
<TR><TD BGCOLOR=\"#eeeeee\">Total Accesses</TD><TD BGCOLOR=\"#eeeeee\" ALIGN=\"right\"><B>$$totals{total}->[1]</B></TD></TR>
<TR><TD BGCOLOR=\"#dddddd\">Total Page Views</TD><TD BGCOLOR=\"#dddddd\" ALIGN=\"right\"><B>$$totals{total}->[2]</B></TD></TR>
<TR><TD BGCOLOR=\"#eeeeee\">Total Visits</TD><TD BGCOLOR=\"#eeeeee\" ALIGN=\"right\"><B>$$totals{total}->[3]</B></TD></TR>
</TABLE>
</P>
";

print SR "
<P>
<TABLE WIDTH=\"600\" BORDER=\"0\" CELLSPACING=\"0\" CELLPADDING=\"5\">
<TR><TH COLSPAN=\"3\" BGCOLOR=\"#003366\"><FONT COLOR=\"#ffffff\">Page Views</FONT></TH></TR>
";
my $bg="#eeeeee";
my $m;
foreach $m (sort keys %$totals)
{
        next if($m eq 'total');
        $_="0".$_ if(length($_)<2);
        if($bg=='#eeeeee') { $bg='#dddddd'; } else { $bg='#eeeeee'; }
        my $pv = $$totals{"$m"}->[2];
        my $barlen = int($pv*400/($MAXDPVIEWS*30))+1;
        print SR "
<TR><TD BGCOLOR=\"$bg\" ALIGN=\"right\" VALIGN=\"center\"><FONT SIZE=\"-1\"><a href=\"$m/index.htm\">$m</a></FONT></TD>
<TD BGCOLOR=\"$bg\" ALIGN=\"left\" VALIGN=\"center\"><FONT SIZE=\"-1\">$pv&nbsp;</FONT></TD>
<TD WIDTH=\"400\" BGCOLOR=\"$bg\" ALIGN=\"left\" VALIGN=\"center\"><FONT SIZE=\"-1\"><A HREF=\"$m/index.htm\"><IMG SRC=\"$BARGIF\" WIDTH=\"$barlen\" HEIGHT=\"10\" BORDER=\"0\" ALT=\"$pv\"></A></FONT></TD></TR>
";
}
print SR "
</TABLE>
</P>
";

print SR "
<P>Report generated on <B>$now</B></P>
</CENTER>
</BODY>
</HTML>
";

close SR;


#####################################################################
# process daily
sub dailyreport
{
   my @date = @_;
   ($QUIET == 0) && print "Generating report for ".join("-", @date)."\n";

   my $summary = "$date[0]-$date[1]/$date[2].dss";

   # decompress the summary 
   if(-f "$summary.gz")
   {
        if(system("$UNZIP $summary.gz"))
        {
                die "$UNZIP failed: $!\n";
        }
    }

    # load the summary
    my (@lines, %accesses, $bytes, %hosts, %docs, %gateways, 
        %referers, %agents);
    load_summary(\@date, \@lines, \%accesses, \$bytes, \%hosts, \%docs, 
        \%gateways, \%referers, \%agents)
      or die "Failed to load summary file: $date[0]-$date[1]/$date[2].dss\n";

    # compress the summary file
    if(system("$ZIP $summary"))
      {
        die "$ZIP failed: $!\n";
      }
 
 
    # write the htm report 
    open(REP, ">$date[0]-$date[1]/$date[2].htm")
      or die "can't write to $date[0]-$date[1]/$date[2].htm: $!\n";    
    ($OUTPUT_DAILY > 0) && print "$REPORTS/$date[0]-$date[1]/$date[2].htm\n";
    my $date = "$date[0]-$date[1]-$date[2]";
    print REP "
<HTML>
<HEAD>
<TITLE>Daily Web Server Report for $DOMAIN ($date)</TITLE>
<META NAME=\"GENERATOR\" CONTENT=\"$PROGRAM v$VERSION\">
</HEAD>
<BODY BGCOLOR=\"#ffffff\">
<CENTER>
<H2>Daily Web Server Report for <A HREF=\"http://$DOMAIN/\">$DOMAIN</A> ($date)</H2>
";
    my $access_total;
    foreach (keys %accesses) { $access_total += $accesses{$_}; }
    my $views_total;
    foreach (keys %docs) { $views_total += $docs{$_}; }
    my $kbytes = int($bytes/1024);
    my $unique = scalar(keys %hosts);
         $unique = 1 unless($unique);
    my $ppv = $views_total/$unique;
    $ppv=~s/(\.\d{2}).*$/$1/;

    foreach ($kbytes, $access_total, $views_total, $unique)
    {
        $_ = "$_ ";
        while($_=~s/(\d)(\d{3})(,| )/$1,$2$3/){}
        $_=~s/ $//;
    }

    print REP "
<P>
<TABLE WIDTH=\"600\" BORDER=\"0\" CELLSPACING=\"0\" CELLPADDING=\"5\">
<TR><TH COLSPAN=\"2\" BGCOLOR=\"#003366\"><FONT COLOR=\"#ffffff\">Summary</FONT></TH></TR>
<TR><TD BGCOLOR=\"#dddddd\">Total Transfer (Kb)</TD><TD BGCOLOR=\"#dddddd\" ALIGN=\"right\"><B>$kbytes</B></TD></TR>
<TR><TD BGCOLOR=\"#eeeeee\">Total Accesses</TD><TD BGCOLOR=\"#eeeeee\" ALIGN=\"right\"><B>$access_total</B></TD></TR>
<TR><TD BGCOLOR=\"#dddddd\">Total Page Views</TD><TD BGCOLOR=\"#dddddd\" ALIGN=\"right\"><B>$views_total</B></TD></TR>
<TR><TD BGCOLOR=\"#eeeeee\">Total Unique Visitors</TD><TD BGCOLOR=\"#eeeeee\" ALIGN=\"right\"><B>$unique</B></TD></TR>
<TR><TD BGCOLOR=\"#dddddd\">Pages Per Visitor</TD><TD BGCOLOR=\"#dddddd\" ALIGN=\"right\"><B>$ppv</B></TD></TR>
</TABLE>
</P>
";

    print REP "
<P>
<TABLE WIDTH=\"600\" BORDER=\"0\" CELLSPACING=\"0\" CELLPADDING=\"5\">
<TR><TH COLSPAN=\"2\" BGCOLOR=\"#003366\"><FONT COLOR=\"#ffffff\">Documents</FONT></TH></TR>
";
    my $bg = "#eeeeee";
    foreach ((sort {$docs{$b} <=> $docs{$a}} keys %docs))
      {
        my $docstr;        
        if($bg eq "#eeeeee") { $bg="#dddddd"; }
        else { $bg = "#eeeeee"; }
        $docstr = "<A HREF=\"http://$DOMAIN$_\">$_</A>";
        print REP "
<TR><TD BGCOLOR=\"$bg\" ALIGN=\"right\" WIDTH=\"48\"><FONT SIZE=\"-1\">$docs{$_}</FONT></TD>
<TD BGCOLOR=\"$bg\" ALIGN=\"left\"><FONT SIZE=\"-1\">$docstr</FONT></TD></TR>
";        
      }
    print REP "
</TABLE>
</P>
";

    print REP "
<P>
<TABLE WIDTH=\"600\" BORDER=\"0\" CELLSPACING=\"0\" CELLPADDING=\"5\">
<TR><TH COLSPAN=\"2\" BGCOLOR=\"#003366\"><FONT COLOR=\"#ffffff\">Gateways</FONT></TH></TR>
";
    my $bg = "#eeeeee";
    foreach ((sort {$gateways{$b} <=> $gateways{$a}} keys %gateways))
      {
        my $gatestr;
        if($bg eq "#eeeeee") { $bg="#dddddd"; }
        else { $bg = "#eeeeee"; }
        $gatestr = "<A HREF=\"http://$DOMAIN$_\">$_</A>";
        print REP "
<TR><TD BGCOLOR=\"$bg\" ALIGN=\"right\" WIDTH=\"48\"><FONT SIZE=\"-1\">$gateways{$_}</FONT></TD>
<TD BGCOLOR=\"$bg\" ALIGN=\"left\"><FONT SIZE=\"-1\">$gatestr</FONT></TD></TR>
";        
      }
    print REP "
</TABLE>
</P>
";

    print REP "
<P>
<TABLE WIDTH=\"600\" BORDER=\"0\" CELLSPACING=\"0\" CELLPADDING=\"5\">
<TR><TH COLSPAN=\"2\" BGCOLOR=\"#003366\"><FONT COLOR=\"#ffffff\">Referers</FONT></TH></TR>
";
    my $bg = "#eeeeee";
    foreach ((sort {$referers{$b} <=> $referers{$a}} keys %referers))
      {
        if($bg eq "#eeeeee") { $bg="#dddddd"; }
        else { $bg = "#eeeeee"; }
        my $refstr;
        if($_ eq '-')
          {
            $refstr = "DIRECT REQUEST";
          }
        else
          {
            my $reftrunc = substr($_, 0, 70);
            $reftrunc .= "..." if(length($_)>50);
            $refstr = "<A HREF=\"$_\">$reftrunc</A>";
          }
        print REP "
<TR><TD BGCOLOR=\"$bg\" ALIGN=\"right\" WIDTH=\"48\"><FONT SIZE=\"-1\">$referers{$_}</FONT></TD>
<TD BGCOLOR=\"$bg\" ALIGN=\"left\"><FONT SIZE=\"-1\">$refstr</FONT></TD></TR>
";        
      }
    print REP "
</TABLE>
</P>
";

    print REP "
<P>
<TABLE WIDTH=\"600\" BORDER=\"0\" CELLSPACING=\"0\" CELLPADDING=\"5\">
<TR><TH COLSPAN=\"2\" BGCOLOR=\"#003366\"><FONT COLOR=\"#ffffff\">Hosts</FONT></TH></TR>
";
    my $bg = "#eeeeee";
    foreach ((sort {$hosts{$b} <=> $hosts{$a}} keys %hosts))
      {
        my $hoststr;
        if($bg eq "#eeeeee") { $bg="#dddddd"; }
        else { $bg = "#eeeeee"; }
        $hoststr = "<A HREF=\"$HOSTINFO$_\">$_</A>";
        print REP "
<TR><TD BGCOLOR=\"$bg\" ALIGN=\"right\" WIDTH=\"48\"><FONT SIZE=\"-1\">$hosts{$_}</FONT></TD>
<TD BGCOLOR=\"$bg\" ALIGN=\"left\"><FONT SIZE=\"-1\">$hoststr</FONT></TD></TR>
";        
      }
    print REP "
</TABLE>
</P>
";
  
    print REP "
<P>
<TABLE WIDTH=\"600\" BORDER=\"0\" CELLSPACING=\"0\" CELLPADDING=\"5\">
<TR><TH COLSPAN=\"2\" BGCOLOR=\"#003366\"><FONT COLOR=\"#ffffff\">Agents</FONT></TH></TR>
";
    my $bg = "#eeeeee";
    foreach ((sort {$agents{$b} <=> $agents{$a}} keys %agents))
      {
        my $agentstr;
        if($bg eq "#eeeeee") { $bg="#dddddd"; }
        else { $bg = "#eeeeee"; }
        $agentstr = $_;
        print REP "
<TR><TD BGCOLOR=\"$bg\" ALIGN=\"right\" WIDTH=\"48\"><FONT SIZE=\"-1\">$agents{$_}</FONT></TD>
<TD BGCOLOR=\"$bg\" ALIGN=\"left\"><FONT SIZE=\"-1\">$agentstr</FONT></TD></TR>
";        
      }
    print REP "
</TABLE>
</P>
";

if ($APPEND_LINES)
  {
    print REP "
<script language=\"JavaScript\">
    function popupLog() {
        w = window.open(\"\",\"w\",\"toolbar=no,directories=yes,status=no,scrollbars=yes,resizable=yes,menubar=yes\");
        if (!w.opener) w.opener = self;
        w.document.write('<html><head>');
        w.document.write('<title>Daily Web Server Log for $DOMAIN ($date)</title>');
        w.document.write('</head><body bgcolor=\"#ffffff\" onLoad=\"opener.w = 1\" onUnload=\"opener.w = null\">');
        w.document.write('<pre>');
";
    foreach (@lines)
        {
    print REP "        w.document.write('$_\\n');\n";
        }
    print REP "
        w.document.write('</pre>');
        w.document.write('</body></html>');
        w.document.close();
    }
</script>
";
    print REP "
<P>
Original log: <A HREF=\"JavaScript:popupLog();\">popup</A><BR>
</P>
";
  }
if ($GENERATE_TXT)
  { 
    print REP "
<P>
Original log: <A HREF=\"$date[2].txt\">$date[2].txt</A>
</P>
";
  }

    print REP "
<P>Report generated on <B>$now</B></P>
</CENTER>
</BODY>
</HTML>
";
    close REP;

if ($GENERATE_TXT)
  {
    # write the txt report
    open(REP, ">$date[0]-$date[1]/$date[2].txt")
      or die "can't write to $date[0]-$date[1]/$date[2].txt: $!\n";    
    ($OUTPUT_DAILY > 0) && print "$REPORTS/$date[0]-$date[1]/$date[2].txt\n";
    foreach (@lines)
      {
        print REP "$_\n";
      }
    close REP;
  }
 
  }

#####################################################################
# load summary
sub load_summary
  {
    my ($date, $lines, $accesses, $bytes, $hosts, $docs, $gateways,
        $referers, $agents) = @_;
    open(DS, "$$date[0]-$$date[1]/$$date[2].dss")
      or return undef;
    while(<DS>)
      {
        if(m/\%b (\d+)/) { $$bytes += $1; }
        if(m/\%a (\S+) (\d+)/) { $$accesses{$1} += $2; }
        if(m/\%d (\S+) (\d+)/) { $$docs{$1} += $2; }
        if(m/\%g (\S+) (\d+)/) { $$gateways{$1} += $2; }
        if(m/\%r (\S+) (\d+)/) { $$referers{$1} += $2; }
        if(m/\%c \"(.+)\" (\d+)/) { $$agents{$1} += $2; }
        if(m/\%h (\S+) (\d+)/) { $$hosts{$1} += $2; }
        if(m/\%l (.+)/) { push @$lines, $1; }
      }
    close(DS);
    return 1;
  }

#####################################################################
# comparison
sub member
  {
    my ($ar, $el) = @_;
    foreach (@$ar)
      {
        return 1 if($_ eq $el);
      }
    return 0;
  }

#####################################################################
